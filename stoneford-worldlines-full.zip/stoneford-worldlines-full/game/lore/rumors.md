# Rumours heard at the Shale Lantern Inn

> Mira serves these with herb tea. Some are true. Some are half-true. All of them are dangerous.

- "The wolves near the Mossbarrow don't howl like they used to. Now it sounds like they're calling names."
- "Guild posted a bounty — twenty gold for a silver pendant. Heron Blackwater looked like he'd seen a ghost when he pinned it up."
- "Third level of the Jadehollow mines has been sealed off. Miners say they heard something digging from the other side."
- "Man in a black cloak came through last week. Asking about a silver-haired woman. Nobody knows her. Nobody admits to knowing her."
- "Wolfsjaw Pass hasn't received a supply shipment in two months. Lord Commander's people are eating bark soup."
- "The Windrest road patrols have doubled. Captain Stoneshield says it's bandits. I say it's something worse."
- "Septon Silas walks to the mine entrance every third night. Alone. In the dark. The Faith doesn't explain."
- "Bruno's caravan master is actually a bastard son of a Mistmere noble. Old Reed told me. Old Reed tells everyone everything."
- "They say the Ashford estate sank into the ground eighty years ago. The whole manor. In one night. Only the cellar remains — and that's what they call the Mossbarrow now."
- "Mira Ashford's husband was the last man to walk into the Mossbarrow and come back. He came back wrong. Walked into the river three days later."
- "A pilgrim from the far north came through in autumn. Said his people still sing of an iron dragon that flew the Great Chasm. Said the last words of the hero-from-beyond were *永生 × 黄金 × 无穷*, and nobody left can read them."
- "Bruno's caravan picked up a man in grey who called himself *地者* — a Depth-Walker. Said the truth of the world is at the bottom of the Chasm. Said he was going back down until his lantern failed."
