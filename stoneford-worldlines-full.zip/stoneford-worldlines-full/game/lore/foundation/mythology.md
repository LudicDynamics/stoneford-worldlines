# Mythology of the Grey Reach

> This document records the stories the commoners of the four northern
> kingdoms tell themselves. It is the folk-version of the history. It is,
> in almost every particular, wrong. It is also, in almost every
> particular, the version the player will hear at taverns, at funerals,
> and over the shoulders of old men grinding ink.
>
> The relationship between this document and `colonial-history.md` is the
> relationship between a folk song and a ledger. Both are true. Neither is
> sufficient.

## Part I — The Creation Myth of the Four Lands

Every commoner in the Reach has heard, in some form, the story of the
**Four Hands at the Long Fire**. The version here is the one told in
Stoneford's common-room, as Heron Blackwater tells it on the nights when
the rain is too heavy to keep the dockside shift open.

*In the first dark, before the road and the cliff, there was only the
Long Fire. The Long Fire had four hands, and each hand held a different
thing.*

*The first hand held a cup of amber. From the amber rose the kings of the
east, whose blood is long and whose sleep is light. They built their
halls along the river-mouths, and they learned to count the years by the
falling of the leaves, and by the silence between the leaves falling.*

*The second hand held a stone that whispered. From the stone rose the
quiet ones of the south, who learned to listen before they spoke. They
built their halls on the high cliffs, and they wore the robes of the wet
ash, and they taught the world to kneel.*

*The third hand held a piece of pale metal. From the metal rose the cold
ones of the west, whose armour cannot be hammered, whose word is their
oath, and whose clans are named for the wind. They built no halls. They
built fires, and around the fires they taught their children to climb
down as well as up.*

*The fourth hand held a single copper coin. From the coin rose the
counting ones of the coast, who learned to weigh before they gave, and
to measure before they wept. They built their halls on the water, and
their walls are warehouses.*

*The Long Fire burned down. The four hands remained, and each took a
quarter of the ashes, and each made of those ashes a land. And where the
four lands meet, the ashes rose into the sky and became the Fog. The Fog
is the memory of the Long Fire. It will not lift until all four hands
meet again, and there is no fifth hand to close the ring.*

This is the common version. A player who asks about it will be told it
with minor regional variations: in the Free North, the third hand is
always named first, not third; in Union harbours, the fourth hand holds
a silver coin, not a copper; in Faith telling, the stone that whispered
is called *the First Bell* and is said to still exist, hidden in a
reliquary that only the High Septa may open.

### What the myth is covering

<!-- writer-only
The Four Hands at the Long Fire is a folk compression of the four colonist
waves. Each hand corresponds to one wave, in the order of wave-arrival:
Crown (amber cup = unaging tea), Faith (whispering stone = distant-voice
stones), Free North (pale metal = un-hammerable structural alloy), Union
(copper coin = commercial charter). The "Long Fire" is the far side
civilization; its "burning down" is the collapse. The "ashes rising into
the sky" is the Fog. The "fifth hand" is, in context, nothing in
particular — a rhetorical flourish — but a Crosser or a Magister could
read it as a reference to the next attempted ascent.

No NPC will ever decode this. The myth is load-bearing as myth.
-->

## Part II — The Iron Dragon Myth (Commoner Version)

The commoner version of the Iron Dragon story differs in important
respects from the Crown's version and from the Depth-Walker version. The
commoner version, as told in the high villages of the Free North and in
the older taverns of Windrest:

*In the first age, before the four kings were named, there was a dragon
of iron. It was not a beast. It did not breathe. It sang like a forge,
and it left behind it a straight line of cloud. It flew above the Chasm,
which in those days had no name, and it carried on its back the
Hero-from-Beyond.*

*The Hero was not of our world. He spoke a language no one now reads. He
came to teach us, but our fathers were too slow to learn. He left us a
warning in his own tongue, which the bards still say, though none of
them understand:*

> *Unending body. Shining metal. Road without counting. Do not come.*

*The Iron Dragon flew west into the mist, and the Hero-from-Beyond went
with it. Neither returned. The straight line in the sky is the road the
Dragon took. When the line is seen again, it means the Dragon is flying
a new road, and those who have studied the old ways must listen for the
song of the forge.*

*Some say the Dragon will come back when the four kings forget their
names. Some say it has come back already, and we have not looked up. Some
say it was never a dragon, but a house that flew.*

The phrase *a house that flew* is Old Shepherd Bram's phrase. It has
begun, in the last twenty years, to enter the commoner telling, though
most commoners who use it do not know where it came from.

### Regional variations

**Free North:** The Hero-from-Beyond is a woman, not a man. She is called
*the Far Chieftess* in some tellings. Her warning is given in a gesture,
not in words: she holds up three fingers, spreads them, and then closes
her hand. Clan grandmothers still make this gesture when warning
children away from the cliff.

**Faith:** The Iron Dragon is recast as one of the Silent Saints — the
*Saint of the Straight Line* — who is said to have flown above the world
to test the faithful. The Hero-from-Beyond is erased entirely; the
Faith's version has only the Saint, and the warning is rendered as a
prayer against vanity: *do not seek the body that does not die. Do not
build the tower of shining metal. Do not walk the road that has no end.
These are the three temptations of the vain.*

**Crown:** The Crown does not tell the Iron Dragon myth in public. In
private, among Crown archivists, the myth is treated as the most
accurate surviving folk-record of the last pre-silence contact.

**Union:** The Union does not tell the myth. In Union harbours, the
Iron Dragon is a minor decorative motif — you can see it on some old
brass cups and on the pediment of the Consul-Merchant's counting-house
— but the story has not been told as a story in Union taverns for at
least four generations.

### The Hero-from-Beyond

The Hero-from-Beyond is a composite figure. No one commoner version
agrees on his or her appearance, but certain details recur:

- The Hero's language is lost. No one now speaks it. Some bards can
  recite the warning phrase but cannot decline or conjugate a single
  word.
- The Hero is described as *thin, tall, and dressed in grey*. (This
  description is the reason a grey-coated stranger in the north draws
  glances. Veyl knows this. He has chosen the coat deliberately.)
- The Hero does not age. In one Free North telling, the Hero is said to
  have ridden with three generations of one clan-mother's line, never
  growing older. This is almost certainly a folk borrowing from stories
  about the amber tea, which commoners have occasionally glimpsed at
  Crown functions and not understood.
- The Hero left a sign. Every telling has a sign. The signs disagree.
  The most common signs are: a stone, a coin, a piece of pale metal, a
  fragment of a banner.

The Hero is, almost certainly, a composite of several historical figures
— possibly a first-wave colonial governor, possibly the quartermaster-
under of the Last Ascent, possibly a bard who existed and who wrote the
warning phrase from dictation without understanding it. The composite
has been smoothed by six generations of retelling. What remains is the
Hero who *could not be forgotten*, rather than the Hero who was.

<!-- writer-only
The Iron Dragon is a far-side reconnaissance or transport craft,
unmanned in its present return-cycle but manned in its original
visitation (the quartermaster-under's Last Ascent party used it as
transport for the final colonial landing). The "Hero-from-Beyond" is
partly the quartermaster-under and partly a later folk-memory of the
first-wave colonial governor. The warning phrase was transmitted in the
Late Bell and relayed through the Iron Dragon's last flyover to a bard
who happened to be watching that night. The bard's transcription is
what survives, and is why the phrase is a recognisable three-compound
structure.

None of this decodes in-world. The myth carries the information in a
form that is irrecoverable without the colonial-history document.
-->

## Part III — The Seven-Day Story

Every child in the Reach, in all four kingdoms, knows the Seven-Day
Story. It is the most widely-shared folk artefact in the north. It is
told, usually, on the seventh night of the first thaw, by the oldest
person in the household, to the youngest.

*On the first day, the world was fog. There was nothing to see, and
nothing saw nothing.*

*On the second day, the fog parted, and there was a road. The road was
long and the road was lit, but there was no one on it.*

*On the third day, a traveller came up the road. The traveller had no
name, and no one waiting for them. They walked.*

*On the fourth day, the traveller found four stones. The first stone was
amber, the second stone was grey and whispered, the third stone was
pale and would not break, the fourth stone was round and bore a number.
The traveller took one of each and walked on.*

*On the fifth day, the traveller came to a cliff, and below the cliff
was a chasm, and below the chasm was another cliff. The traveller did
not know which side of the road they were now on.*

*On the sixth day, the traveller sat down. The traveller placed the
four stones around them in a ring and said: *here is where the road
meets itself*. And they slept.*

*On the seventh day, the traveller woke. The stones were gone. The road
was gone. But the traveller remained, and was four now instead of one,
and each of the four walked in a different direction, and those four
are the four kings, and that is how the north began.*

This story is told to children for two reasons: first, because it is a
pleasant story and easy to remember; second, because the fourth day
is, in Free North clans, the night the clan-grandmother tests the
child's memory by asking what the four stones were, and the child's
answer is a marker of their early schooling.

Faith and Crown children are less frequently quizzed, but all four
kingdoms know the story. A player who recites it correctly to any
child in any town will be treated as *one of us*, regardless of their
obvious foreignness.

### The four stones, as cultural markers

The four stones in the Seven-Day story correspond — in a way no
commoner would articulate — to the four royal signets of the four
kingdoms:

- the amber stone = the Crown's signet (amber and gold)
- the grey whispering stone = the Faith's signet (grey stone, sometimes
  called *the Bell-stone*)
- the pale unbreakable stone = the Free North's signet (pale inlaid
  metal on a leather pauldron)
- the round numbered stone = the Union's signet (a stamped copper disc)

If the player asks the oldest Septon in any Faith chapel whether the
four stones of the Seven-Day story are the four signets, the Septon
will smile and say, *perhaps, child. The stones in the story are also
the stones in the pocket. It is the same stone.* This is a stock
answer. It has been the stock answer for at least four generations.

## Part IV — Folk Cosmology

Commoners do not, as a rule, have a unified cosmology. They have a
collection of small explanations, each adequate to its domain.

### The Sun

*The sun is the lantern of the First Hand.* This is the Crown teaching.
The sun, in this telling, is the lantern Voss the First lit when he
came up the road on the third day, and it has burned ever since
because no Voss has since walked far enough to need it.

The Faith teaches, instead, that *the sun is the eye of the Silent
Saints, and the Silent Saints have closed it when they sleep*. This is
why sunset is called *the closing* in some Faith texts.

The Free North teaches that *the sun is a fire kept by the first of the
cold ones, and when the cold ones' line ends, the sun will go out*.
This is a source of some anxiety among Free North children, who are
told, on reaching a certain age, that the cold ones' line has not yet
ended and the sun is in no present danger.

The Union teaches nothing about the sun. In Union harbours, the sun is
a thing that rises and sets and affects the tides and the drying of
the salt. No more is required of it.

### The Stars

Every kingdom agrees that the stars are *the lanterns of the Depth-
Walkers who have gone down and not come up*. This is the one piece of
commoner cosmology that is shared across all four kingdoms. It is
inconvenient for the Faith, which teaches that the stars are *the
Silent Saints' other eyes*, but in practice the Faith tolerates the
lantern-reading because it is too widespread to suppress.

A shepherd on a clear night will count the stars and say, in a low
voice, *another one down*. A Depth-Walker will, at a funeral, gesture
to the sky and say *he is lit now*. The two readings coexist. Neither
is challenged.

<!-- writer-only
The Depth-Walker lantern-cosmology is a beautiful accident. There is no
mechanical connection between descent-deaths and stars. But the
widespread belief in this connection gives the Depth-Walker order a
kind of cultural oxygen that the Faith cannot match. This is part of
why the royal contracts with the Listeners have been so quiet: openly
attacking the order would attack a story every child knows.
-->

### The Fog

Commoners have three explanations of the Fog, held simultaneously and
without contradiction:

1. **The Fog is the memory of the Long Fire.** (From the creation myth.)
   The Fog is the ashes of the Long Fire rising. It will not lift
   until the four hands meet again. This is the most common belief in
   Stoneford and the river-towns.

2. **The Fog is the breath of the Chasm.** (From Free North tellings.)
   The Chasm breathes, and when it breathes out, the Fog comes. When
   it breathes in, the Fog recedes, briefly, and one can see farther
   than on other days. Every clan-grandmother will tell a child to
   *watch for a breathing-in day*, and will not explain what they mean
   by it.

3. **The Fog is the veil of penitence.** (Faith teaching.) The Silent
   Saints laid the Fog over the world when the world proved
   unworthy. The Fog will lift when penitence is complete. The Faith
   does not say how penitence is measured.

A player who asks a commoner *why is there fog?* will receive one of
these three answers, often without the commoner being fully certain
which of the three they believe. In practice, most commoners believe
the first one in the morning, the second at sunset, and the third at
funerals.

### The Chasm

The Chasm is not, in folk cosmology, a geographical feature. It is a
thing that *exists*, in the way the sky exists and the sea exists, and
no commoner has an explanation for its existence because no commoner
has ever been asked.

If pressed, a commoner will say: *the Chasm has always been there. The
Chasm is where the world ends. No one crosses the Chasm. Some walk
down into it. None come back up.* This is the limit of the commoner
cosmology. The Crown knows more. The Free North knows more. The
Depth-Walkers believe they know more. The commoner does not want to
know more.

## Part V — What the Faith Officially Teaches vs. Street Superstition

The Faith of Mistmere is the only one of the four kingdoms with a
systematic doctrine, and its doctrine differs, often sharply, from
street belief.

### Official Faith doctrine

The Faith teaches that:

- The world was made by the **Silent Saints**, seven in number, each
  responsible for a different domain (the sun, the moon, the sea, the
  stone, the fire, the word, the silence).
- The Hundred-Year Hush is *the withdrawal of the Silent Saints'
  voices*, imposed for an impiety the world has not yet confessed. The
  Faith's central liturgical project is to identify and confess this
  impiety.
- The Iron Dragon is a recast saint (*the Saint of the Straight Line*),
  and its appearance is an omen, not a physical event.
- The far side of the Chasm is *the forbidden west*, and seeking it is
  the primary sin of the age.
- The Depth-Walkers are *mistaken*. Not heretical — the Faith is
  careful here — but mistaken. They look down when they should look
  up.
- The amber tea is *uninspected*, which is the Faith's term for things
  the Faith has not yet ruled on.

High Septa Malen the Unsleeping teaches all of the above. She does not
believe all of it. Her private view, which she has confided to no one,
is that *the Silent Saints have not withdrawn. The Silent Saints have
died. The silence is not penitential. The silence is corpse-silence.*
She cannot say this aloud. She has not slept for ten years.

### Street superstition

What ordinary Faith-flock believe, in addition to or instead of the
doctrine:

- The stone that whispers is **real**, and the Septa's stone is one of
  them. This is said in low voices. The Faith does not confirm or
  deny.
- The Hundred-Year Hush is **the far side's abandonment**, not the
  Saints'. This is the commoner consensus in the north; it directly
  contradicts Faith doctrine, and Faith preachers are trained to
  redirect it without confronting it.
- The straight line in the sky is **a dragon's road**, not a saint's
  test. Commoners cross themselves the Faith way when they see it,
  but they also touch iron and mutter the Iron Dragon's name.
- The Ashen Herald is a **ghost**, specifically the ghost of a first-
  hand arbitration mediator who died before the four crowns were
  named. The Faith has not ruled on this.
- **Iron is lucky.** If you find a piece of iron on the road, you
  keep it. If you find a piece of pale metal that will not hammer,
  you bury it again and do not speak of it. This superstition is
  almost certainly the street-residue of a Free North teaching that
  has leaked south over generations.

### Where the Faith and the street agree

Both Faith doctrine and street superstition agree on:

- The world is made. It is not a brute accident.
- Looking up is more respectable than looking down.
- The Fog is meaningful.
- The Hundred-Year Hush is *something that has been done to us*, not
  *something we chose*.
- Children should not be sent to the cliff unaccompanied.

The Faith welcomes these agreements. They allow it to claim that
street superstition is *an imperfect understanding of doctrine*,
rather than a rival system.

## Part VI — The Minor Figures of Folk Belief

These are the figures a player will encounter in passing, in bard-songs
and in half-remembered warnings, without receiving a full explanation.

### The Woman at the Ford

*She washes stones at the ford where the road ends. If you pass her on
a third night, she will offer you a stone. Do not take it. If you take
it, she will not follow you, but the stone will.*

This is a Stoneford-specific figure. It is, almost certainly, a
retrospective rationalization of Septon Silas's habit of walking the
mine-mouth every third night; the Woman is the folk's attempt to make
sense of Silas's finding of the shard. Silas is male, not female; the
folk has regendered him in transmission, which is not unusual.

### The Counting Hermit

*On the high pass west of Jadehollow, there is a hermit who counts.
No one knows what he counts. If you meet him, do not ask what number
he is on, or he will start again.*

This is a folk figure with no clear historical basis. It may be a
drift from Depth-Walker lantern-count practice, or it may be older.

### The Cold Child

*On the nights the fog is thickest, a child walks the roads with a
lantern. The child is not lost. The child is looking for something
very small. If you see the child, do not offer to help. The thing the
child is looking for, you do not want to find.*

This is a pan-regional figure, told in all four kingdoms. It is a
nurse-tale told to keep children off the roads after dark. It has no
colonial connection and no hidden meaning. It is, for once, just a
nurse-tale.

### The Iron-Voiced Man

*Sometimes a stranger arrives at a village and speaks, and his voice
sounds like iron. Do not sell to him. Do not refuse him. If he asks
for bread, give him bread and nothing else.*

This is the folk premonition of Veyl. Travellers who have met Veyl
and then heard this tale for the first time report a feeling of
dislocation. Commoners who know the tale and then meet Veyl generally
do what the tale prescribes: they give him bread and nothing else.

### The Silent Maester

*In a monastery in the north, there is a woman who cannot speak. She
draws pictures on the walls. The pictures are of things that should
not exist. Do not go to look at the pictures. But if you do, do not
tell anyone what you saw.*

This is Eilin, in folk form. The tale has spread slowly over the
eleven years of her silence and is now told in Windrest and as far
south as Stoneford. It is never told within three days' ride of the
Wolfsjaw monastery itself; there, Eilin is simply *the Maester*, and
the folk version is considered disrespectful.

## Part VII — On the Conflict Between Myth and History

A player who begins to piece together the history of the Grey Reach
will notice that the myths do not exactly match. The creation myth has
four hands; the history has four waves. The Iron Dragon's warning is
recited in commoner taverns in a phrase the Crown holds in a sealed
reliquary. The Seven-Day Story's fourth stone is the Union's signet
and also, possibly, not.

This is not an accident. The folk transmission of the colonial
history has been continuous but lossy, and each generation has
smoothed away what was too specific to be useful. What remains is a
myth-structure that *holds the shape* of the history without holding
its content. A player who reads this document alongside
`colonial-history.md` will see the correspondences. An NPC who has only
this document and not the other will hear fairy tales and warnings.

Both are the real Grey Reach. The Reach is what it remembers plus
what it has forgotten; the forgetting is not an error, it is a
preservation method. Without the forgetting, the Crown's cover story
would have collapsed two generations ago. With the forgetting, it has
held.

The orchestrator should treat the myths as *true-to-the-teller* and
should allow commoners to offer them with full conviction, regardless
of their partial or total inaccuracy. No commoner will ever be shown
to be wrong on-screen. If a player confronts a commoner with the real
history, the commoner will simply fail to understand what is being
said, in the specific way that a person fails to understand a
language they do not speak. The folk tongue is the myth. The scholar's
tongue is the history. They do not translate.

## Part VIII — For the Next Writer

If you are extending this document:

- Do not retcon any of the myths. They are load-bearing in their
  current form.
- Do not resolve the tension between folk and history. The tension is
  the point.
- New minor figures of folk belief are welcome if they are grounded in
  one of the existing storylines' props or NPCs. Do not invent folk
  figures with no anchor.
- The Seven-Day Story's fourth stone should not be changed. Four is
  the number. The story's power is that it holds the colonial shape
  in a form children can remember.
- Do not give the commoners a cosmology of the Fog more systematic
  than the three they have. Three is the number. Any commoner who
  tries to systematize further is a Crosser in disguise.

That is the mythology of the Reach. It is, like all mythology, the
memory of a history the people making it did not know they were
making. It will outlive the history that birthed it, and it will, in
time, become the only history there is.
