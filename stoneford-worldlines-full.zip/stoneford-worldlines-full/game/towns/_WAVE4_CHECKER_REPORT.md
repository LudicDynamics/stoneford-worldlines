# Wave 4b Checker Report

## Wave 4b Editor pass — status (2026-04-14)

- **B1 flag namespace** — RESOLVED via `game/meta/flag_aliases.json` (alias-table strategy; no churn to inline gates).
- **B2 Ylva ↔ Yura cousins** — RESOLVED (T002/npcs.json NPC_T002_07 description + Ylva line "Cousin." restored).
- **B3 Durm at Windrest** — RESOLVED (world/cultures/union.md §161 + §201 corrected; ingot on Durm's shelf, oblique Caul link via T001 NPC008 Bruno).
- **B4 Items registry** — RESOLVED (items.md §IX appended; 28 IDs registered with prose).
- **B5 D001 access node** — RESOLVED (T001/town_map.json: trail_to_D001 + D001_mossbarrow_entry added; main_street + gate_north linked).
- **S1** Yura description — verified clean (no "sister"). **S2** Silas T004 visits-T001 note added. **S3** Tobiah branch added in T001 messenger quest + canonical flag emitted; T005 arrival_condition aliases via flag_aliases.json. **S4** unaging_tea_dregs_held flag emitted by T004 envoy theft branch. **S5** T005_sula_contract_shown emitted by all three Sula audience branches. **S6** pale-alloy grandfathered with editor note in items.md §IX.
- **M1** engine-shaft → drop-shaft in D002. **M3** Sula standardized on "Archdepth Sula of the Iron Lantern" (T004 quest faction_truth + T005 npcs title). **M5** Vossel: T002 and T003 both name him "Preceptor Vossel the Younger" — verified consistent. **M7** Silas role unified to `faith_septon` at T004. **M2/M4/M6/M8** noted but require no edit (canonical chronology, alias-handled, no collision, same-NPC intent confirmed).

## Flag aliasing strategy (editor note)
Canonical convention: `flag.T00X_<short_slug>` for town-emitted, `flag.{A|B|C|D|E}_<slug>` for line-emitted, `flag.T005_<slug>` for summit-internal. Resolver consults `game/meta/flag_aliases.json` at gate-eval time; if any upstream flag in the alias set is true, the gate opens. New work should emit canonical names directly.

---

## Summary verdict
**needs-rework** — five editor-blockers, mostly mechanical (flag-naming, kinship conflict, missing item registry). No town or dungeon requires a full rewrite; all blockers are surgical.

## Blockers (editor must fix) — 5
1. **Flag-namespace mismatch between T005 gates and T001–T004 flag emitters.** T005 NPCs and quests gate on `flag.T001_*`, `flag.T002_*`, `flag.T003_*`, `flag.T004_*`, `flag.A_*`, `flag.C_*`, `flag.D_*`, `flag.E_*` (e.g. `flag.T001_brass_token_found`, `flag.T002_ylva_met`, `flag.T003_malen_proclamation_seen`, `flag.T004_jadehollow_register_seen`, `flag.A_jadehollow_register_delivered`, `flag.T001_herald_letter_delivered_to_tobiah`). Towns 1–4 emit `outcome_flags` and reward flags under different names: `brass_token_held`, `heralds_letter_held`, `four_knot_seen`, `a_line_ban_read`, `has_bram_testimony`, `met_kestrel_gated`, `renna_trusts_reader`, `magister_audience_pending_T005`, `b_line_sprout_closed`, `lantern_oil_chain_noted`, `guild_path_chosen_or_refused`. No normalization layer exists. As written, **every soul-NPC's shallow/deep dialogue at T005 is unreachable.**
2. **Ylva ↔ Yura kinship conflict (Wave 4a pre-flagged).** T002/npcs.json line 140 calls Ylva **"sister to Captain Yura Stoneshield"**; T002/npcs.json line 12 under Yura says "She lost her entire squad at Wolfsjaw" but the Yura–Ylva stable scene originates in Line C storyline (C-four-crown-intrigue.md lines 23, 77, 103), where they are explicitly **cousins, same House, different branch, different country**. Line C is authoritative (storyline canon > refiner). T005 Brenna's dialogue ("She is my elder. She walked out of our hall…") requires Ylva be Brenna's sister, so if Ylva=Yura's sister, Yura becomes Brenna's sister too — collapsing the whole Greyhold-Stoneshield distinction. **Must revert to cousins.**
3. **Durm is T002 (Windrest) — legacy Stoneford reference must be corrected in cultures/union.md.** T002 refiner (npcs.json NPC_T002_09), D-storyline, SHARED_BRIEF inventory, T001/npcs.json Bruno dialogue ("Tried to trade it in Windrest to a smith called Durm") are all consistent: Durm at T002. But `world/cultures/union.md` line 201 states *"The Stoneford blacksmith Durm was contracted to test the metal…"* and the same file's line 161 refers to an un-hammerable lump in the **Stoneford** warehouse as a Caul-inventory item. This is the inverse of the canonical placement (the lump is at Durm's forge at T002, not a Caul warehouse in T001). **Fix union.md: Durm is at Windrest (T002); the un-hammerable lump described in §201 is on Durm's shelf, not Caul's Stoneford warehouse.**
4. **Quest-item IDs missing from items.md.** items.md contains zero IDs matching quest rewards/held items. At least 22 IDs referenced by quests or NPC dialogue have no registry entry: `silas_sealed_letter` (T001), `heralds_letter` (T001/Q_T001_messenger), `silas_guild_branch_letter` (T001), `rubbing_of_the_shard` (T001), `glowfen_rush_jar` (T001), `church_cipher_fragment` (T001), `north_gate_pass` (T002), `governor_writ` (T002), `military_shortsword` (T002), `noles_direction_note` (T002), `durm_lump_loan` (T002), `directional_lantern_E` (T002), `greyhold_token` (T002), `vossel_intro_letter` (T002), `sara_case_notes` (T003), `wolfsjaw_badge` (T003), `merick_audience_seal` (T003), `eilin_slate_rubbing` (T003), `wall_glyph_rubbing` (T003), `brass_one_dot_token` (T003), `deep_hearings_book` (T003 flagged ITM.DOC.DEEP_HEARINGS), `faith_deepvein_pact` (T003), `uncut_crystal` (T004), `healing_salve` (T004), `unaging_tea_dregs` (T004), `crosser_sketch` (T004), `harbour_wall_rubbing` (T005), `thornwood_cane` (T005). Editor must either (a) add them to items.md or (b) agree a parser convention that quest-embedded items are self-declaring.
5. **T001 town_map.json is missing the D001 Mossbarrow access node.** T001 quests Q002 ("Wolves at the Barrow", `unlocks: discover_dungeon: D001`) and Q003 ("The Whispering Cairn", `requires: D001_discovered`) assume an access node. T001/town_map.json has only `exchange_vault` (D006). No east-trail, no R002 hook point, no Mossbarrow dungeon_entry. **Add a Mossbarrow trail node + D001 entry node.**

## Serious issues — 6
S1. **Yura Stoneshield flag "sister" in description (T002/npcs.json NPC_T002_01) is tied to Blocker 2** — purge the word "sister" from her description and fix the Yura/Ylva cross-ref consistently in Yura's lines, Ylva's description, and any dialogue hooks.
S2. **Silas kinship chain is consistent but sparsely tagged.** T001/NPC005 declares `canonical_home: "T004"` and has a visiting schedule; T004/NPC_T004_07 has no reciprocal "visits T001 every third night" note. Not a contradiction — but editor should drop a one-line `visits: T001` into T004/NPC_T004_07 for grep-integrity. T003 has no Silas presence and correctly does not claim one.
S3. **Tobiah arrival condition at T005 references `flag.T001_herald_letter_delivered_to_tobiah`** (NPC_T005_06, line 190) but T001 Q_T001_messenger delivers the Herald's letter to **Heron Blackwater**, not Tobiah (see T001/quests.json line 141, "Bring the seal to Heron Blackwater in the Guild back office"). There is no quest path that delivers the letter to Tobiah. Either rename the flag to match the Heron path or add a Tobiah-variant branch in T001.
S4. **Envoy Alric "un-emptied cup" item output mismatch.** T004 Q_T004_envoy_audience theft_path gives `unaging_tea_dregs`, which T005 Darrik's deep gate expects as `flag.C_unaging_tea_fragment`. No item→flag bridge.
S5. **T005 sula contract gate.** `flag.T005_sula_contract_shown` is required by Corvin's deep dialogue (NPC_T005_01) and Sula's deep (NPC_T005_09). No quest in T005 explicitly emits this flag; only Q_T005_sula_audience's "betray_to_guild" branch produces `contract_sold_to_guild`. Add emission of `T005_sula_contract_shown` when the player presents the contract in either Sula's or Corvin's audience.
S6. **"Pale-alloy" in player-visible dungeon prose.** D001, D005, D007, D008, D009, N001 describe fittings and pegs as "pale-alloy". `alloy` is on the forbidden modern-vocabulary list (scope §E). The word is pervasive and deliberate (Dungeon Prose Polisher established it as the in-world indigenous sensory gloss for kor-nor-family metal), but the original checker list forbids `alloy` outright. Decision needed: grandfather "pale-alloy" as an indigenous term, or rename globally to "pale-metal" / "kor-nor-like metal". Recommend grandfather with a glossary note in old-tongue.md; otherwise it's 20+ lines of edits.

## Minor issues — 8
M1. D002-jadehollow-mines-l3.md uses `engine-shaft` and `engine shaft` for the central mine shaft. "Engine" in pre-industrial English means "contrivance" and was standard mining vocabulary for horse-whim and waterwheel lifts, but a modern reader will read it as combustion-engine. Consider renaming to "drop-shaft" or "main shaft."
M2. T005 Corvin's "gated_shallow" line *"the same season a maester's tongue was taken"* — this references Eilin's tongue-cutting. Fine canonically, but check: Line B canon says Eilin's tongue was cut **by royal order** (T003/NPC_T003_06). Corvin implies a Guild timing link ("the Ban was re-drafted eleven years ago, the same season"). Reconfirm with editor whether the Ban/tongue are intended to share a chronology.
M3. `Archdepth Sula of the Iron Lantern` (T005) vs `Archdepth Sula of the Long Descent` (T004/NPC_T004_07 secret, and Kestrel ref). Two titles for one person. Pick one.
M4. T005 `Q_T005_summit` references `flag.tobiah_absent_or_present_per_T001_choice` as an effect but no upstream flag controls it; ties to S3.
M5. T003/NPC_T003_10 Preceptor Vossel **and** T002/NPC_T002_06 Preceptor Vossel the Younger are the same person — fine (the T002 description notes "visiting Windrest this fortnight") — but the T002 record names him `Vossel the Younger` (facility: scribe_rest) while T003 names him `Preceptor Vossel` (house: monastery). Consistent enough; editor may want identical canonical naming across both files.
M6. Dungeon Prose Polisher color-NPCs (Obra, Orvin, T-boy, Branic, Imre, Jerem, Tem, Jas, Horn, Hen, Mela, Sister Vela, Rett, Tam) — I spot-checked none collide with T001-T005 NPC lists. "Sister Vela" is close to but distinct from "Sister Ivy" (T003). "Branic (Mistmere senior)" — verify doesn't conflict with any crown/guild-name not yet enumerated; not found on quick scan.
M7. T001 NPC005 Silas and T004 NPC_T004_07 Silas have different titles ("faith_septon" vs "priest"/"Septon of the Dawn Chapel, Jadehollow"). Consolidate role nomenclature.
M8. T005 NPC_T005_06 Tobiah Caul is `house: "Caul & Sons"` but T001 NPC006 Tobiah is also `Caul & Sons`. Same man, two stat blocks — confirm editor intent that T005 Tobiah is the same NPC who *may arrive* based on T001 path.

## Resolved internally (no action)
- T003 Vossel / T002 Vossel identity (minor note retained as M5 only).
- "Colonial" terminology — all appearances are in writer-only `secret`/`faction_truth` fields, or in Kestrel's gated deep dialogue (by design per SHARED_BRIEF §H). No hidden-premise leak.
- Facility coverage — every soul NPC has a named facility file (guild_citadel, royal_chambers_crown, royal_chambers_faith, royal_chambers_free_north, royal_chambers_union, sulas_ledger_room, sunken_ward, veyls_camp, summit_hall exist at T005). Earlier towns likewise.

## Detailed findings

### A. Cross-town flag chain integrity (BLOCKER — see B1)
Audit of T005 gate flags:

| T005 gate flag | Where expected to be set | Where actually set | Status |
|---|---|---|---|
| flag.T001_brass_token_found | T001 | T001 sets `brass_token_held` via Q_T001_guild_token outcome_flags | MISMATCH |
| flag.A_brass_token_handled | T001 | not set by name | MISSING |
| flag.T001_herald_letter_read | T001 Q_T001_messenger | not set; sets `heralds_letter_held`, `four_knot_seen` | MISMATCH |
| flag.T001_herald_letter_delivered_to_tobiah | T001 | no path — letter goes to Heron | MISSING (S3) |
| flag.T001_heralds_letter_delivered | T001 | (see above) | MISMATCH |
| flag.T001_silas_shard_received | T001 Q_T001_shard_escort | sets `stone_shard_carried`, `silas_letter_carried` | MISMATCH |
| flag.T002_cloud_witnessed / flag.D_straight_line_cloud_witnessed | T002 Q_T002_cloud_report | no named outcome flag; only gives item note | MISSING |
| flag.T002_metal_lump_acquired / flag.D_un_hammerable_lump_shown | T002 Q_T002_metal_lump | gives `durm_lump_loan` item; no flag | MISSING |
| flag.T002_yan_lantern_delivered / flag.T002_yannic_errand_accepted | T002 Q_T002_lantern_north | item-only reward; no flag | MISSING |
| flag.T002_ylva_audience / flag.T002_ylva_met / flag.C_ylva_audience | T002 Q_T002_envoy_audience | `greyhold_token` only; no flag | MISSING |
| flag.T003_shard_delivered | T003 Q_T003_shard_delivery | item-only; no flag | MISSING |
| flag.T003_eilin_audience / flag.T003_eilin_met | T003 Q_T003_eilin_audience | sets `b_line_sprout_closed` | MISMATCH |
| flag.T003_ban_read / flag.T003_northern_ban_seen | T003 Q_T003_ban_fragment | sets `a_line_ban_read` | MISMATCH |
| flag.T003_wall_glyph_rubbing / flag.seen_monastery_glyph_上下相通 | T003 Q_T003_glyph_rubbing | item-only | MISSING |
| flag.T003_malen_proclamation_seen | T003 | not emitted | MISSING |
| flag.C_septon_silas_letter | T001/T004 | not emitted | MISSING |
| flag.T004_bram_interview / flag.T004_bram_conversation | T004 Q_T004_bram_testimony | sets `has_bram_testimony` | MISMATCH |
| flag.T004_kestrel_gate_cleared / flag.T004_kestrel_met / flag.T004_kestrel_contacted / flag.T004_kestrel_refused | T004 Q_T004_library_deep_archive | sets `met_kestrel_gated` | MISMATCH |
| flag.T004_envoy_audience | T004 Q_T004_envoy_audience | sets `heard_crown_pronouncement` | MISMATCH |
| flag.T004_dregs_acquired / flag.C_unaging_tea_fragment | T004 (theft_path) | item-only | MISSING |
| flag.T004_jadehollow_register_seen / flag.A_jadehollow_register_delivered | T004 | no register quest canonically exists — Line A register is in Kassa's lower drawer but no quest emits a flag | MISSING |
| flag.E_distant_voice_identified | T003 or T005 | not emitted | MISSING |
| flag.T005_magister_met, T005_summit_attended, T005_herald_unmasked, T005_sula_contract_shown, T005_veyl_crest_shown, T005_hallen_fed, T005_herald_contacted | T005 internal | partially emitted (Q_T005_herald_unmasked emits `T005_herald_unmasked`, Q_T005_hallen_care emits `T005_hallen_fed`). Others unreferenced. | PARTIAL |

Resolution: **flag normalization table**. Editor must decide: (a) rename T005 gate conditions to match the emitters; or (b) add T001-T004 outcome_flags emission of the canonical `flag.T00X_*` / `flag.{Line}_*` names alongside existing flags.

### B. NPC ID collisions
- T001 uses `NPC001..NPC010`.
- T002/T003/T004/T005 all use `NPC_TXXX_NN` form.
- **No ID collisions.** Silas appears as T001:NPC005 (visiting) and T004:NPC_T004_07 (canonical home). Tobiah as T001:NPC006 and T005:NPC_T005_06 (travels to summit). Vossel as T002:NPC_T002_06 (visiting Windrest) and T003:NPC_T003_10 (at monastery). These are intentional same-person multi-location blocks, which is fine.
- Naming inconsistency (not collision): T001 uses plain `NPC###` while T002-T005 use `NPC_TXXX_##`. Recommend normalization.

### C. Tier-E relic placement (CONSISTENT)
Verified against relics.md:
- Unbroken Kettle / unaging tea → Alric (T004, envoy_house) + Darrik (T005 royal_chambers_crown): **consistent, two legitimate instances**.
- Unbreakable metal (kor-nor) → Brenna (T005 royal_chambers_free_north) + Durm's lump (T002) + Bram's valley stash (T004 per D-story): **consistent**.
- Distant-voice stones → Malen (T005 royal_chambers_faith) + Malen's stash at T003 proclamation + Ylva's night-listening at T002 + N001 stash: **consistent**.
- Colonist Crest Fragment → Veyl (T005): **single-instance, consistent**.
- Ancient Stone Shard → Silas (T001 item_held `stone_shard_T001`) → Eilin at T003: **consistent, follows transport chain**.
- Guild Charter → Corvin (T005 guild_citadel): **single-instance, consistent**.
- Listener Contract Parchment → Sula (T005 sulas_ledger_room): **consistent**.
- Half-Burned Northern Ban → Naryn (T003 monastery_archive): **consistent**.

### D. Quest prerequisite chains
- Q_T002_shard_escort_continued requires `silas_shard_carried` (outcome_flag of T001 Q_T001_shard_escort). **Match.**
- Q_T003_shard_delivery prereq_items `ancient_stone_shard`. T001 carries `stone_shard_T001` as Silas's item. Item-id mismatch — editor should unify on one ID.
- Q_T003_eilin_audience requires `Q_T003_shard_delivery_completed`. **OK.**
- Q_T003_ban_fragment requires `guild_brass_token` or `magister_warrant`. T001 Q_T001_guild_token produces `brass_token` as part of oilcloth bundle; quest tag `brass_token_held`. Slight ID mismatch.
- Q_T004_library_deep_archive requires `Q_T004_library_research_started`. T004 quest exists (`Q_T004_library_research`). Status flag `renna_trusts_reader` from completion should gate; `started` is undefined. Minor.
- Q_T005_* chains — see §A (flag-name mismatches).

### E. Modern vocabulary leaks
- Towns: no hits for plane/aircraft/engine/reactor/etc. in player-facing content. "circuit" appears as "on circuit" (ecclesiastic/administrative sense, legitimate pre-industrial usage).
- Dungeons: "alloy" appears as "pale-alloy" ×20+. "engine-shaft" / "engine shaft" in D002 ×3. See M1, S6.
- No reactor/satellite/radar/cryogenic/prosthetic/vehicle/missile/module/transistor in any file.
- Player-facing leakage: `pale-alloy` is player-facing in N001 ambient paragraphs. Borderline; recommend grandfathering as indigenous term.

### F. Dungeon ↔ town cross-links
- D001 Mossbarrow referenced by T001 quests; **no access node in T001 town_map.json** — BLOCKER 5.
- D002 Jadehollow Mines L3 ↔ T004 town_map.json: referenced line 165. **OK.**
- D003 Sunken Ward ↔ T005 town_map.json node `D003_sunken_ward_entry`. **OK.**
- D004 Brokenspine Watchtrail ↔ T003 trail_to_D004 + T005 D004_brokenspine_entry. **OK.**
- D005 Olric Barrow ↔ T003 trail_to_D005. **OK.**
- D006 Old Exchange Vault ↔ T001 exchange_vault node with `dungeon_ref: D006`. **OK.**
- D007 Fogmoor Hide: T002/town_map mentions "R013 / D007" in gate_north description but has no dedicated trail node. Acceptable (off-road trail).
- D008 Crosser Workshop ↔ T004/town_map line 174. **OK.**
- D009 Second Sun Crag ↔ T003 trail_to_D009. **OK.**
- N001 Chasm Approach ↔ T005/town_map N001_chasm_approach. **OK.**

### G. New items not in items.md
See Blocker 4 for full list of 22+ IDs.

### H. Hidden premise leaks
- All `colonial`/`from the other side` / `Vi kam fra den andre sida` references are in writer-only `secret`/`faction_truth`/`canon_flags` fields, **except**:
  - Kestrel's gated `theory` dialogue (T004/NPC_T004_07 line 213): *"The colonial road ran under the Chasm…"* This is intentional; Kestrel is gated behind the glyph/artefact wall per SHARED_BRIEF. OK.
  - Ylva whisper `we came from the other side` — Line C authorises this one utterance; not reachable unless social DC 17 + trust condition met. OK.
  - Hallen's raving (T005/NPC_T005_10): *"Below. And beyond. Are one. The floor is the far wall."* Premise-adjacent but framed as madness, by design. OK.
  - Veyl's *"Vel-bren. Kor-thal. San-tol. Ven-u. 'Eternal-life × Gold × Infinity. Do not visit.'"* (T005) — borderline reveal, but gated behind `flag.T005_veyl_crest_shown`. OK.
- No uncontrolled leaks identified.

### I. Facility coverage
All soul NPCs have facility_file entries. Spot-checked:
- T001 NPC005 Silas → `chapel_T001` → `facilities/chapel.json` exists.
- T002 NPC_T002_07 Ylva → `envoy_quarters` → `facilities/envoy_quarters.json` exists.
- T003 NPC_T003_06 Eilin → `monastery_archive`/`monastery_library`/`monastery_chapel` exists (Eilin's cell is within the monastery complex).
- T004 NPC_T004_07 Silas → `chapel` exists. NPC_T004_13 Bram → `bram_cottage` exists.
- T005 all 13 NPCs map to existing facilities listed in town_map or inline scenes.
No missing facility files.

### J. Dialogue tone consistency (10-sample)
Spot-sampled across towns:
1. T001 Heron: "Pin the silver-fish pendant board-side." — concrete, short, tone OK.
2. T001 Mira: "Hearth needs sweeping. I'll be in the back." — tone OK.
3. T002 Yura: "The Keep does not log weather." — tone OK.
4. T002 Durm: "I have laid six hammers on that stone." — strong concrete image, OK.
5. T002 Ylva: "I drink after my chieftess, not before her." — OK, cultural.
6. T003 Linden: "Name, rank, and business. In that order." — OK.
7. T003 Eilin (slate): "same hand. older than the ban." — OK, sparse.
8. T004 Bram: "It was not a dragon. It was a house that flew." — one of the series' best lines, OK.
9. T004 Alric: "Hear it plainly, and carry it home." — OK, courtly.
10. T005 Corvin: "You have come far. Sit. I am told you carry paper that is not yours." — OK, patient.
No tone outliers. Dungeon Prose Polisher color-NPC lines (sampled N001, D007) also conform.

## Proposed resolutions

**For Blocker 1 (flag namespace):** Editor creates `game/meta/flag_aliases.json` mapping existing outcome_flag names to the `flag.T00X_*` namespace, *OR* does a find-replace in T005 gate_conditions to use the actual flag names emitted upstream. Recommend the alias file — less churn.

**For Blocker 2 (kinship):** In `T002/npcs.json`:
- NPC_T002_01 Yura description: remove any "sister" line (none present in current text, but confirm).
- NPC_T002_07 Ylva line 140: change *"She is sister to Captain Yura Stoneshield"* → *"She is cousin to Captain Yura Stoneshield — same House, different branch, different country."* and update line 143 Ylva line to restore the "Cousin" address already canonical in Line C's stable scene (currently "Sister. If you are asked…" at T002/npcs.json line 143 — must change to "Cousin." to match Line C line 103).

**For Blocker 3 (union.md):** In `world/cultures/union.md`:
- Line 161: remove "Stoneford warehouse has logged an un-hammerable metal lump" (the lump is on Durm's shelf at T002, not in Caul's inventory).
- Line 201: change "The Stoneford blacksmith Durm" → "The Windrest blacksmith Durm" and amend the provenance: the ingot is on Durm's shelf, not in a warehouse; the Caul inventory link is oblique (via Bruno's attempted sale per T001 NPC008).

**For Blocker 4 (items.md):** Add a canonical ID table at the end of items.md enumerating every quest-emitted item with (id, name, town-of-origin, storyline-line). Alternatively declare in meta rules that quest-embedded items are self-registering.

**For Blocker 5 (D001 access node):** In `T001/town_map.json` nodes list, add:
```json
{ "id": "trail_to_D001", "name": "Trail to the Mossbarrow", "type": "trail", "pos": { "x": 820, "y": 180 }, "links": ["main_street", "D001_mossbarrow_entry"], "danger": 2, "leads_to": "D001" },
{ "id": "D001_mossbarrow_entry", "name": "D001 — Mossbarrow", "type": "dungeon_entry", "dungeon_id": "D001", "pos": { "x": 900, "y": 140 }, "links": ["trail_to_D001"] }
```

**For S-issues:** Editor-pass items. Per-item fixes are listed inline in each S-row above.

## Top 5 biggest editor fixes
1. Reconcile T005 gate flag names with T001–T004 outcome flags (alias table or T005 rewrite).
2. Ylva = Yura's **cousin**, not sister — correct at T002/npcs.json NPC_T002_07 and the Ylva stable line.
3. Fix union.md: Durm is Windrest, not Stoneford; the un-hammerable lump is on Durm's shelf.
4. Register 22+ quest-item IDs in items.md.
5. Add D001 Mossbarrow access node to T001 town_map.json.

## Unreconcilable rewrites
None. All blockers are surgical edits to JSON flag-strings, one markdown factual correction, an items.md append, a town_map node addition, and a cousin-vs-sister word swap. No town or dungeon design needs fundamental reconstruction. The Wave 4a refinement quality is high; the gaps are wiring and registry, not narrative.
