# The Union — The Honest-Weight Guild of Caul & Sons

## Snapshot

The Union is not a crown and has never been one. It is a confederation of nine merchant houses, seven port-guilds, and a chartered Exchange at Greyharbour, held together by contract, ledger, and the Twelve Honest Weights. Its people are the most mixed-blooded in the Reach, its cloth is russet and ochre and slate, and its Consul-Merchant drinks from whatever cup is put in front of him and writes the price of it on a wax tablet in his sleeve.

## Governance

The Union is governed by **the Exchange** — a standing assembly of one hundred and twenty seats at Greyharbour, one seat per chartered house or guild, the rest appointed by rotation from the port-towns. The Exchange meets on the first and fifteenth of every month. It does not adjourn for weather, war, or mourning. It has not missed a sitting in seventy-one years.

The Exchange elects, from among its own, a **Consul-Merchant** — a single executive officer whose term runs nine years. The current Consul-Merchant is **Tobiah Caul**, of Caul & Sons, now in the seventh year of his first term. Tobiah was elected because Caul & Sons pays its dockhands on the day and because Tobiah laughs at his own jokes in a way that dockhands find reassuring. He was not elected because anyone thought him a statesman. He has, by accident, become one.

Below the Consul-Merchant sit the **Twelve Senior Weights** — the heads of the nine merchant houses and three elected port-guildmasters. They meet weekly at the Consul's table. A matter is decided by counted vote; ties are broken by the Consul. Tobiah has cast three tie-breakers in seven years and has explained each one, in writing, to the full Exchange the following week.

Arbitration between houses is by **the Honest-Weight Court** — three Senior Weights seated in rotation, hearing disputes under written contract, reading aloud every clause that bears on the matter. Judgement is written, sealed in wax, read aloud, and posted on the Exchange wall for thirty days. An appeal may be filed within that thirty. After the thirty, the ruling is a thing the ledger has swallowed, and the ledger does not give back.

Execution is rare and is carried out by **the dock-rope**. A condemned man is hanged at dawn on the main pier at Greyharbour, the charge read aloud in common northern, the weight of his broken contract read aloud in silver. The body is cut down at the first tide and the family is permitted to claim it. The Union has hanged seven men in Tobiah's term. Tobiah has attended every hanging. He writes each one down, with the weight, in a small book he keeps in his bedside drawer.

## Bloodline / race

The Union is the most diverse population in the Reach and is proud of this in a shy, numerical way — a Union census is a list, not a boast. Greyharbour alone hosts Ashcrown southerners (dockhands and bakers, mostly), Free-North clansfolk (stevedores and rope-masters), Faith-born orphans (clerks and pilgrims' innkeepers), hill-blooded east-country folk (mule-drivers and charcoalers), and a thin persistent layer of far-coast fisher-families whose accents have survived three generations of marriage.

A Union child's bloodline is not tracked. A Union child's **guild of first service** is tracked — the first guild to sign the child's papers at twelve. This replaces, for all social purposes, the Ashcrown's House-stamp or the Free North's clan-name. A Caul clerk, asked where she is *from*, will answer *Caul & Sons*, not the valley she was born in.

The Union teaches, in its apprentice-halls, that **blood is what you eat with; paper is what you sign with**. Mixed marriages are the norm and not remarked upon. A Union apprentice-hall will, in its first-year curriculum, pair apprentices across house-of-origin on purpose.

There is no Union claim to elven, dwarf, or any other lineage, and no interest in such claims. The Consul-Merchant's own family, Caul & Sons, traces itself to a ship's cook four generations back who married a Free-North rope-master's daughter and opened a salt-fish shed at Stoneford. Tobiah tells this story at dinners. He tells it with the prices.

## Economy

The Union *is* an economy with a flag stapled to it. Its primary trades are **salt-fish, finished iron goods, paper, grain transshipment, and credit**. Salt-fish runs the northern coast and inland to the cathedral towns; finished iron — the Union forges mill Free-North ore into nails, hinges, pots, plough-blades, and sells them to every kingdom — is the Union's most profitable weight. Paper and credit are the quiet engines. The Union mints no coin but issues **Exchange-paper**, letters of credit drawn on the Greyharbour Exchange, accepted in every major port and most inland towns at face weight.

Every Union transaction is recorded. The Exchange maintains a **Central Ledger** at Greyharbour — a room with a lock of nine keys, each held by a different Senior Weight — and local ledgers at every chartered port. A contract not in the ledger is not a contract. Union merchants travel with sealed copies of their own ledger-leaves and will, at the end of a meal, show the host the weight of what was eaten. This practice is called **reading the table**. It is considered the highest form of courtesy. It is considered, by every other culture in the Reach, an embarrassment.

Tax is **the Honest Tithe** — a flat fractional levy on every recorded transaction, one part in forty. It is collected at the point of sale by the buying guild's clerk. Uncollected tithe is an uncollected debt, and the Union has no mechanism for forgiving debt other than writing it off in a posted notice the defaulter must countersign. Union tax evasion is not common. It is, when it happens, social suicide.

The Union's currency in practice is **Ashcrown royal silver** for large weights, **Union Exchange-paper** for merchant-to-merchant, and **Honest-copper** — thin copper discs stamped with the Exchange's crossed scales — for dockhand pay and daily small-purchase. Faith cathedral-copper is accepted but discounted. Free-North blood-coin is accepted on personal trust only.

Caul & Sons' warehouses run from Stoneford up the coast to Greyharbour and inland to Mistmere. Tobiah has twelve weight-clasps on his merchant-chain. Most Union-folk wear three or four. Twelve is unusual and is not worn casually. A man with twelve clasps has, by the Exchange's definition, taken twelve separate public oaths to weigh honestly, and has kept them for more than a decade each.

## Food

The staple is **salt-fish and barley-bread**, eaten with a small dish of pickled vegetables and a cup of thin beer. Salt-fish is the Union's own product and its own pride; a Union hearth serves salt-fish at least three meals a week, and a Union mother who cannot cure her own fish is considered to have married badly.

Feast food is **the long ledger** — a meal served in numbered courses, each course announced by the host by name and price. *Course one: pickled cabbage, two coppers the head. Course two: salt-fish in vinegar, three coppers the portion. Course three: roast mutton, eleven coppers the joint.* The announcements are not about cost; they are about honesty. A Union feast-guest is expected to thank the host not for the generosity but for the *accuracy*. Faith-folk find this disturbing. Crown-folk find it vulgar. Free North-folk find it baffling. Union-folk find it the only sane way to eat.

Travel food is **ship's biscuit and cured fish**. Ship's biscuit is a hard barley cake, double-baked, that keeps for three months in a dry hold. Union couriers carry a week's ration in an oiled leather satchel, with a leather bottle of thin beer.

Sacred food does not exist in Union life in any strong form. The nearest equivalent is **the apprentice's loaf** — a plain white-flour bread baked by every guild on the day it swears in its new twelve-year-old apprentices. The loaf is shared between the apprentice and the first-weight who takes responsibility for her. It is eaten once per apprentice, once per year.

Forbidden food is not a Union category. Union-folk will eat anything they have paid for. A Union merchant at a Free-North hearth will eat the blood-sausage, note the price it would fetch in Mistmere, and thank the host for the weight. A Union merchant at an Ashcrown court will refrain from the nine dishes only if she is not offered them, and will take notes if she is.

## Dress

Daily dress is **merchant's doublet** in muted colours — russet, ochre, slate, muted green — cut generously for movement, belted at the waist, with a short jacket or cape for weather. Trousers are plain, boots are good but not polished. Hair is short but not southern-short. A Union dockhand wears a shorter coat; a Union clerk wears a longer one.

Ceremonial dress is **the Exchange coat** — a long coat in the house's own colour, with the merchant-chain worn over the chest. Each clasp on the chain is a weight the merchant has publicly pledged to weigh honestly. The chain is worn at all formal sittings and at all Exchange business. Tobiah has twelve clasps; most Union-folk have three or four; a new Senior Weight may have only one.

Military dress does not exist as a Union institution. The Union has dock-wardens (harbour police), caravan-guards (private, hired by the merchant house), and the **Exchange Watch** (Greyharbour's own constabulary, forty men, plain russet livery, short swords, no banners). None of these are dressed for war. The Union has not fielded a field army in its history.

Colours are russet, ochre, slate, muted green, and plain black for mourning. Deep red is not taboo — the Union will wear deep red at festival — but is considered a bit loud and is not worn at Exchange business. White is worn at weddings. Grey is avoided (it reads as Faith-adjacent and implies a vocation the Union does not have).

Fabrics are linen, wool, and — for senior merchants — a little silk at the cuff or collar. Silk is a Union luxury and a Faith taboo; a Union merchant dining with a Septa will, if well-coached, remove the silk cuff before the meal.

The merchant-chain's clasps are physical: small brass or silver medallions, each stamped with a weight the merchant has publicly pledged (e.g., *salt-fish honest to the pound*, *iron honest to the nail-count*, *paper honest to the signature*). A clasp can be ceremonially stripped in public if the Exchange finds a merchant has broken the weight. Tobiah's twelve clasps include *salt-fish*, *cured meat*, *linen*, *finished iron*, *paper*, *timber transshipment*, *credit*, *coin-weight*, *contract-oath*, *courier-seal*, *warehouse-custody*, and *private collection* — this last is the one the three other crowns will, at the summit, quietly notice.

## Rituals & holidays

**Birth.** A Union child is registered at the nearest Exchange house within the first week. A clerk writes the child's name, the date, the parents, and the guild of first service (which is usually the mother's guild, unless the father's weighs heavier). The record is sealed with the Exchange's crossed-scales stamp. The child's first official act is a signature — the clerk guides the baby's hand around a small X on the page. This is held to be the child's first honest mark.

**Marriage.** The two parties sign a **marriage contract** at the Exchange, in front of two witnesses from each party's guild. The contract specifies the joining of weights — whose warehouse merges with whose, whose debts are assumed by whom, whose apprentices pass to whom in the event of death. The contract is read aloud, clause by clause, and both parties sign. A meal follows, with the dishes announced by price. Union marriages are unusually stable, which Union-folk attribute to *knowing what you signed*.

**Death.** A Union body is washed, dressed in the merchant's own Exchange coat (or, for a dockhand, the guild's plain russet), and buried in the Exchange cemetery with a small upright stone marker bearing name, dates, guild, and — distinctively — the final ledger-balance of the deceased, positive or negative. A Union grave is legible. A Union grave tells you, at a glance, whether the dead kept honest weight.

**Seasonal festivals** are three: **the Founding Day** (the midsummer anniversary of the Greyharbour Exchange's first sitting, with public reading of the Twelve Honest Weights, a market-day across every Union port, and a public hanging if any is pending); **the Ledger Closing** (midwinter, when every Union house closes its annual books and settles its tithe, followed by a feast that is famously over-ordered and famously accurately-priced); and **Apprentices' Day** (early autumn, when new twelve-year-olds are sworn into their first guilds; the apprentice's loaf is baked and shared, and parents weep).

**Military oaths** do not exist in the Union repertoire. The Union swears **contract-oaths** and **courier-oaths** and **warehouse-oaths** and — most weightily — the **house-word oath** (see below). A Union merchant has never, in the Exchange's records, sworn a blood-oath.

## Oath forms

The Union swears **by Honest Weight and Honest Word**. The full form is: *"On the weight of my house, on the word of my guild, on the ledger that records this day — I swear this clause is the clause I will keep."* The oath is always sworn against a specific written clause. A Union merchant does not swear abstractly. She swears *this sentence, as written*.

Oaths are sworn on **the signed contract** (everyday), on **the merchant-chain** (season-weight), or on **the house-word** (life-weight). The house-word oath is the highest Union oath: the merchant swears on the continued existence of her own house, and if she breaks the oath the Exchange dissolves the house, strips its charter, and redistributes its warehouses among the remaining houses. A house-word oath has been sworn forty-one times in Exchange history and broken four. Three of the breaking houses no longer exist. The fourth is a cautionary tale told to apprentices.

The penalty for breaking a contract-oath is **double restitution plus the stripping of one clasp** from the merchant-chain in public. The penalty for breaking a season-oath is **the stripping of the full chain** and exile from the Exchange floor for one year. The penalty for breaking a house-word oath is **dissolution of the house**.

The idiom *he owes a clasp* means a merchant has a pending contract breach and the Exchange is aware. The idiom *the chain is heavy this year* means a merchant has taken on many new public oaths (usually said with approval). The idiom *read the table* is the literal Union practice of announcing prices at a feast, and is also used to mean *lay out the terms openly*. The idiom *honest to the nail-count* is the highest praise a Union merchant can give another — it means *she weighs what she sells down to the smallest unit and loses money if the weight requires it*.

Tobiah's personal house-words are **"Honest Weight, Honest Word."** These are stamped on every Caul & Sons crate, painted on every warehouse door, and embroidered on the cuff of his Exchange coat. They are, in the summit at Mistmere, the words the Ashen Herald will use against him as a rhetorical trap.

## Law & punishment

Union law is **written, posted, and read aloud**. The Twelve Honest Weights are the Union's constitution; beneath them sit the chartered guild codes; beneath those sit the individual contracts. Every Union subject can read (apprentice-halls teach letters at twelve), and every Union subject is expected to know, at minimum, the Twelve Honest Weights by heart.

Union courts are the Honest-Weight Court (inter-house disputes), the Dock Court (public-order cases at the ports), and the Apprentice Court (disputes involving guild apprentices under twenty-one). Each court keeps a written record. Each judgement is read aloud at sentencing and posted on the Exchange wall for thirty days. There is no oral judgement in Union law.

Common crimes: **false weight** (selling less than the contract's stated quantity), **paper-forgery** (altering an Exchange-paper), **warehouse-breach** (stealing from a bonded warehouse), and **contract-abandonment** (walking away from a signed agreement). Sentences run: double restitution, ten years' loss of charter, dock-rope, and dissolution of house, respectively.

A Union subject fears the law as **the ledger that does not lose**. Union law is slow, public, and absolutely memoried. A false weight sold in Stoneford twenty years ago will, if the ledger survives, still be a false weight sold in Stoneford twenty years ago. Union-folk do not flee their debts; they settle them, even a generation late.

The Union's most feared punishment is **the stripping of the chain** — the public removal, clasp by clasp, of a merchant's oath-medallions on the Exchange floor, each clasp named aloud as it comes off. The stripping takes as long as it takes. A twelve-clasp stripping, like Tobiah's would be, would last over an hour. No such stripping has ever occurred at the Consul-Merchant level. The threat is real.

## Military style

The Union has no standing army. Its security forces are **the Exchange Watch** (Greyharbour's constabulary, forty men), **the Dock Wardens** (port-town harbour police, house-funded, varying strength), and **caravan-guards** (private mercenaries, usually Free-North hire, paid by merchant contract).

Doctrine, such as it is, is **the insured line** — the Union does not fight wars; it buys insurance. If a caravan is at risk, the merchant house pays a Free-North war-band to escort it. If a port is at risk, the Union pays the Ashcrown to station Linden foot at the harbour for a season. The Union has, in its Exchange records, paid for three separate wars it never fielded a man in. It considers this a successful foreign policy.

Unit types are the **Exchange Watchman** (short sword, russet livery, club, short-bow), the **dock warden** (short club, whistle, no blade), and the **caravan-guard** (contracted, varies — usually Free-North axe and bow, occasionally Ashcrown crossbow). The Union's own Exchange Watch has fought one pitched engagement in eighty years, against a Stoneford grain-riot, and lost it. The merchants paid restitution, amended the grain-contract, and the riot ended.

Weapon preferences are the **short sword**, the **crossbow** (a Union innovation, manufactured in the Greyharbour iron-forges and sold to every kingdom), and the **ledger** (literal — the most powerful Union weapon is a sealed contract entered into the Central Ledger). The Union does not use the great-axe (a Free-North weapon) or the long spear (an Ashcrown weapon). It will not issue arrows without a written requisition.

Tobiah Caul has never held a weapon more dangerous than a letter-opener. He is not expected to. A Consul-Merchant who took the field would be impeached within a week.

## Religion / metaphysics

The Union has no official religion. It has **civic decency** — a set of shared behaviours that approximate a faith without naming any gods. The Twelve Honest Weights are the nearest thing to scripture; the Central Ledger is the nearest thing to a sacred text; the Exchange floor at Greyharbour is the nearest thing to a temple. Union-folk will swear by the weight, by the word, and by the ledger. They will not swear by any named god.

Private belief is widely varied. Many Union-folk pay tithe to a Faith cathedral (especially in the cathedral towns); many Union-folk keep a small grey stone at the hearth out of habit; many Union-folk attend Free-North clan-feasts if married into a clan. The Union does not object to any of this. It objects only to proselytising at the Exchange, which is considered a breach of civic decency and is fined two silver per incident.

The Union's folk-practice is **the counting-prayer** — a small private habit, often seen in Union children, of counting coins, clasps, or knots on a rope while worried. It has no theology. It is a comfort.

The Union's relationship to the Fog is **practical**. Fog is bad weather; bad weather is a logistics problem; logistics problems are handled by insurance. Union merchants carry a small iron bell when travelling through fog-valleys, not for spiritual reasons but because bells reduce collisions in poor visibility. If asked, a Union-folk will say she does not believe in the Fog being *anything*, and will then quietly note that she still rings the bell.

## Language & address

The Union common tongue is **plain northern merchant-speech** — a pragmatic dialect of common northern with heavy loan-words from Ashcrown southern, Free-North Norhald, and Faith cathedral-tongue. Union merchants pride themselves on plainness: they use contractions, use the first person freely, use numbers and weights in everyday speech, and dislike metaphor. *"I would like to be told. I would like to be told honestly."*

A Union subject addresses a fellow merchant as **Consul** (if Senior Weight or above), **Master** (if guild-master), or by given name and house (*Caul of Caul & Sons*, *Veld of the Greyharbour ropers*). Apprentices are addressed by given name only; this is a mark of their probationary status.

A Union subject addresses an Ashcrown lord as **Your Grace** with a small bow (never a kneel — the Union has no kneeling culture; a Union merchant's knee is for bracing a crate, not for a floor). A Union subject addresses a Septa as **Holiness** with a small bow. A Union subject addresses a Free-North chieftess as **Hearth-mother** or **Chieftess**, usually the latter in formal sittings.

A Union subject addresses the Ashen Herald — if she ever arrives at a Union house, which has not yet happened — by no address. The Herald has written no name on her slate, and the Union, in the absence of a written name, has no form to use.

Idioms:

- *Honest Weight, Honest Word.* Caul & Sons' house-words; also a standard greeting and closing among Union merchants.
- *Read the table.* Announce the prices at a meal; lay out the terms openly.
- *Honest to the nail-count.* Highest praise. Absolute precision of weight.
- *He owes a clasp.* A pending contract breach noted by the Exchange.
- *The chain is heavy this year.* Said of a merchant taking on many public oaths. Approving.
- *The ledger does not lose.* An old debt will still be collected. Warning.
- *A brass cup buys a brass wine.* A Union proverb meaning *you get what you pay for* — now, under Tobiah's term, a phrase he cannot hear without a small unexplained chill.

## Attitude towards the other four cultures

**Crown.** The Union respects the Ashcrown's stability and its silver. The Ashcrown's coin is the Union's preferred large-weight currency, and the Union has never issued a complaint against the royal mint. The Union is, however, quietly annoyed that the Ashcrown will not sit a merchant at the Morning Table. Tobiah has been called to the Morning Table twice in his term and has been received politely, fed nothing, and sent home. He does not hold this against Darrik Voss personally. The house does.

**Faith.** The Union respects the Faith's septons and is mildly baffled by the Faith's refusal to write things down. A Union merchant who tithes at a cathedral will receive a blessed stone, and the Union — as a matter of civic decency — will list the stone in the merchant's will as an asset of sentimental value, weight ungiven. The Union finds the Faith's unwritten judgements a legitimacy risk and prefers not to have its contracts heard in the Septa's chair.

**Free North.** The Union values Free-North labour, iron ore, and wool, and pays honest price for all three. Tobiah personally likes Free-North clansfolk — they are, he says, the only people in the Reach who will sit through a full reading of a contract without fidgeting. The Union finds the Free-North blood-coin system inconvenient and politely refuses it for large transactions. Union merchants are the only southerners who ever correctly pronounce *hearth-mother*.

**Fog.** The Union does not recognise the Fog as a culture. The Ashen Herald is, in the Union's Exchange records, filed under **unregistered correspondent** — she has sent letters, they have been read, they have been filed, no reply has been issued. Tobiah has received one letter from the Herald, personally, three years ago. He read it, showed it to his senior clerk, and filed it. He does not remember its contents. His clerk does.

## Attitude towards the Chasm & Depth-Walkers

Public stance: **the Chasm is a geographical feature**, unprofitable, unbridgeable, and therefore not a Union concern. The Depth-Walkers are a northern order that occasionally passes through Union ports buying rope and lantern-oil. The Exchange has a standing contract with the Listener order for rope-supply; the contract is renewed every seven years and has been uneventful.

Private suspicion: **Tobiah Caul has none**. He does not know the colonial history. He does not know what is in the brass cups. He does not know that Caul & Sons warehouses hold, at this moment, nine objects his grandfather bought at estate-sales sixty years ago believing them to be antiques of unknown provenance. He does not know that the unaging tea he has seen Darrik Voss drink is the same substance his own ledger records as *amber leaf, foreign, value unknown, three silver the pound*.

Tobiah's ignorance is canon. Tobiah's merchants, beneath him, have begun to notice things — the clerks at the Jadehollow branch have flagged the brass cups as a curiosity, the Windrest blacksmith Durm has on his shelf an un-hammerable metal lump logged as *iron, refuses forge, value in dispute*, and the Mistmere branch has received a cathedral inquiry about a consignment of grey stones. None of this has yet reached Tobiah's desk. Some of it will, in the season after the summit. Some of it is being held back by Senior Weights who are beginning, privately, to wonder whether the Consul-Merchant should be told.

The Union's policy on Depth-Walkers is **supply, do not judge**. The Union sells rope and oil to Listeners and Crossers alike. The Exchange has, in writing, no stance on the schism.

## Storyline hooks

Named NPCs from this culture:

- **Consul-Merchant Tobiah Caul** (T005, Line C soul — Union kingdom seat, dangerously ignorant)
- **Tobiah's senior clerk** (T001 cameo, T004 by ledger — has filed the Herald's letter and is the keeper of the Jadehollow inquiry)
- **Caul & Sons dockhands** (T001 — ambient, report on the dockside chase in Line C)
- **Caul & Sons warehouse clerks at Jadehollow** (T004 — Hawke, existing NPC_T004_08, has the brass-cup trail)

Storyline beats that rely on this culture's norms:

- The brass cups (Line C T005) — twelve vessels bought by Tobiah's clerks sixty years ago as antiques, at three silver the lot. Nine are still in the Stoneford warehouse. Three are in Mistmere, one of them on the summit table in front of Tobiah. The cups are the Union's accidental evidence. Their provenance is recorded in a Union ledger. Tobiah has never read the entry.
- The honest-weight toast (Line C T005) — Tobiah's small improvised speech at the summit opening, *"The Union is — honoured to be asked. We will do our honest best to deserve the asking,"* is a Union signature on a blank document. The three other crowns read it correctly: the Union will oath-bind to terms it has not seen, because the Union does not suspect the terms hide anything.
- The wax tablet in the sleeve (Line C T005) — Tobiah comes prepared to take notes at the summit. He does not realise this is improper. When Brenna warns him, he reaches for the tablet before he reaches for the clan-knife response, because his first instinct is to record, not to defend.
- The crate-manifest with item 47 (Line C T001) — *"twelve brass cups of antique foreign manufacture, sold to Consul-Merchant's private collection, three silver the lot"* — a Union clerk's honest entry, which will, across the five towns, be the thread the player follows to the colonial-history edge. The entry is not hidden. It is posted on the Exchange wall in the thirty-day rotation and then filed. A Union merchant would consider its concealment dishonest.
- The twelve clasps on the merchant-chain (Line C T005) — physical proof of Tobiah's twelve public oaths. The twelfth clasp, *private collection*, is the one the three other crowns will silently notice at the summit. It is the only honest-weight pledge in the Exchange's records that covers an unknown provenance. Tobiah pledged it because his grandfather taught him a merchant pledges honesty on what he owns, known or unknown.

Idiosyncrasies a town writer must preserve:

- Union NPCs do not kneel. The Union has no kneeling culture. A Union merchant's knee is for bracing a crate against a ship's rail, not for a floor. A small bow is the deepest respect a Union-folk will offer.
- Union NPCs announce prices. A Union host will read the table at any formal meal. Other culture NPCs should register this as charming, vulgar, or baffling depending on their own voice, never as normal.
- Union NPCs write things down. A Union merchant at any formal sitting will have a wax tablet, a small ledger, or a sealed slip of paper on her person, and will reach for it unconsciously when asked to remember something.
- Union NPCs swear on signed clauses. A Union NPC asked to swear abstractly will ask for the clause first. If no clause is offered, the Union NPC cannot swear — not *will not*, *cannot*, because a Union oath requires a written object.
- Union NPCs pay their tab. A Union NPC offered hospitality will, at the end, attempt to settle the weight. Refusing the settlement is a social breach in the Union's direction. Accepting it graciously is the Faith or Free-North manner. Writers should have Ashcrown NPCs stiffen politely at the attempt.
- The house-words **Honest Weight, Honest Word** are stamped on every Caul & Sons crate, painted on every warehouse door, and embroidered on Tobiah's cuff. They are the most legible Union iconography in the Reach and should appear as ambient detail in any Union-adjacent scene.
- Tobiah laughs at his own jokes. He explains why they are funny. He is loved by his clerks for this. No Ashcrown royal and no Septa has ever found him charming. Brenna, privately, does.

<!-- writer-only
## Inner circle knowledge

Tobiah Caul knows nothing of the colonial history. This is canon (SHARED_BRIEF §24) and is the engine of Line C's summit. The following notes are for writers; none of this knowledge exists inside Tobiah's head at the moment of the summit.

1. The brass cups. Caul & Sons acquired twelve brass cups sixty-one years ago at an estate sale in the old Deepvein liquidation. The seller was a clerk closing out a minor holding; the invoice is in Caul & Sons' Stoneford ledger, entry 1174 of volume XXXI, under *antique foreign manufacture*. Three silver the lot. Tobiah's grandfather signed the purchase. Tobiah has never read the entry and does not know the cups exist in his inventory until Brenna names them at the summit.

2. The amber leaf. Caul & Sons has, in its Mistmere branch, a small consignment of dried amber leaves logged as *foreign leaf, unknown plant, three silver the pound, private collection*. The leaves were a gift to Tobiah's father from an Ashcrown grain-merchant in the previous generation, ostensibly as a thank-you for a timely grain-shipment. The Ashcrown merchant was a Voss cousin. The gift was, in Crown terms, a deniable sample. The leaves have sat in a warehouse for thirty years. Tobiah does not know they are there.

3. The un-hammerable metal. Four years ago, a small iron ingot purchased from a northern moor-miner via a Free-North intermediary was sent on to Windrest for assay. The Windrest blacksmith Durm was contracted to test the metal for forge-work. Durm returned a note: *metal refuses forge, no crack, no flow, value in dispute*. The ingot still sits on Durm's shelf at Windrest, never returned to Caul & Sons. The Caul link is oblique — recorded only in a Bruno-of-Stoneford resale attempt (T001 NPC008). Tobiah has not seen the note.

4. The Herald's letter. Three years ago, a letter arrived at Tobiah's desk bearing a four-knot seal with an empty centre. The letter was in the Union's own merchant-cipher, which Tobiah found curious. Decoded by his senior clerk, the letter read: *"Consul-Merchant. You have bought a cup that is older than your house. Ask the man who sold it to your grandfather. Ask him what his grandfather's grandfather drank from."* Tobiah read the letter, showed it to his senior clerk, laughed nervously, and filed it. His clerk filed it under *unregistered correspondent, sentimental value*. The letter is still in the Greyharbour Central Ledger's personal file under Tobiah's name. Tobiah has forgotten it. His clerk has not.

5. The Union's accidental role in the colonial-history leak. Because the Union does not hide its ledgers, and because Union clerks have, beneath Tobiah's notice, been filing honest entries on brass cups, amber leaves, un-hammerable metal, and grey stones for six decades — the proof of the colonial history is, at this moment, the most publicly-documented secret in the Reach. The only reason no one has connected the entries is that no one outside the royal circles knows what the entries are entries *of*. The Ashen Herald has read them all. The Crown has been paying Union clerks a small private stipend for thirty years to lose the entries in the system. The stipend has not worked, because Union clerks accept the coin and file the entry anyway — *honest weight, honest word* is a discipline, not a bribe target. The Crown does not know this discipline is winning.

6. Writers may not place any moment of self-knowledge in Tobiah's scenes before the summit. He does not suspect. He is broad, red-cheeked, fifties, cheerful, and his internal monologue — if represented — is entirely about the price of things, the weight of things, and whether his clerks are eating well. Tobiah's ignorance is the canon lever of Line C's endpoint set; it is not to be softened.

7. After the summit — depending on endpoint — Tobiah will either remain ignorant (Endpoints 1 & 2), be warned by Brenna and begin investigating (Endpoint 3), withdraw the Union from the four-crown frame and begin a full audit of his warehouses (Endpoint 4), or — in Endpoint 5, if the player has taken the Fog path — be permanently bound to an oath he does not understand, because no one stood for the Union at the table. Writers for later acts must preserve this branching.

8. Tobiah's senior clerk. An unnamed figure in the storylines so far, but canonical: female, mid-forties, Stoneford-born, Caul & Sons employee of thirty-two years. She has been filing the incriminating entries into the Central Ledger without comment for twenty years. She knows. She has never told Tobiah. She considers it her job to keep the ledger honest, not to explain it to the Consul. She will, after the summit, begin to consider telling him. Writers may develop her in T001–T004.

9. The vocabulary used inside the Greyharbour Exchange's senior circle — among the Senior Weights who have begun to suspect — is careful and non-modern. They say *the foreign consignments*, *the older merchandise*, *the items of unclear provenance*, *the entries that will not settle*. They do not say *colonial*, *far-side*, or *relic*. None of these Senior Weights know what they are looking at; they only know the ledger has a pattern. Three of them have asked Tobiah, obliquely, whether the Consul wishes to open a review. Tobiah has declined each time, because the items are filed and the items are small. This refusal is the Union's contribution to the cover-up, made in ignorance.

10. The Union's endpoint, whichever it lands on, will determine whether the Union becomes the destabilising force of the following decade. Endpoint 4 (the walkout) is the most destabilising. Endpoint 3 (Brenna's warning held) is the slower burn. Endpoints 1, 2, and 5 bind the Union into silence. Writers for later acts should treat the Union's post-summit state as the central foreign-policy question of the Reach's next generation.
-->
