# The Free North — The Clans of the Brokenspine

## Snapshot

The Free North is not a kingdom in any southern sense. It is a standing agreement between twenty-three clans of the Brokenspine, the Greyhold valleys, and the upper moors, who decide every matter at the hearth and swear every oath on the forearm. Its folk are broad-boned, mountain-blooded, and their chieftess carries armour inlaid with a pale line of metal no smith in the Reach can hammer.

## Governance

The Free North has no throne. It has **the Hearth** — a rotating seat of common decision, held at a different clan-hall each winter. The current Hearth is Greyhold, seat of Chieftess **Brenna Greyhold**, and has been for the last fourteen years, which is unusually long. The clans have chosen not to rotate because Brenna has not failed them and because the alternative (contesting her) would require a blooding.

Each clan is led by a **chieftess** or **chieftain** (the title is not gendered in the clan-tongue) chosen by acclamation at the clan's autumn gathering. The chieftess holds the seat until she voluntarily steps down, until the clan withdraws acclamation, or until she is blooded on the Circle.

The twenty-three chieftesses together form **the Circle** — an assembly that meets at the winter solstice at whichever clan holds the Hearth. Each chieftess speaks in turn, longest-seated first. No chieftess may interrupt another. A matter is decided when every chieftess has spoken, and the matter is decided by *hearth-count*: each chieftess names the answer she will take home and defend to her clan. If nine or more stand alone with a minority answer, the matter is held over to the next winter. If fewer than nine, the majority carries.

Power transfer is by acclamation or by **blooding**. An acclaimed chieftess steps down when she no longer holds her clan's voice; a blooded chieftess is the result of a formal challenge — single combat to first blood, not to death — on the Circle's threshold. Blooding is rare. Brenna has never been blooded.

Arbitration between clans is by the Hearth-holder. The Hearth-holder has no executive power in peacetime but may call the Circle into session on any matter she declares *clan-threatening*. Brenna has called three such sessions in fourteen years.

Execution is **the drifting boat**. A condemned person is given a small boat, a jar of water, a loaf of stone-bread, and a single oar, and pushed into the Grey Sea from a named beach at dawn. The boat drifts. The Free North does not take a life directly; it lets the sea take one.

## Bloodline / race

The Free North is **dwarf-blooded and mountain-blooded**. The clans trace descent not to kings but to three legendary foremothers: **Greyhold the Stone-walker**, **Karn the Axe-hand**, and **Vilda the Long-breath**. Each foremother is said to have carried a strain of mountain-folk blood — shorter stature, broader shoulders, denser bone, a capacity for heavy labour at high altitude.

Physically, clansfolk are shorter than Ashcrown southerners and broader across the chest and shoulder. They grow slower and live hard. A Free-North forty-year-old woman can out-lift a Union stevedore of twenty. Their hair runs pale in the high valleys, darker in the lowlands; eyes are grey or the distinctive pale-blue of the Greyhold line.

The dwarf-blood is **tradition, not magic**. The clans do not claim supernatural ancestry. They claim a mountain-dwelling people — called in the clan-tongue *steinfolk*, *stone-folk* — interbred with the early clans six or seven generations back. The steinfolk themselves are said to be gone now, withdrawn to the upper ranges. No steinfolk has been seen in living memory. The chieftess-line of Greyhold carries the strongest stone-folk blood; Brenna has the broadest shoulders of any woman in the Circle.

Interbreeding attitudes: the clans welcome outsider marriages but require a **hearth-year** — the incomer lives with the clan for one full year before marriage, and must prove work at forge, kiln, or lamb-pen. Mixed children are clan-children, no distinction. A Free-North clan does not track pure blood; it tracks hearth-service.

## Economy

The Free North produces **wool, iron, and timber**. Wool from the high pastures (heavy, long-fibre, the best in the northern lands); iron from the Brokenspine's surface ores (inferior to Union mined iron but honest metal); timber from the slow-growing upper pine forests (prized for ship-keels and cathedral-beams).

They trade with the Union (wool for iron tools and finished goods), with the Ashcrown (timber for grain), and with the Faith (wool for cathedral candles and blessed stones). The clans do not trade with the Fog, but fogged travellers are given a meal and a bed at any clan-hall without question.

Tax is paid in **hearth-service**. Each clan sends one son or daughter per generation to the Hearth-holder's valley for a year's labour — forge, lamb-pen, harbour-work, depending on need. This is not taxation in a Union sense; it is a circulation of hands. A clan that fails to send its year's hand loses speaking-order at the Circle.

Currency: the clans distrust minted coin. They prefer **blood-coin** — a small iron disc stamped with a clan's sigil and given as a record of debt. A blood-coin is owed, not spent. Ashcrown silver is accepted at the coast and the Union paper is accepted in trading-towns; neither is trusted inland. A clansman travelling south carries a pouch of silver; a clansman travelling valley-to-valley carries no coin at all.

## Food

The staple is **blood-sausage and hard cheese**. The sausage is made from the autumn cull — sheep's blood, fat, barley, salt, and hill-thyme — stuffed into gut, smoked in the rafters for three weeks. A clan-hall hangs forty at the solstice. The cheese is a hard goat's-milk wheel aged in stone cellars for eighteen months.

Feast food is **the long table**. At a clan-feast the table is set the length of the hall, and the meal comes in waves: first the blood-sausage and cheese (always), then a roast (mutton, goat, or on great occasions a whole deer), then hill-root stew, then the **clan-ale** drawn from a single cask opened only at feast. The final dish is always a plain barley porridge with a spoon of honey — a reminder that the clan began poor and will end the same.

Travel food is **hardtack and wind-meat**. Hardtack is a barley biscuit baked hard; wind-meat is mutton cured by hanging in the high-valley wind for two months. A clan scout carries both, and water in a waxed leather bladder.

Sacred food is **the hearth-root** — a small pale tuber that grows only at altitude, cooked in ash at the clan-hall's own hearth, eaten only at birth-namings and death-vigils. Each clan keeps its own hearth-root patch, and the patch is said to die if the clan fails.

Forbidden food is **the grey fish** — a pale cave-fish from the Depth-Walker tunnels. The clans will not eat fish that have not seen the sun. A clansman offered grey fish at a Mistmere table will push the plate away without comment.

## Dress

Daily dress is **leather and oiled wool**. Men and women both wear a hooded tunic to the thigh, trousers cross-laced at the calf, boots of seal-leather (coast clans) or goat-leather (inland). Colours are undyed brown, dark grey, and the deep blue of the clan-dye, which comes from a hill-moss unique to the northern valleys.

Ceremonial dress is **the clan-plaid** — a long woven cloak in the clan's pattern, pinned at the shoulder with a bronze brooch shaped to the clan sigil. Each clan has its own plaid; Greyhold's is dark grey and pale blue in a narrow check. A chieftess adds a **forearm-band**, a thick leather cuff with the clan's history worked in pale metal inlay.

Military dress is **dark leather and inlaid plate**. Clan-warriors wear hardened leather at the chest and shoulder, with iron or (for the chieftess-line) **pale inlaid metal** — the unhammerable metal — worked in straight lines across collar, shoulder, and vambrace. The inlay is never for decoration; it is for cuts the leather would not stop.

Colours: brown, grey, pale blue, and the specific dark blue of clan-moss. Dyed red is taboo in the field (it marks a warrior for the other side's arrows). White is worn only at death-vigils.

The taboo: **no clan wears another clan's plaid**, not even in jest. A clansman caught wearing a rival clan's pattern is challenged on sight.

## Rituals & holidays

**Birth.** The child is held to the clan-hearth by the clan's eldest woman, and a drop of the hearth-root ash is pressed into the child's navel. The child is named by the mother only; fathers do not name children in the Free North.

**Marriage.** The two parties stand at the clan-hall's threshold, each with a forearm bared. The clan's eldest woman draws a shallow cut on each forearm with a clan-knife, and the two forearms are pressed together and bound with a strip of clan-plaid. The binding is left for a full day. When unbound, the two scars form a single mark that both parties carry for life. Marriages are marked in the skin, not on paper.

**Death.** The body is washed in the clan's well-water, wrapped in the clan-plaid, and either burned on a high pyre (for a chieftess or clan-warrior) or laid in a stone cairn on the clan's own moor (for common clansfolk). Names are cut into the cairn's capstone. The cairn is visited every solstice and the name is spoken aloud; a cairn that goes unvisited is said to be *a dead name*.

**Seasonal festivals.** Two: the **winter Circle** (the great political gathering, austere, no feast beyond stone-bread and clan-ale) and the **summer Run** — a three-day foot-race across clan-moor and valley-ridge, open to any clansfolk who can run. The Run's winner takes a silver brooch and a year's precedence in speaking-order at the next Circle.

**Military oaths.** Sworn on the forearm with the clan-knife. The swearer draws his own blade across his own forearm, lets three drops fall on the ground, and speaks: *"Blood to ground, word to clan. If the word breaks, the blood goes with it."* The scar is a permanent mark. Free-North warriors of long service carry forearms like old leather.

## Oath forms

The Free North swears **on the forearm and on the hearth**. The full form is: *"By blood drawn from my own arm, by hearth at which my mother named me, by the plaid I wear and will be buried in — I swear this word."*

Oaths are sworn on **one's own blood** (highest), on **the clan-hearth** (medium), or on **the clan-plaid** (everyday). A blood-oath is life-binding; a hearth-oath is clan-binding; a plaid-oath is a day's binding.

The penalty for breaking a blood-oath is the drifting boat. For a hearth-oath, the clansman is denied hearth-service for a year — he eats outside the clan-hall, sleeps in the stable, and speaks to no kinsman. For a plaid-oath, the clansman's cloak is cut with the clan-knife in front of the clan, and he wears the cut cloak until it falls apart.

The idiom *his blood is on the ground* means he has sworn and cannot take back. The idiom *the plaid is cut* means shame, visible shame. The idiom *she eats outside* means she is serving a hearth-oath penalty.

Chieftess Brenna swears by pressing her own blood to the unbreakable metal of her vambrace. This is called **the pale-line oath** and has been sworn only by chieftesses of the Greyhold line. Brenna has sworn it twice in her reign. She will not say to whom or for what.

## Law & punishment

The Free North has no written law. Each clan keeps its own customary law, recited at the winter Circle by the clan's eldest woman. When customs conflict between clans, the Hearth-holder mediates; when mediation fails, the Circle decides by hearth-count.

Common crimes: theft from a clan-hall, striking a hearth-guest (a visitor under the clan's protection), breaking the hearth-oath, and trespassing on another clan's moor. The sentences are, respectively: restitution at double weight; exile from the clan for one year; hearth-oath penalty above; and a public beating at the offending clan's threshold.

A clansman fears the law as **the mothers who remember**. Free-North law is carried in the eldest women's memory; a wrong done to a clan is remembered for three generations, and it is the clan's mothers who will tell their grandchildren the offender's name. A clansman will take a physical beating before he takes a remembered shame.

The Free North does not execute by blade. The drifting boat is the only killing-sentence, and the clan that sentences it does not watch the boat leave. The sea is said to be the clan's judge; the clan is not the clan's judge.

## Military style

Doctrine is **raid and hold**. Clan-warriors do not field armies. They field **war-bands** of thirty to fifty, fast-moving, travelling in dispersed small columns, converging on a fixed hour. They raid, they take, they withdraw to prepared cairn-positions on high ground, and they hold until the enemy leaves. They do not hold line against disciplined infantry; they fade and re-appear.

Unit types: the **shield-pair** (two warriors bound by marriage-scar, fighting as one unit), the **axe-line** (five to seven warriors with great-axes, the clan's shock formation), and the **ridge-runners** (scouts and skirmishers, light leather, short-bow, long legs).

Weapon preferences: the **great-axe** (the clan's iconic weapon, four feet haft, heavy head, single-handed if the warrior is strong enough), the **long knife** (used for utility and, at close quarters, for killing), and the **short-bow** (for the ridge-runners; the Free North does not use the crossbow, which is considered a Union tool). Pale-metal inlaid armour is reserved for the chieftess-line and for named warriors of long service.

The chieftess is expected to fight. Brenna has fought in two Circle-called wars and one border skirmish. She wears her own scars visibly.

## Religion / metaphysics

Official belief is **the Hearth and the Stone**. There are no named gods. The clans believe that the clan-hearth is alive — it hears, it remembers, it can be angered. A hearth let to go cold without cause is said to *forget the clan*, and the clan then loses luck until a new hearth is kindled with a fragment of an older clan's flame.

The folk variant is **the stone-folk still walk**. Common clansfolk hold that the mountain-dwelling forefolk are not gone, only withdrawn, and that on the high moors at dusk a shepherd will sometimes see a short broad figure watching the flock and raise his cap to it in respect.

The Free North's relationship to the Fog is **indifferent**. The Fog is a weather. Clansfolk wait it out. They do not theologise it. A Fog-silenced pilgrim is, to a clansman, simply a man who lost his voice in bad weather. The clans do not share the Faith's edge-of-the-weave reading and do not share the Ashcrown's diplomatic wariness.

## Language & address

The clan-tongue is **Norhald**, a consonant-heavy language distinct from the common northern speech. Most clansfolk also speak common northern for trade. Oaths, funerals, and the Circle's formal speech are in Norhald; trade and ordinary conversation mix freely.

A clansman addresses a chieftess as **Hearth-mother** (or **Hearth-father**). A Circle-chieftess is **Elder Hearth** in formal speech. A common clansman is addressed by given name and clan-name: *Ylva of Stoneshield*, *Kjell of Greyhold*. No titles, no *lord*, no *sir*.

A clansman addresses an Ashcrown lord as **south-crown** (a slight diminution, a reminder that the Ashcrown is one crown among several). A clansman addresses a Septa as **Holiness** but does not kneel. A clansman addresses a Union merchant as **contract-folk** — not meant as insult, but perceived as cool.

Idioms:

- *Blood to ground.* A blood-oath has been sworn.
- *The plaid is cut.* Public shame.
- *She eats outside.* Serving a hearth-oath penalty.
- *The mothers remember.* A long shame will follow.
- *The stone-folk watch.* Old wrongness on the high moor; also used for moments of vertiginous recognition.
- *We came from the other side.* A child's rhyme in the Greyhold line; a lullaby, nothing more, to most clansfolk. Brenna knows better.

## Attitude towards the other four cultures

**Crown.** The Free North respects the Ashcrown's discipline and distrusts its closed rooms. Clansfolk view the Morning Table as a place where decisions are made in the absence of the people they affect. A clan proverb: *a table with four legs and only one chair speaks for one mouth, not four*. Brenna privately regards Darrik Voss as a man whose tea is more interesting than his politics.

**Faith.** The Free North accepts the Faith's septons as honoured guests and is cool to the Faith's High Septa. A clan will feed a septon and listen to his prayers; a clan will not accept a Septa's judgement over the clan's hearth-custom. Brenna has corresponded with Malen three times, warmly, and has not agreed to a single one of Malen's requests.

**Union.** The Free North views the Union as *useful, noisy, and unworthy of a clan-oath*. Union contracts are honoured in trade and ignored in principle. Clansfolk like Union merchants as people and distrust them as a culture. The nickname *contract-folk* is affectionate in a small way and dismissive in a large way.

**Fog.** The Free North does not distinguish Fog from weather. The Ashen Herald is regarded as a *walker-without-hearth* — a person with no clan, who therefore has nothing to swear on and whose word accordingly carries no weight. Brenna would not refuse to hear the Herald; she would refuse to take an oath from the Herald, and the refusal would be polite.

## Attitude towards the Chasm & Depth-Walkers

Public stance: the Chasm is the end of the walkable land, and going into it is a personal choice that brings neither honour nor shame. The Depth-Walkers are a northern order the clans have always known about and have never joined. The Greyhold line has a specific quiet respect for the Depth-Walkers, which most clansfolk do not understand.

Private suspicion, held by the Greyhold chieftess-line alone: the Depth-Walkers are correct that the truth of the north is below and beyond the cliff. Brenna has met Archdepth Sula twice, in unrecorded meetings at a clan-hall on the northern moor. She has not told her clans. She has told her successor, her niece Svala, only that *the Greyhold line carries an old memory and a harder one*.

Brenna's armour inlay — the pale unbreakable metal — is a Greyhold inheritance from before the clan-lines settled. She does not know what the metal is, exactly, but she knows that the line never sells it and only takes a blood-price for it. She knows, without having been told in so many words, that the metal came from the other side.

## Storyline hooks

Named NPCs from this culture:

- **Chieftess Brenna Greyhold** (T005, Line C soul — Free-North kingdom seat)
- **Ylva Stoneshield** (T002, Line C envoy — Brenna's southern hand)
- **Captain Yura Stoneshield** (T002, existing NPC_T002_01 — Ylva's cousin, clan-born, keep-serving)
- Reference: the Stoneshield family branches — Free-North branch (Ylva) and keep-service branch (Yura)

Storyline beats that rely on this culture's norms:

- The Two Stoneshields in the Stable (Line C T002) — cousins separated by eleven years and different clan-oaths. Their conversation in the stable is a Free-North-internal conversation on Ashcrown soil: Norhald idiom, forearm-bared oaths, the clan-saying *we wear what we wear because we remember what we remember*.
- Brenna's pale-line oath (Line C T005) — she swears the summit's opening on her own forearm with her own clan-knife, not on a written document. The other three crowns must accept this because the Free North does not swear otherwise.
- Brenna's warning to Tobiah (Line C T005) — *"You have brass cups in your warehouses. Twelve, I am told. They are not brass."* This breaks summit protocol. It is a Free-North hearth-custom imposed on a Crown room: in a clan-hall, you warn a hearth-guest before the other three can eat him. Brenna treats Tobiah as her hearth-guest at the summit.
- The unbreakable metal lump (Line D T002) — Durm's un-hammerable iron is a northern-moor find. The Free-North line metal (Brenna's inlay) is the same stuff. A Free-North NPC seeing the lump will recognise it and will not say so aloud.
- Ylva's distant-voice stones (Line C T002) — she uses staged swaps to explain her impossibly-rested horse, but she also carries a pair of stones, unacknowledged. The stones are Crown-supplied; Ylva does not know what they are. She thinks they are *chieftess-gifts*.

Idiosyncrasies a town writer must preserve:

- Free-North NPCs do not kneel. Not to kings, not to Septas, not at death. The knee is for climbing, not for bowing.
- Free-North NPCs do not drink first. A guest does not drink before her host; a subordinate does not drink before her chieftess. Ylva's line *"I drink after my chieftess, not before her"* is the canonical form.
- Free-North NPCs swear on the forearm. A Free-North NPC asked to sign a written oath will offer, instead, a drop of blood on the document. If the document is refused, the oath is refused.
- Free-North NPCs speak given-name-of-clan-name: *Ylva of Stoneshield*, not *Lady Ylva*. Any town writer using *Lady* for a Free-North character has broken voice.
- Free-North NPCs do not eat grey fish, do not wear red in combat, and do not wear another clan's plaid ever.
- The lullaby *Vi kam fra den andre sida* ("We came from the other side") is a Norhald phrase. It appears to most clansfolk as a child's nonsense-rhyme. The Greyhold chieftess-line knows it is not nonsense. A town writer quoting the phrase outside of Brenna's or Ylva's mouth, in the hearing of another clansman, should have that clansman react to it as a *familiar rhyme I vaguely remember from childhood*, never with recognition of its content.

<!-- writer-only
## Inner circle knowledge

Chieftess Brenna Greyhold knows the following, passed down in the Greyhold chieftess-line from mother to daughter as a spoken inheritance never written, never witnessed, never confessed:

1. The Greyhold chieftess-line descends from colonists who crossed from the far side of the Great Chasm in an earlier age, via a route that did not go over the cliff but under the land. The line's memory is explicit on this point: *vi kam fra den andre sida, men vi kam ikkje over — vi kam under*. "We came from the other side, but we did not come over — we came under." The lullaby is a fragment of this memory, the under-part worn away into rhyme.

2. The pale inlaid metal — the unhammerable metal — is a colonial alloy. Brenna does not know the word *alloy*, but she knows the metal is *made, not found*, and that the making is not a northern smith's work. The line has a small reserve of the metal, enough for one more generation of chieftess-armour. After that the line must either find more or give up the inlay.

3. Contact with the far side stopped a hundred years ago. Brenna has not been told a theory. Her mother said only: *the other side stopped speaking to us, and we do not know why, and we must keep the line alive until we know.* Brenna has read this as *the far side may have collapsed, or the far side may have withdrawn*, and has held both possibilities open for fourteen years.

4. Brenna has met Archdepth Sula. Twice. She has not told her clans. Sula offered, on the second meeting, to show Brenna a Crosser sketch. Brenna refused. She will not see the sketch because seeing it is a commitment she does not want to make in advance of the summit.

5. Brenna knows Darrik Voss knows. She does not know the full shape of what Darrik knows; she knows only that his silence at the Morning Table is not a performance. She is at the summit to ensure that whatever the Crown plans to do with this knowledge, the Free North is not bound to it by proxy.

6. Brenna has not told her niece Svala the full inheritance. Svala is twenty-six; the inheritance is traditionally given at thirty-five. Brenna will tell Svala before the summit at Mistmere if and only if Brenna does not expect to return. She is privately considering this.

7. The Greyhold clan-moor holds, in a cairn Brenna has never opened, a *colonist crest fragment* matching the one in Veyl's pocket. The cairn was sealed by Brenna's grandmother. Brenna has been told, by her mother, that if the cairn is ever opened, the Greyhold line ends and the clan must choose a new chieftess-line from the Karn or Vilda blood.

8. The Ashen Herald has written to Brenna twice. Brenna has not replied in writing. She has sent, once, a small iron disc with the Greyhold sigil pressed into it — a clan-mark that the Herald will understand as *I have received, and I have noted, and I owe you a word in person*. The word has not yet been given.

9. The vocabulary used inside the Greyhold inner line is Norhald and old-Norhald, with specific words for *the under-road* (*undervei*), *the made-metal* (*gjord-jern*), *the other side* (*andre sida*), and *the old line* (*gamle-linja*). These words are not used outside the chieftess-line. A clansman overhearing them would register them as archaic Norhald and nothing more.

10. Brenna does not know, and has never been told, about the distant-voice stones, the unaging tea, or the colonial-transit theory. The Greyhold inheritance is narrow and exact — it preserves bloodline and metal, and nothing else. Brenna will, at the summit, learn things from Darrik and from Malen and from the Herald that expand her picture. She is prepared for this and has told Svala only: *if I do not come home, the cairn stays closed*.
-->
