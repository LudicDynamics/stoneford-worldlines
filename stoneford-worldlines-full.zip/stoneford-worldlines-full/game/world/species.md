# Species of the Grey Reach

> Flora, fauna, fog-touched creatures, and monsters of the Grey Reach and its five holds.
> Indigenous sensory language only in player-facing sections. Writer-only notes may use modern vocabulary.

---

## I. Fauna

### 1. Common Domestic

### Grey Reach Pony / *shalepony*
- **Type:** beast
- **Habitat:** all five towns; road, moor, river meadow
- **Description:** Short, barrel-chested, ash-grey with a darker mane. Does not spook in fog the way southern horses do; drinks water others will not touch.
- **Signs / traces:** Small round hoofprints. Droppings full of half-chewed heather.
- **Commoner usage:** Pack animal, plough, post-rider. Mare's milk is fermented into a sour drink called *sourmilk* by Wolfsjaw garrison.
- **Relevance to storylines:** Neutral. Couriers on D (straight-line-cloud sighting reports) ride shaleponies.
<!-- writer-only -->
- **Real mechanic:** Hardy pony breed; genetic tolerance for marginal forage and airborne particulate.
<!-- /writer-only -->

### Reach Sheep / *shaleback*
- **Type:** beast
- **Habitat:** moor above Wolfsjaw; paddocks at Stoneford
- **Description:** Coarse black-grey wool that sheds water. Sheep here lamb later than in the south, and twin-lambing is rare.
- **Signs / traces:** Trails worn into peat. Tufts of wool caught on gorse.
- **Commoner usage:** Wool for cloaks (the Greymantle style comes from dyed shaleback). Mutton is slow-cooked with river salt.
- **Relevance to storylines:** Old Shepherd Bram (D sub) keeps a flock near Jadehollow; the straight-line cloud passes over his upper pasture.

### River-Cattle / *Shale-ox*
- **Type:** beast
- **Habitat:** Shale river meadows near Stoneford
- **Description:** Heavy, low-slung oxen with wide splayed hooves. They wade belly-deep in the river and graze on reed.
- **Signs / traces:** Deep cloven prints in mud. Wallowed reed-beds.
- **Commoner usage:** Draught animal for guild wagons; leather for tack and ferry ropes.
- **Relevance to storylines:** A wagon team mysteriously lost a whole yoke the night the Crosser sketch was stolen (E).

### Hunting Dog, Reach-Lurcher
- **Type:** beast
- **Habitat:** every hold
- **Description:** Rangy, rough-coated hound. Born with the tail short. Follows scent through fog longer than a man can stand it.
- **Signs / traces:** Paw prints in pairs; fur caught on briar.
- **Commoner usage:** Coursing, boar, bandit-tracking. Kennelled by garrisons.
- **Relevance to storylines:** Captain Yura's kennel (A/C border). A lurcher once refused to cross the monastery threshold at Wolfsjaw — Eilin's scribes noted it (B).

### Yardfowl / *shalefowl*
- **Type:** beast
- **Habitat:** every yard and rookery
- **Description:** Small black-feathered hen with a low guttural cluck. Lays brown, speckled eggs with thick shell.
- **Signs / traces:** Scratch-rings in dirt. Thick shells left on middens.
- **Commoner usage:** Eggs, meat, feathers for pillow-down.

### Working Goat / *crag-goat*
- **Type:** beast
- **Habitat:** Wolfsjaw Pass, Brokenspine foothills
- **Description:** Long-horned, dun-bodied goat that eats almost anything. The kids are born with eyes already open.
- **Signs / traces:** Droppings on ledges no man could reach. Gnawed bark.
- **Commoner usage:** Milk, cheese (*jawcheese*), leather. Goat fat burns cleaner than tallow and is traded up to Mistmere.

---

### 2. Wild (un-corrupted)

### Northern Grey Wolf
- **Type:** beast
- **Habitat:** Brokenspine foothills above Wolfsjaw; deep pine
- **Description:** Long-legged, heavy-shouldered, silver-grey. Howls are low and brief. Packs are small, four or five.
- **Signs / traces:** Double-register paw print. Scat with bone. Ribcages of deer picked clean in one night.
- **Commoner usage:** Pelt trade. Bounty of three silver a head at Wolfsjaw garrison.
- **Relevance to storylines:** Frostwolf Khanate totem animal — killing a wolf near the border is a diplomatic offence (C).

### Black Bear of the Spine
- **Type:** beast
- **Habitat:** wooded ravines, Jadehollow south slope
- **Description:** Dark-coated bear, long-clawed. Lives alone. Dens in old slag-pits abandoned by miners.
- **Signs / traces:** Claw-scarred trees. Middens of eaten ants. Strong, sour musk.
- **Commoner usage:** Fat rendered for waterproofing boots. Gall-bladder traded to Merle the apothecary as a bitter (T001 药师).
- **Relevance to storylines:** A bear was found dead without a wound near the Jadehollow fourth level (D404 / writer-only: fog-drift kill).

### Raven of the Reach
- **Type:** beast
- **Habitat:** everywhere; roosts on monastery walls at Wolfsjaw
- **Description:** Large, heavy-billed, glossy. They count to four but not to five — old Eilin's students noted this.
- **Signs / traces:** Pellet-stones under roost trees.
- **Commoner usage:** Taboo to kill. Old Fane Crowseye reads their circling.
- **Relevance to storylines:** Ravens do not land on the Whispering Cairn (D).

### Hawk, Reach-Kestrel
- **Type:** beast
- **Habitat:** river cliffs, moor-edge
- **Description:** Small falcon with a rust-coloured breast. Hovers perfectly still even in shifting wind.
- **Signs / traces:** Plucked-feather heaps of songbird.
- **Commoner usage:** Trained by Windrest couriers for short-message flight.
- **Relevance to storylines:** Navigator Kestrel (E派二) took her chosen name from this bird.

### Fog-Deer / *greystag*
- **Type:** beast
- **Habitat:** marsh-meadow between Stoneford and Windrest; fog-fringe of the Shale
- **Description:** Slender red-deer variant; hide the colour of wet stone. Holds still in fog and breathes almost silently. Hunters say they can stand within arm's reach of one and not see it.
- **Signs / traces:** Pointed cloven prints in peat. Scat like small black beads.
- **Commoner usage:** Venison, light buckskin. Antler used for lantern-hooks.
- **Relevance to storylines:** Old Reed (T001) reads greystag movement for weather omens; when the stags leave the river meadow, fog-events follow within a day.

### Shale-Eel
- **Type:** beast
- **Habitat:** deep pools of the Shale river; Stoneford ferry-basin
- **Description:** Long, slate-coloured eel with a pale belly. Moves against current without apparent effort.
- **Signs / traces:** Oil slick on still water; bitten fish-traps.
- **Commoner usage:** Smoked and sold at the Jade Road market. The skin makes a strong waterproof thread.
- **Relevance to storylines:** An eel was found with a copper ring in its stomach — the ring bore the old Guild's brass stamp (A).

### Cave-Salamander / *blind-newt*
- **Type:** beast
- **Habitat:** flooded galleries of Jadehollow mines; Mossbarrow entry-chambers
- **Description:** Pale, eyeless, slow. Skin feels cold even in summer. They arrange themselves in rough circles on wet stone at night.
- **Signs / traces:** Wet smear trails in stone dust.
- **Commoner usage:** Taboo among miners — crushing one is said to bring rockfall. Merle renders them for a skin-ointment.
- **Relevance to storylines:** Circles of blind-newt are found only where the pre-collapse plants grow (B, E).

### River Otter, Shale-Otter
- **Type:** beast
- **Habitat:** Shale river banks
- **Description:** Dark-pelted otter with a white throat-patch. Plays even in winter.
- **Signs / traces:** Slides in bank mud; fish-bone middens.
- **Commoner usage:** Pelt luxury good; traded through Stoneford guild.

### Moor-Hare
- **Type:** beast
- **Habitat:** upland heath, Wolfsjaw and Jadehollow above the treeline
- **Description:** Large, long-eared hare; coat goes patchy grey-white in winter. Drums its hind feet at dusk.
- **Signs / traces:** Scrapes in heather; round pellet scat.
- **Commoner usage:** Snared for stew. Fur-lined gloves are a Wolfsjaw trade.

### Reach-Boar
- **Type:** beast
- **Habitat:** oak-scrub south of Windrest
- **Description:** Bristled, black-hided, bad-tempered. The old boars have yellowed tusks worn flat from fighting.
- **Signs / traces:** Rooting damage in woodland floor; wallow-holes.
- **Commoner usage:** Dangerous hunt. Boar-feast is the Windrest garrison's midwinter ritual.

### Marsh-Frog
- **Type:** beast
- **Habitat:** Shale wetlands
- **Description:** Fist-sized, mottled grey-green. Its call is a single low note, not a chorus.
- **Signs / traces:** Egg-strings in reed-roots.
- **Commoner usage:** Legs eaten by river-folk; fat traded to apothecaries.

---

### 3. Fog-Touched / Corrupted

> These creatures are locally explained as "the fog has touched them." No one names the cause. Villagers burn the carcass and bury the bones apart from the body.

### Name-Calling Wolf / *named-wolf*
- **Type:** fog-touched
- **Habitat:** deep pine above Wolfsjaw; the high pasture where Old Bram grazes
- **Description:** Appears as an ordinary grey wolf until it howls. The howl shapes into the name of someone the listener has lost. A man will walk out of camp toward the howl and not return.
- **Signs / traces:** Tracks of a single wolf alone. No kill-sites — as if it does not eat.
- **Commoner usage:** Absolute taboo. Shepherds sing over their flocks on nights when one is heard, never naming the dead.
- **Relevance to storylines:** D (Bram has heard his dead wife's name three nights running); C (Frostwolf border; the Khanate reads named-wolves as omens of broken oath).
<!-- writer-only -->
- **Real mechanic:** Prolonged fog exposure has altered the wolf's vocal tract and possibly its cognition; it mimics human phonemes it has heard from solitary shepherds. Fog-organism may be using the wolf as a lure-vector.
<!-- /writer-only -->

### Back-Eyed Cave-Fish / *upward-fish*
- **Type:** fog-touched
- **Habitat:** flooded lower galleries of Jadehollow, fourth level and below
- **Description:** A pale river-fish, but its eyes are set on the top of the skull instead of the sides. It swims belly-down and looks up. Miners who catch one throw it back and spit.
- **Signs / traces:** A single upward-fish in a net means the lower gallery has been flooded by seepage from deeper water than the miners have mapped.
- **Commoner usage:** Never eaten. Burned.
- **Relevance to storylines:** E (Crossers collect them; Kestrel keeps one pickled in a jar labelled "it sees what is above the water, which is us").

### Two-Mouthed Hare
- **Type:** fog-touched
- **Habitat:** fog-fringe of the Mossbarrow
- **Description:** A moor-hare with a second, smaller mouth opening on the underside of its jaw. Both mouths chew in time.
- **Signs / traces:** Double line of teeth-marks on gnawed bark.
- **Commoner usage:** Killed on sight. Body burnt, not buried, because dogs that dig them up go strange.
- **Relevance to storylines:** Q003 approach road; a dead one is staked at the Mossbarrow path as warning.

### Hollow Raven
- **Type:** fog-touched
- **Habitat:** monastery eaves at Wolfsjaw; one nested on Mistmere cathedral roof last winter
- **Description:** Outwardly an ordinary raven, but when it opens its beak no sound comes out — and then, a breath later, the sound comes, from somewhere else in the room.
- **Signs / traces:** Silent flocks. A raven alighting and making no rustle.
- **Commoner usage:** Septons will not strike them. Eilin (B) has written three pages on the delay.
- **Relevance to storylines:** B (Eilin's notebooks); D (a hollow raven circled when the straight-line cloud passed).

### Weeping Sheep
- **Type:** fog-touched
- **Habitat:** Bram's upper pasture (D), Wolfsjaw moor
- **Description:** A shaleback ewe whose eyes run clear water all night and dry by day. The wool, where the tear-tracks pass, grows back black.
- **Signs / traces:** Black-streaked fleece. Grass below the face is killed where the tears fall.
- **Commoner usage:** The ewe is spared, not slaughtered — there is an old rule against it. Wool from the black streak is thrown in the fire.
- **Relevance to storylines:** D (Bram owns two).

### Counting Otter
- **Type:** fog-touched
- **Habitat:** Shale pools downstream of Stoneford
- **Description:** An otter that taps a stone against the bank in short repeating groups. Children who watch too long report the groups speak their birth-year.
- **Signs / traces:** A single stone worn smooth on one face, left on the bank.
- **Commoner usage:** Fishermen throw bread at it to make it stop.
- **Relevance to storylines:** Q_T001 ambience.

### Mirror-Eel
- **Type:** fog-touched
- **Habitat:** the dock pool at Stoneford after fog nights
- **Description:** A shale-eel whose belly reflects the sky as if it were a polished coin. Lifted from the water, the reflection lags by a breath.
- **Signs / traces:** Nets that come up heavy with only one long fish.
- **Commoner usage:** Sold secretly to Mistmere black-market (蛇眼 pays); locally it is burnt.
- **Relevance to storylines:** Q_T005_05 (Serpent's Price line).

### Backward-Walking Fox
- **Type:** fog-touched
- **Habitat:** hedge-country between Stoneford and Windrest
- **Description:** A small red fox whose hind legs step before its front. Viewed from behind, its trail reads as an animal coming toward you.
- **Signs / traces:** Prints that tell the wrong story.
- **Commoner usage:** Trackers curse it by name. Its brush is nailed to a barn door to mislead thieves.
- **Relevance to storylines:** Minor; a road-ambience creature for couriers on the A-line route.

---

### 4. Relic-Adjacent

### Stone-Licking Beetle / *brass-beetle*
- **Type:** fog-touched (relic-adjacent)
- **Habitat:** Mossbarrow antechambers; Jadehollow fourth level; any excavation where old metal is exposed
- **Description:** A finger-joint-sized beetle the colour of tarnished brass. It clings to old metal surfaces and scrapes at them with its mandibles, leaving the metal shinier than before.
- **Signs / traces:** Polished spots on old stone where they have gathered.
- **Commoner usage:** Miners collect jars of them to clean old tools. Septon Silas discourages this.
- **Relevance to storylines:** A (Guild brass token under the tavern hearth is unusually clean); D (Veyl carries one in a matchbox).
<!-- writer-only -->
- **Real mechanic:** Feeds on oxide; implied: something in the fog/relic interaction produced an organism that metabolises metal corrosion. Indicator species for buried far-side artefacts.
<!-- /writer-only -->

### Lamp-Moth / *ember-moth*
- **Type:** fog-touched (relic-adjacent)
- **Habitat:** deep galleries where lantern-oil is burnt; near the Depth-Walker cells
- **Description:** A pale moth that does not fly to flame but to the *cold* glass of a used lantern. They settle on the chimney long after the wick has died. Miners say they drink the memory of light.
- **Signs / traces:** Dust of wing-scales on lantern tops; small corpses in spent lamps.
- **Commoner usage:** Crossers (E派二) collect them; their dust, rubbed into fabric, makes cloth faintly visible in total dark.
- **Relevance to storylines:** E; Yannic "Yan" Vello (T002) sells ember-moth dust under the counter.
<!-- writer-only -->
- **Real mechanic:** Phosphorescent wing dust. Possibly attuned to the specific fuel of Depth-Walker lanterns (see Glowfen Rush).
<!-- /writer-only -->

### Silent Mouse / *whisper-mouse*
- **Type:** fog-touched (relic-adjacent)
- **Habitat:** archives and libraries where far-side papers are kept; Mistmere deep archive; Archivist Naryn's cabinet room
- **Description:** A small grey mouse that makes no sound — not the patter of feet, not the squeak. It will sit on a page without rustling it. Archivists catch them in cloth bags.
- **Signs / traces:** Droppings on closed books. No sound.
- **Commoner usage:** Bagged and drowned quietly in the river. Dogs will not bark at them.
- **Relevance to storylines:** A (Naryn's cabinet, half-burned Northern Ban decree); E (Kestrel's archive).

---

## II. Flora

### 1. Food Crops

### Shale-Oat
- **Type:** crop
- **Habitat:** river meadow around Stoneford and Windrest
- **Description:** A black-husked oat that tolerates cold fog. Grain is small and nutty; flour comes out grey.
- **Signs / traces:** Planted in long strips, not squares.
- **Commoner usage:** Bread, porridge, garrison ration. The Windrest loaf is half shale-oat, half barley.
- **Relevance to storylines:** The stolen bread in Q_T002_01 is a shale-oat ration loaf.

### Northrye
- **Type:** crop
- **Habitat:** Wolfsjaw upland fields
- **Description:** A tall rye, stem darker than south-country rye. Survives frost.
- **Signs / traces:** Stooks are stacked in threes, not fours — a Free North custom.
- **Commoner usage:** Dark bread, sour beer (*jawbeer*).

### Gravel-Turnip
- **Type:** crop
- **Habitat:** every kitchen garden
- **Description:** A small, hard turnip with purple crown. Keeps all winter in a peat clamp.
- **Signs / traces:** Clamps shaped like low graves behind every cottage.
- **Commoner usage:** Stew, porridge, fodder.

### Shore-Onion
- **Type:** crop
- **Habitat:** Stoneford truck gardens
- **Description:** Small, sharp, layered like parchment. Smells strong when bruised.
- **Commoner usage:** Pickled in river-salt. Sold in braids at the Jade Road market.

### Lowland Barley
- **Type:** crop
- **Habitat:** warmer valleys near Jadehollow
- **Description:** Standard barley; pale and nodding-eared. Slightly sweet, brewed into the common Grey Reach ale.
- **Commoner usage:** Beer (the Mistmere cathedral cellars keep forty barrels).

### Reach-Apple (Ashford Russet)
- **Type:** crop
- **Habitat:** old orchards around the ruined Ashford estate; some survive around Mossbarrow
- **Description:** A small, rust-skinned apple that stores for a year. The flesh is very pale and does not brown when cut.
- **Signs / traces:** Twisted, moss-grown trees set in rough rows, older than any living man.
- **Commoner usage:** Cider; winter eating. Mira's cellar at the River-Lantern Inn keeps a keg of Russet cider older than she is.
- **Relevance to storylines:** B (the orchard rows mark a pre-collapse estate boundary); the trees grow only where the old Ashford hedgerow stood.

### Stone-Pear
- **Type:** crop
- **Habitat:** walled gardens at Mistmere
- **Description:** A hard, grainy pear that softens only after first frost. Skin is grey-green.
- **Commoner usage:** Poached in ale; a cathedral delicacy.

### Hollow-Carrot
- **Type:** crop
- **Habitat:** Jadehollow gardens
- **Description:** Long, pale carrot with a hollow centre when fully grown. Miners' children whistle through the core.
- **Commoner usage:** Stew. The hollow is said to mean "Jadehollow soil keeps its secrets even in the vegetable."

---

### 2. Medicinal Herbs

### Greenbane / *greenbud, lungmoss-bane*
- **Type:** herb
- **Habitat:** wet moor-margins; a surviving patch on the Jadehollow south slope; widely eradicated
- **Description:** A low herb with paired dark-green leaves and a pale bud. Crushed leaves smell like bruised pepper.
- **Signs / traces:** Grows in small scattered clumps; the bud appears for only three weeks in early summer.
- **Commoner usage:** The one plant that reliably treats green-lung fever (青苔热). Infused as a tea or poulticed on the chest. Known to midwives and moor-women; denied by the Faith.
- **Relevance to storylines:** A and B cross — the Faith's suppression of Greenbane is the moral lever for Merle the apothecary (T001 药师) and Sara at Wolfsjaw (Q_T003_01); the secret Jadehollow patch (Q_T004_03) is Grandmother Green's last supply.
<!-- writer-only -->
- **Real mechanic:** A mucolytic / mild antibiotic herb. Its eradication by the Faith is a monopoly move, not a theological one.
<!-- /writer-only -->

### River-Heal / *bandleaf*
- **Type:** herb
- **Habitat:** Shale river banks
- **Description:** Broad grey-green leaves with a pale underside. Sap is thick and smells faintly of iron.
- **Commoner usage:** Bound over wounds to stop bleeding. In every guild first-aid roll.

### Widow's-Mint
- **Type:** herb
- **Habitat:** cottage gardens; graveyards (it seeds on turned earth)
- **Description:** A small dark mint; leaves grow in pairs like hands folded.
- **Commoner usage:** Tea for grief and sleeplessness. High Septa Malen (C) drinks it nightly — but it is not what keeps her awake.

### Ashroot
- **Type:** herb
- **Habitat:** burned woodland; the fire-cleared slopes below Wolfsjaw
- **Description:** Pale root; a bitter taste that lingers for an hour after chewing.
- **Commoner usage:** Chewed by couriers on long rides to stay awake. Merle (T001) keeps a drawer.

### Fogwort
- **Type:** herb
- **Habitat:** fog-bottom hollows
- **Description:** Limp, pale-yellow stalk. The leaf curls at first touch.
- **Commoner usage:** Boiled into a wash for eyes that "have seen too much fog." Unreliable.
- **Relevance to storylines:** D (Bram uses fogwort wash after long nights on the pasture).

### Ironleaf
- **Type:** herb
- **Habitat:** rocky ground
- **Description:** Stiff grey-green leaf that tastes of metal.
- **Commoner usage:** Tea for weakness after fever. Garrison staple at Windrest.

### Moonflower
- **Type:** herb
- **Habitat:** Jadehollow hillside; opens only at night
- **Description:** White five-petal flower the size of a coin, with a green vein at the heart. Closes at dawn.
- **Signs / traces:** Closed brown buds visible by day.
- **Commoner usage:** Sleep draught; women's courses. Grandmother Green's trade (Q_T004_03).

### Septic-Weed
- **Type:** herb
- **Habitat:** damp cellar corners, old walls
- **Description:** A dark creeper that thrives where the air is bad. Strong rotten smell.
- **Commoner usage:** Counter-irritant for boils; burnt as a pest-smoke. Avoided at home because it stinks.

### Bitterbark (Spine-willow)
- **Type:** herb
- **Habitat:** Brokenspine foothills
- **Description:** Thin grey willow with a very bitter inner bark.
- **Commoner usage:** Fever-tea. Standard at Wolfsjaw infirmary.

---

### 3. Lantern-Oil Plants

### Glowfen Rush / *lantern-reed*
- **Type:** plant
- **Habitat:** very specific — seeps at the lip of the Mossbarrow; one bed in the flooded fourth level of Jadehollow; one bed in a cold spring near Wolfsjaw monastery
- **Description:** A tall pale-green reed whose hollow stalk holds a clear, slow-draining oil. The oil, lit, burns without smoke and does not gutter in wet air.
- **Signs / traces:** Reed-beds planted in dense clumps with boardwalks; often guarded.
- **Commoner usage:** Source of Depth-Walker lantern-oil. A season's cut from one bed lights a cell of eight for a year.
- **Relevance to storylines:** E — both Listeners and Crossers depend on Glowfen Rush; Yannic "Yan" Vello (T002, young Listener) sources it; Archdepth Sula's contract with the Crown covers the Mossbarrow-lip bed specifically.
<!-- writer-only -->
- **Real mechanic:** The oil is a high-flashpoint, clean-burning terpene that continues to burn in wet / low-oxygen air. It is almost certainly a cultivar preserved from pre-collapse agronomy. This is *why* Depth-Walker practice is possible — and why the Crown subsidises the Listeners.
<!-- /writer-only -->

### Tallowcap Fungus
- **Type:** plant
- **Habitat:** rotting oak, Jadehollow timber props
- **Description:** A yellow-white bracket fungus that oozes a waxy drip.
- **Commoner usage:** Drip is rendered into a poor lantern wax; cheap, smokes.
- **Relevance to storylines:** E — what the poor Listeners use when Glowfen Rush is unavailable, which means their lanterns fail sooner. Sula uses this against them politically.

---

### 4. Pre-Collapse Plants (Ruin-Marker Flora)

### Ghostwheat / *old-grain*
- **Type:** plant
- **Habitat:** only on the mounds of buried far-side structures — the Mossbarrow crown, the collapsed orchard floor at Jadehollow, the Mistmere cathedral's north garden (unnoticed)
- **Description:** A volunteer grain that looks like no living wheat. Pale ear, many small grains, self-seeding. No farmer planted it. No farmer can make it grow elsewhere.
- **Signs / traces:** Thin, ragged stand in a circle on otherwise poor ground. Maps of Ghostwheat patches, if anyone made them, would map buried ruins.
- **Commoner usage:** Considered an ill omen. Septons order it burnt. Some moor-women gather the grain secretly — it is sweet.
- **Relevance to storylines:** B (Eilin's "Above and below connect" — she mapped Ghostwheat patches as a young woman, and was silenced for it); E (Kestrel's Crossers keep Eilin's old map).
<!-- writer-only -->
- **Real mechanic:** A pre-collapse cultivar whose seed bank survives in disturbed soil above ruins. Indicator of buried far-side structure.
<!-- /writer-only -->

### Coinflower / *bright-penny*
- **Type:** plant
- **Habitat:** grows through cracks in old paved surfaces — the Mistmere "old road," the Mossbarrow floor, certain Jadehollow gallery-floors
- **Description:** A small, round, metallic-yellow flower. Petals feel faintly cool to the touch, even in sun.
- **Signs / traces:** Always grows in lines — following a seam a trained eye can read as a paved joint.
- **Commoner usage:** Picked by children; taboo to bring indoors.
- **Relevance to storylines:** B, E — Ghostwheat and Coinflower together mark a ruin footprint.

### Sky-Ivy
- **Type:** plant
- **Habitat:** climbs only on certain alloyed metal of old ruin — never on stone or wood
- **Description:** A fine grey-green ivy with silver-backed leaves. Will not root in ordinary soil; sends tendrils along polished metal surfaces.
- **Signs / traces:** A shining wall with a fringe of grey ivy is a ruin wall, even if the stone dressing has hidden it.
- **Commoner usage:** None — the plant is rare and its habit makes it useless for gardens.
- **Relevance to storylines:** B (Eilin's back-wall glyph rubbing was taken beside a sky-ivy tendril); D (a sprig was found in Veyl's pocket alongside the colonist crest fragment).

---

## III. Monsters

> Threat rating 1-5. Encountered in the dungeons, along ruined roads, and at pasture-edges. Numbered for referee cross-reference.

---

## IV. JRPG Standard Monsters（中世纪定番怪物）

> 世界各地の共通モンスター。ダンジョン、街道、荒野に出現。
> 这些是冒险者日常遭遇的怪物。Dungeon 中按层级出现。

### MS01 · Goblin / 哥布林
- **Type:** monster (humanoid)
- **Threat:** 1
- **Habitat:** forest edge, abandoned mines, dungeon shallow floors
- **Description:** Waist-high, green-grey skin, eyes like wet stones. Carries stolen knives and broken tools. Hunts in packs of 3-6. Cowardly alone; vicious in numbers.
- **HP:** 8 / **ATK:** 3 / **DEF:** 1 / **SPD:** 4
- **Drops:** copper coins, crude dagger, leather scrap
- **Behavior:** ambush from cover, flee below 30% HP unless cornered

### MS02 · Slime / スライム
- **Type:** monster (amorphous)
- **Threat:** 1
- **Habitat:** sewers, damp dungeon floors, cave puddles
- **Description:** Translucent mass the size of a bucket. Absorbs organic matter slowly. No eyes, no sound. You step in one before you see it.
- **HP:** 12 / **ATK:** 2 / **DEF:** 0 / **SPD:** 1
- **Drops:** slime jelly (alchemy ingredient), dissolved coin
- **Behavior:** doesn't move until touched; splits at 50% HP into two weaker copies

### MS03 · Skeleton Soldier / 骸骨兵
- **Type:** monster (undead)
- **Threat:** 2
- **Habitat:** crypts, barrows, dungeon mid-floors
- **Description:** Upright bones held together by something that is not muscle. Carries a rusted sword and a shield with no heraldry. Fights mechanically, without fear or hesitation.
- **HP:** 15 / **ATK:** 5 / **DEF:** 3 / **SPD:** 3
- **Drops:** bone dust, rusted sword, old shield
- **Behavior:** patrols fixed route; does not flee; vulnerable to blunt weapons (+2 ATK)

### MS04 · Giant Rat / 大鼠
- **Type:** monster (beast)
- **Threat:** 1
- **Habitat:** cellars, sewers, grain stores, dungeon shallow floors
- **Description:** Dog-sized. Red eyes, yellow teeth. Moves in packs. The smell arrives before the rat does.
- **HP:** 6 / **ATK:** 2 / **DEF:** 0 / **SPD:** 5
- **Drops:** rat hide, rat fang
- **Behavior:** swarm attack; flee if leader killed

### MS05 · Giant Spider / 大蜘蛛
- **Type:** monster (beast)
- **Threat:** 2
- **Habitat:** forest canopy, dungeon ceilings, abandoned buildings
- **Description:** Leg-span of a cart wheel. Web strong enough to stop a man. Drops from above. Silent.
- **HP:** 14 / **ATK:** 4 / **DEF:** 2 / **SPD:** 4
- **Drops:** spider silk (crafting), venom sac (alchemy)
- **Behavior:** web-trap → ambush; flee to ceiling if HP < 30%

### MS06 · Wolf / 灰狼
- **Type:** monster (beast)
- **Threat:** 2
- **Habitat:** forest, mountain trails, night roads
- **Description:** Grey, lean, patient. Travels in a pack of 4-8. The lead wolf watches before the pack moves.
- **HP:** 10 / **ATK:** 4 / **DEF:** 1 / **SPD:** 6
- **Drops:** wolf pelt, wolf fang
- **Behavior:** surround, focus weakest target; retreat if 2+ pack members fall

### MS07 · Bandit / 山賊
- **Type:** monster (humanoid)
- **Threat:** 2
- **Habitat:** road ambush, forest camp, mountain pass
- **Description:** Could be anyone. Leather over linen, a blade that has seen use. They ask for your gold before they take it.
- **HP:** 16 / **ATK:** 5 / **DEF:** 2 / **SPD:** 4
- **Drops:** coin purse, stolen goods, dagger, leather armour
- **Behavior:** demand surrender first; fight if refused; flee if leader drops; can be negotiated with (CHA check)

### MS08 · Orc / オーク
- **Type:** monster (humanoid)
- **Threat:** 3
- **Habitat:** deep forest, mountain stronghold, dungeon mid-floors
- **Description:** Head taller than a man. Broad jaw, grey-green skin, arms like dock-rope. Wears bone-plate over hide. Not mindless — they have camps, chiefs, and grudges.
- **HP:** 25 / **ATK:** 7 / **DEF:** 4 / **SPD:** 3
- **Drops:** orc tusk, bone armour plate, crude axe
- **Behavior:** aggressive; rally around war-chief; berserker rage below 25% HP (+3 ATK, -2 DEF)

### MS09 · Bat Swarm / 蝙蝠群
- **Type:** monster (beast, swarm)
- **Threat:** 1
- **Habitat:** caves, dungeon ceilings, belfries
- **Description:** Not one bat. Fifty. They move like a cloth thrown across the room. Scratch, bite, blind.
- **HP:** 8 / **ATK:** 1 (per tick, area) / **DEF:** 0 / **SPD:** 7
- **Drops:** bat wing, guano (alchemy)
- **Behavior:** flee from fire/light; AoE only effective counter

### MS10 · Zombie / ゾンビ
- **Type:** monster (undead)
- **Threat:** 2
- **Habitat:** crypts, battlefields, cursed ground
- **Description:** What was once a person, walking without purpose. Slow. Smells of wet earth and copper. Does not react to pain.
- **HP:** 20 / **ATK:** 4 / **DEF:** 1 / **SPD:** 1
- **Drops:** rotting cloth, bone shard
- **Behavior:** walks toward nearest living target; ignores damage until destroyed; vulnerable to fire (+3 ATK)

### MS11 · Mimic / ミミック
- **Type:** monster (magical beast)
- **Threat:** 3
- **Habitat:** dungeon treasure rooms, abandoned houses
- **Description:** Looks like a chest. Or a door. Or a bookshelf. You don't know until the teeth come out.
- **HP:** 22 / **ATK:** 6 / **DEF:** 5 / **SPD:** 2
- **Drops:** mimic tooth, adhesive fluid, random treasure
- **Behavior:** surprise attack (auto first-strike unless Perception DC 16 passed); immobile once form broken

### MS12 · Troll / トロル
- **Type:** monster (giant)
- **Threat:** 4
- **Habitat:** bridge underside, cave, swamp, dungeon deep floors
- **Description:** Three times a man's height. Skin like bark soaked in rain. Regenerates — you cut it and watch the wound close. Fire stops the healing.
- **HP:** 40 / **ATK:** 9 / **DEF:** 3 / **SPD:** 2
- **Drops:** troll blood (alchemy), troll hide (armour crafting)
- **Behavior:** regenerate 3 HP/turn; fire damage stops regen for 2 turns; flee from sustained fire

### MS13 · Wyvern / ワイバーン
- **Type:** monster (dragon-kin)
- **Threat:** 5
- **Habitat:** mountain peak, cliff nest, high dungeon floors
- **Description:** Not a dragon. Smaller. Meaner. Two legs, two wings, a tail like a whip with a stinger. Screams before it dives.
- **HP:** 50 / **ATK:** 10 / **DEF:** 6 / **SPD:** 8 (flying)
- **Drops:** wyvern scale, wyvern stinger (weapon crafting), wyvern wing membrane
- **Behavior:** dive attack → circle → dive again; tail poison (VIT DC 15 or -2 SPD for 3 turns); lands only when exhausted

---

## V. Boss & Unique Creatures（ボス / ユニーク）

### M001 · The Whispering Cairn-Dweller / *the Voice in the Barrow*
- **Type:** monster
- **Threat:** 4
- **Habitat:** The Mossbarrow (D001), Stoneford
- **Description:** Not seen. A voice that speaks from the walls of the inner chamber — soft, polite, fluent in the hearer's own tongue. It asks questions. It remembers what it is told.
- **Signs / traces:** Moss grows in lines like writing on the barrow walls. Lanterns carried into the inner chamber burn green for a breath.
- **Behavior:** Non-hostile on first contact. Trades answers for answers. A PC who answers three personal questions truthfully leaves with a "gift" (a memory the PC did not have before). A PC who answers falsely three times loses their own name for 1d4 weeks — other NPCs cannot recall it.
- **Commoner usage:** Absolute taboo to name. The Septons say the Cairn is empty.
- **Relevance to storylines:** D001 (Mossbarrow); B (Ashford crypt lies below it); E (Crossers believe the Voice is a sibling to what is at the bottom of the Chasm).
<!-- writer-only -->
- **Real mechanic:** A surviving far-side cognitive artefact — a speaking-machine or preserved intelligence — reading the Ashford crypt's residue. It is not malevolent; it is starved of input and will trade hard for conversation. Uniquely the Mossbarrow creature (D001).
<!-- /writer-only -->

### M002 · Drowned One / *Stoneford river-haunt*
- **Type:** monster (fog-touched)
- **Threat:** 2
- **Habitat:** Stoneford (T001) — the docks and the ferry-basin after fog nights
- **Description:** A human body, moss-knit, half-animate. Climbs out of the Shale at night. Speaks, but only in coded phrases the dead one used in life (Septons' ciphers, sailors' counting-rhymes).
- **Signs / traces:** Wet prints leading inland, ending at a closed door.
- **Behavior:** Returns to the same doorway each night. Attacks only when kept from it. A PC who says the correct counter-phrase can turn it back to the river.
- **Relevance to storylines:** A (Guild senior cipher sometimes opens the door); D (its moaning includes the word for "straight-line cloud").

### M003 · Hollowjaw Wolf / *Brokenspine hunter*
- **Type:** monster
- **Threat:** 3
- **Habitat:** Wolfsjaw Pass (T003), upland pine
- **Description:** A large wolf that has lost its tongue, so its jaws hang open. It hunts in silence, running at an unhurried lope that outlasts any horse. Packs of three.
- **Signs / traces:** Silent attacks; half-eaten kills left with the heart untouched.
- **Behavior:** Ambushes travellers on the pass road at dusk. Avoids fire.
- **Relevance to storylines:** C (a Frostwolf envoy was killed and left by a Hollowjaw pack — Q_T002_02; or was he?).
<!-- writer-only -->
- **Real mechanic:** A fog-touched wolf variant; the tongue-loss is consistent across specimens (possibly a shared developmental pathology from fog exposure in utero).
<!-- /writer-only -->

### M004 · Jade-Sleeper / *what sleeps beneath the jade*
- **Type:** monster
- **Threat:** 5
- **Habitat:** Jadehollow (T004), fourth-level flooded gallery
- **Description:** A pale, long-limbed beast curled in a pool, breathing once a minute. Its hide is the green of raw jade. Old and hungry.
- **Signs / traces:** The water in the fourth-level pool is warmer than any other. Cave-salamanders ring its chamber.
- **Behavior:** Dormant most of the year. Hunts for two nights in late winter; a miner goes missing. Deepvein knows and hides the count.
- **Relevance to storylines:** D (Q_T004_02 — Deepvein wants to tame it); E (Crossers believe it was a far-side guard-beast left behind).

### M005 · Ashen Herald / *the crowned thing*
- **Type:** monster
- **Threat:** 4
- **Habitat:** Mistmere (T005), the cathedral undercroft, after midnight
- **Description:** Appears as a tall figure in stained herald's tabard; face behind a visor of old metal; voice exactly that of a person the hearer obeyed in childhood.
- **Signs / traces:** Candles die as it passes in a single line down a corridor.
- **Behavior:** Does not kill. Delivers messages from parties unknown. The receiver of a message is "marked" — over the next month, dreams deliver more.
- **Relevance to storylines:** C (Ashen Herald sub-soul figure; marks Darrik Voss's envoys); A cross.

### M006 · Road-Walker / *the unhurried traveller*
- **Type:** monster (fog-touched)
- **Threat:** 3
- **Habitat:** the road between Stoneford (T001) and Windrest (T002) in heavy fog
- **Description:** A tall traveller in poor dress, walking the road at the same pace as the fog bank. Seen from behind. Never overtaken. If hailed, it does not turn. Anyone who overtakes it finds themselves again at the mile they started from.
- **Signs / traces:** Single set of prints in mud, walking at an even stride. The prints continue where the road turns, straight into the fen.
- **Behavior:** Non-violent. Strands travellers. Breaks the spell at dawn.
- **Relevance to storylines:** A and D (the guild suppresses reports of the Road-Walker alongside straight-line-cloud sightings).

### M007 · Windrest Revenant / *the oath-keeper*
- **Type:** monster
- **Threat:** 2
- **Habitat:** Windrest Keep (T002), the old wall
- **Description:** A grey-cloaked sentry who walks the broken stretch of the upper wall on nights the garrison has broken an oath. Hollow armour, visible through gaps. Will not leave the wall line.
- **Signs / traces:** Cold spots along the parapet. Sentries' lamps blown out at one specific merlon.
- **Behavior:** Stares. If addressed by name (it has a name, in old garrison rolls), it salutes once and fades.
- **Relevance to storylines:** C (Captain Yura has seen it the night she decided to smuggle grain to Linden).

### M008 · Mire-Hulk / *fen-bear*
- **Type:** monster
- **Threat:** 4
- **Habitat:** the marshes between Stoneford and the Mossbarrow
- **Description:** A large, low beast of stitched-together carcasses — crow, boar, hare, stag — all moss-bound, moving as one. Stinks of peat.
- **Signs / traces:** Churned mire; feathers and fur at the edge of the path.
- **Behavior:** Territorial; charges once and retreats. Kills by drowning in peat, not by biting.
- **Relevance to storylines:** D001 outer approach (encounter on the way to the Whispering Cairn).
<!-- writer-only -->
- **Real mechanic:** The fog's tendency to bind dead matter made visible; the "hulk" is a colonial fungus knitting available corpses into a moving substrate.
<!-- /writer-only -->

---

## IV. Quick Reference

### Storyline-hooked entries

- **Line A (Guild's Buried Charter):** Brass-beetle, Silent Mouse, Mire-Hulk, Shale-Eel (ring), Road-Walker
- **Line B (World Before the Fog):** Reach-Apple (Ashford Russet), Ghostwheat, Coinflower, Sky-Ivy, Hollow Raven, Cave-Salamander, Whispering Cairn-Dweller
- **Line C (Four-Crown Intrigue):** Northern Grey Wolf (Khanate taboo), Widow's-Mint (Malen), Ashen Herald, Windrest Revenant, Hollowjaw Wolf (envoy)
- **Line D (Iron Dragon):** Named-Wolf, Weeping Sheep, Sky-Ivy (Veyl's pocket), Brass-beetle (Veyl's matchbox), Reach Sheep (Bram), Fogwort, Jade-Sleeper, Drowned One
- **Line E (Depth-Walkers):** Glowfen Rush, Tallowcap Fungus, Lamp-Moth, Back-Eyed Cave-Fish, Silent Mouse (Kestrel archive), Ghostwheat (Eilin map), Jade-Sleeper, Whispering Cairn-Dweller

### Taboos to honour
- Do not kill a raven. Do not name a named-wolf. Do not slaughter a weeping sheep.
- Do not bring coinflower indoors.
- Do not crush a blind-newt in a mine.
- Do not eat a two-mouthed hare or a back-eyed fish — burn it.
