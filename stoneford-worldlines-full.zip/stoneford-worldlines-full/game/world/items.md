# Items of the Grey Reach

> Everyday gear. Tools. Weapons. Cloth and coin and small trinkets a hand can close around.
> Relic-class objects (strange, unexplained, pre-collapse origin) are catalogued separately. A handful of pre-collapse ordinary things — potsherds, buried coinage — appear here, labelled, because a commoner finds them and uses them as ordinary.
> Indigenous sensory language only in player-facing sections. Writer-only blocks may use modern vocabulary for cross-reference.

---

## I. Weapons

### Greyhold Longaxe / *the hearth-axe*
- **Category:** weapon
- **Origin:** Free North, twenty-three clans; the Greyhold forge-pattern is the best known
- **Description:** A four-foot hickory haft, bound at the grip in black-dyed leather. The head is a single crescent, heavier at the toe than the heel, the edge kept bright. The haft is scorched at the butt from years of being stood upright against a hearth-stone.
- **Typical user:** Clan-warrior of the axe-line
- **Rarity:** common (Free North), scarce elsewhere
- **Storyline links:** C (Brenna's own; the Circle opens each winter with axes laid across the threshold)
- **Notes:** Two-handed for most clansfolk; the broad-shouldered can wield single-handed if a shield is needed. Sharpened once a year, at the winter Circle, by the clan's eldest smith.

### Clan-Knife / *forearm-blade*
- **Category:** weapon
- **Origin:** Free North
- **Description:** A hand-and-a-half blade, six inches of forged iron, a bone handle worn to the shape of its owner's grip. Every clansfolk of age carries one. The blade draws the oath-blood. The blade draws the marriage-scar.
- **Typical user:** Every Free North adult
- **Rarity:** common
- **Storyline links:** C (Ylva's clan-knife, drawn in the stable at Windrest; Brenna's, used for the pale-line oath)
- **Notes:** Functional blade, ritual object. Never loaned. A clansfolk who has lost her clan-knife is considered diminished until she has forged another.

### Linden Long Spear / *the grey-shaft*
- **Category:** weapon
- **Origin:** Crown, House Linden
- **Description:** Eight feet of straight ash, grey-stained, iron-shod at the butt. The head is a leaf-blade of Ashcrown-forged steel, no wider than a man's palm, polished twice before each dawn-march.
- **Typical user:** Linden foot, Ashcrown mailed infantry
- **Rarity:** restricted (Linden company issue)
- **Storyline links:** C (Linden Ironfist's company at Wolfsjaw; the line that will not break)
- **Notes:** Not a throwing spear. The Crown's slow line depends on a wall of these held shoulder-high, points level, for as long as the line holds.

### Voss Side-Sword / *the orchard blade*
- **Category:** weapon
- **Origin:** Crown, court-issue
- **Description:** A straight blade of thirty inches, single-edged, in a plain leather scabbard stitched black. The hilt is brass-bound wood, worn paler at the pommel where a thumb has rested. No sigil on the blade.
- **Typical user:** Voss horse, Ashcrown envoy, Morning Table Guard
- **Rarity:** uncommon
- **Storyline links:** C (Envoy Alric carries one, strapped beneath his travelling cloak)
- **Notes:** Drawn at court only in the executioner's orchard. At the border, drawn without ceremony.

### Horn-Recurve Bow / *the short horn*
- **Category:** weapon
- **Origin:** Crown, Voss horse
- **Description:** A short bow of layered horn and sinew, dark as smoked amber, the grip wrapped in red silk — a concession to ornament, hidden inside the quiver-hand. Strung only before a ride; kept unstrung in a waxed linen case.
- **Typical user:** Voss courier, Voss horse, border scouts
- **Rarity:** uncommon
- **Storyline links:** C (Voss riders screen the Crown delegation to Mistmere)
- **Notes:** Short range. The Voss do not charge; they skirmish, they carry word.

### Union-Pattern Crossbow / *the honest bolt*
- **Category:** weapon
- **Origin:** Union, Greyharbour foundries
- **Description:** A stocked crossbow of walnut and iron, the lock stamped with the crossed scales of the Exchange. The span-cord is replaced every ninety days by regulation; the regulation is written on a small brass plate set into the stock.
- **Typical user:** Caravan-guard, Exchange Watch, port militia
- **Rarity:** common (along trade roads)
- **Storyline links:** A (Guild suppression patrols along the Jade Road); C (Tobiah's personal guard at the summit escort)
- **Notes:** Slow to span. Sold to every kingdom except the Free North, who refuse it.

### Pilgrim-Staff / *the Mistmere staff*
- **Category:** weapon
- **Origin:** Faith
- **Description:** A six-foot hardwood stave, oiled ash or hill-pine, the butt shod in a simple iron cap. The upper foot is unshod and unmarked, the place where a Septa would lay her hand in blessing before the road.
- **Typical user:** Staff-pilgrim, pilgrimage-road militia, septon on circuit
- **Rarity:** common (Faith), uncommon (elsewhere)
- **Storyline links:** B (Septon Silas walks with one from Wolfsjaw to Stoneford); C (the militia-ring around the Mistmere cathedral at the summit)
- **Notes:** Not a swearing-object. Faith swears on stone, not on wood. The staff is walk and defence only.

### Free North Short-Bow / *ridge-runner bow*
- **Category:** weapon
- **Origin:** Free North, ridge-runners
- **Description:** A plain yew-stave bow, four feet, nocked in horn, strung with clan-twisted gut. The grip is bound in a strip of the archer's own clan-plaid. Draws heavy for its size.
- **Typical user:** Ridge-runner scout, harrying war-band
- **Rarity:** common (Free North)
- **Notes:** Good for ambush-range in valley cover. Useless at rank-and-file distance.

### Honest Short-Sword / *Exchange blade*
- **Category:** weapon
- **Origin:** Union, Greyharbour Watch issue
- **Description:** A straight double-edged blade, two feet in length, blackened hilt, a small brass weight-mark on the cross-guard reading *honest to the tempering*. Kept in a plain russet scabbard.
- **Typical user:** Exchange Watchman, dock warden, caravan-guard
- **Rarity:** common
- **Notes:** Not a duellist's weapon. A tool for close-quarters at the dock, on the ledger side of a warehouse.

### Pilgrim-Sling / *stone-sling*
- **Category:** weapon
- **Origin:** Faith, hill-born pilgrims
- **Description:** A braided leather sling the length of a forearm, weighted with a single knot at the pouch. Carried wrapped around the wrist beneath the sleeve. Launches a grey river-pebble.
- **Typical user:** Faith militia, hill-born shepherds
- **Rarity:** common
- **Notes:** Silent. The Faith's one permitted ranged weapon; an arrow is *ink without a word*, but a stone is a stone.

### Butcher's Knife / *kitchen blade*
- **Category:** weapon
- **Origin:** every culture
- **Description:** A broad-bladed knife nine inches long, bone or ironwood handle, the edge ground until it will take hair off a forearm. Used for the autumn cull. Used, on three nights in ten years, for worse.
- **Typical user:** every hearth
- **Rarity:** common
- **Notes:** A butcher's knife is a butcher's knife.

### Courier-Dirk / *Windrest slip*
- **Category:** weapon (improvised)
- **Origin:** Union couriers, Free North road-folk
- **Description:** A slim dagger four inches in the blade, tucked into a boot-sheath or the seam of a courier satchel. Grip of twisted cord. No guard.
- **Typical user:** Couriers, letter-carriers, any walker of the night road
- **Rarity:** common
- **Storyline links:** C (Jenn carries one; never draws it)
- **Notes:** Drawn quickly. Not drawn twice.

### Smith's Hammer-turned-weapon
- **Category:** weapon (improvised)
- **Origin:** any forge
- **Description:** A shaping hammer, two-pound head, hickory handle blackened by the fire it stands beside. In a riot, it is reached for without thought. The soot at the grip is a smith's own sweat.
- **Typical user:** blacksmith, forge-apprentice, grain-rioter
- **Rarity:** common
- **Storyline links:** D (Durm's forge at Windrest; the un-hammerable metal lump sits beside such a hammer, unmarked)
- **Notes:** Crushing work. The grain-riot at Stoneford was quelled by men carrying these, on both sides.

### Frostwolf Sabre / *Khanate steel*
- **Category:** weapon
- **Origin:** Frostwolf Khanate (north border, beyond the five towns)
- **Description:** A curved single-edged sabre of three feet, worn high on the hip. The scabbard is felt-wrapped wood bound in white hide. The pommel is carved as a wolf's head, small enough to close a fist around.
- **Typical user:** Frostwolf envoy, border horseman
- **Rarity:** scarce
- **Storyline links:** C (the Hollowjaw pack left a dead Frostwolf envoy with his sabre still sheathed — Q_T002_02)
- **Notes:** Drawn, it is held to be a diplomatic breach. Sheathed, it is a reminder.

### Sapper's Pick / *miner's pry*
- **Category:** weapon (improvised) / tool
- **Origin:** Jadehollow, Deepvein Company
- **Description:** A two-foot pick with a straight point one side, a flat pry the other. Hickory haft. The head is stamped faintly *Deepvein* along its collar.
- **Typical user:** miner, Listener Depth-Walker
- **Rarity:** common (Jadehollow)
- **Storyline links:** E (Listener cells carry these as tool, as weapon, as lever against stubborn relic-stone)
- **Notes:** First a tool. Second a weapon. Third a ladder-foot.

---

## II. Armour & Clothing

### Linden Mail / *grey-coat mail*
- **Category:** armour
- **Origin:** Crown, House Linden
- **Description:** Riveted iron mail from nape to knee, worn over a padded gambeson of dark grey wool. A grey surcoat laid over, the single black oak of House Linden stitched at the breast. The mail is oiled weekly; the surcoat is replaced once a year, at the summer Cut.
- **Typical user:** Linden foot
- **Rarity:** restricted (House issue)
- **Storyline links:** C (Ironfist's company)
- **Notes:** Heavy. The grey surcoat is a kindness for the eye: a Linden company in the field looks like a wall of weather, not of men.

### Greyhold Plate Inlay / *the pale line*
- **Category:** armour (ceremonial / field)
- **Origin:** Free North, Greyhold chieftess-line only
- **Description:** Boiled leather at the chest and shoulder, stained black; across the collar and vambrace, a narrow line of pale metal worked flush into the leather, no wider than a finger. The metal does not take a scratch and catches the light strangely, even at dusk.
- **Typical user:** Chieftess of Greyhold; three named warriors of long service
- **Rarity:** restricted (chieftess-line)
- **Storyline links:** C (Brenna's armour at Mistmere); D (the Stoneford un-hammerable metal lump is the same substance, unacknowledged)
- **Notes:** The line never sells this metal. The Greyhold reserve is, by Brenna's own count, enough for one more generation of armour.
<!-- writer-only -->
- **Real mechanic:** Colonial alloy. Non-ferrous, non-forgeable by northern technique. Same substance as Durm's lump (D) and the Mossbarrow fragments. Greyhold inheritance traced to *gjord-jern* — "made-metal."
<!-- /writer-only -->

### Clan-Plaid / *the wearing*
- **Category:** clothing (ceremonial and daily)
- **Origin:** Free North, each clan distinct
- **Description:** A long woven cloak, wool on wool, in the clan's pattern — Greyhold is dark grey and pale blue in a narrow check; Stoneshield is moss and black; Karn is brown and oat. Pinned at the left shoulder with a bronze brooch cast to the clan sigil.
- **Typical user:** every clansfolk
- **Rarity:** common (to the clan)
- **Storyline links:** C (Ylva and Yura both Stoneshield, both wearing the same plaid, divided by oath)
- **Notes:** Never worn across clans. A clansfolk in another clan's plaid is challenged. A plaid is cut, publicly, as punishment for a broken plaid-oath.

### Septa's Robe / *wet-ash grey*
- **Category:** armour (ceremonial)
- **Origin:** Faith
- **Description:** A full-length robe, heavy wool, dyed in boiled wet-ash until the colour is almost black at the hem and grey at the shoulder. Cut straight, beltless, falling to the floor. A collar of stiffened wool, undyed on a septon, grey on a Septa, silver-threaded with the nine-ring pattern on the High Septa.
- **Typical user:** Septa, septon, High Septa
- **Rarity:** restricted (ordained only)
- **Storyline links:** C (Malen at the summit)
- **Notes:** No head-covering indoors. A Septa's robe is the only grey in the Reach that is sworn on.

### Pilgrim's Grey Surcoat
- **Category:** armour (militia)
- **Origin:** Faith, pilgrim militia
- **Description:** A padded grey surcoat of layered linen and cheap wool, knee-length, open at the sides for movement. A single grey cord tied at the waist. No sigil.
- **Typical user:** staff-pilgrim, pilgrimage-road volunteer
- **Rarity:** common at cathedrals
- **Notes:** Padding enough to turn a stone, not a blade. Drilled once each autumn and set aside.

### Exchange Coat / *merchant-coat*
- **Category:** clothing (ceremonial)
- **Origin:** Union
- **Description:** A long coat of house-coloured wool — Caul russet, Greyharbour slate, Mistmere-branch ochre — cut to the calf, cuffs turned back in black linen. The merchant-chain is worn across the chest, weight-clasps hanging in order of pledging.
- **Typical user:** Exchange-seated merchant, Senior Weight, Consul-Merchant
- **Rarity:** uncommon
- **Storyline links:** C (Tobiah's Caul russet, twelve clasps; the twelfth marked *private collection*)
- **Notes:** A coat with more clasps than its wearer has years of service is a lie worn in public.

### Merchant-Chain / *the weights*
- **Category:** clothing (oath-object)
- **Origin:** Union
- **Description:** A chain of alternating brass and silver links, each clasp a small medallion stamped with a publicly-pledged weight: *salt-fish honest to the pound*, *paper honest to the signature*, *courier-seal*. Worn from shoulder to shoulder across the Exchange coat.
- **Typical user:** chartered Union merchant
- **Rarity:** uncommon
- **Storyline links:** C (Tobiah's twelfth clasp, the one the three other crowns read silently)
- **Notes:** A clasp can be stripped in public. The stripping takes as long as the pledging took.

### Seal-Leather Boots / *coast boots*
- **Category:** clothing
- **Origin:** Free North coast clans, Union dockhands
- **Description:** Thigh-high boots of tough seal-leather, black from fish-oil rubbed in yearly. Sole is double-stitched, heel is low. Smell stays on a man for a week after he takes them off.
- **Typical user:** coast clansfolk, stevedores, ferrymen
- **Rarity:** common (coast), scarce (inland)
- **Notes:** Keep the foot dry for as long as the leather lasts. The leather lasts.

### Greymantle Cloak
- **Category:** clothing (travel)
- **Origin:** Free North; the dye-style from Wolfsjaw fullers
- **Description:** A hooded cloak of shaleback wool, dyed in layered greys to the colour of wet stone under rain. Heavy. Sheds water for three hours before it wearies. Lined inland with undyed linen.
- **Typical user:** traveller of any culture
- **Rarity:** common
- **Notes:** The cloak a road-rider hopes he is wearing when the fog closes.

### Ash Cloak / *fog-walker cloak*
- **Category:** clothing
- **Origin:** Fog, valley-dyed
- **Description:** An undyed or wet-ash-dyed wool cloak with a deep hood, no fastening but a bone toggle at the throat. No lining. No mark. Worn long, to the boot-top, frayed at the hem from valley-walking.
- **Typical user:** fog-walker
- **Rarity:** uncommon
- **Storyline links:** C (the Herald wears one; Jenn does not, yet)
- **Notes:** A fog-walker with any visible kingdom-mark under the ash is suspect. The cloak is the uniform of refusal.

### Southern Doublet
- **Category:** clothing (ceremonial)
- **Origin:** Crown
- **Description:** A tight-fitted doublet in dark green or dark blue, silver piping at cuffs and collar, horn buttons down the front. Worn over a plain linen shirt. The king wears a plain grey version with no piping, because ornament is beneath the throne.
- **Typical user:** court attendant, envoy
- **Rarity:** uncommon
- **Notes:** Not worn in the field. A Voss envoy at a Free North clan-hall in a southern doublet will be served first and spoken to last.

### Four-Knot Thumb-Ring
- **Category:** clothing (royal mark)
- **Origin:** Crown, royal line only
- **Description:** A ring of dull gold, four-knot pattern pressed into the face, the centre of the knot empty. Worn on the left thumb. Never removed. The pattern is shallow now on old kings' rings, worn by decades.
- **Typical user:** Crown royal-born (king, King-Apparent)
- **Rarity:** restricted
- **Storyline links:** C (Darrik's ring, read silently by every House-born at the summit)
- **Notes:** Burned with the king when he dies. The empty centre is the same shape as the Herald's mask.

### Oilskin Hood & Coat
- **Category:** clothing (weather)
- **Origin:** Union coastal, Free North coast
- **Description:** A waxed canvas coat to mid-thigh, matching hood that buttons under the chin. Yellowish with age. Smells of whale-fat.
- **Typical user:** fishermen, ferry-crew, caravan-drivers in wet season
- **Rarity:** common (coast), uncommon (inland)
- **Notes:** Stiff in cold. Sweats the wearer in warmth. Worth the bargain.

---

## III. Travel & Survival

### Road Lantern / *guild-lantern*
- **Category:** travel
- **Origin:** Union manufacture, every kingdom uses
- **Description:** A brass-framed lantern the size of a loaf, four panes of horn (not glass — glass breaks on the road), a hinged top for the wick. Burns tallow or cheap lamp-oil. A leather loop at the top for slinging from a saddle.
- **Typical user:** every traveller
- **Rarity:** common
- **Notes:** Not a Depth-Walker ritual lantern. This is what a Caul courier carries on the Jade Road at dusk.

### Waxed-Linen Map-Case
- **Category:** travel
- **Origin:** Union cartographer guild
- **Description:** A cylindrical case of waxed linen over a willow-frame, end-caps of turned beech, a shoulder-strap of braided hemp. Holds a rolled map twelve inches long without creasing.
- **Typical user:** courier, caravan-master, envoy
- **Rarity:** uncommon
- **Notes:** A Union courier's first investment. A lost map-case is a week's wage.

### Jade Road Map
- **Category:** travel
- **Origin:** Union cartographer guild, Stoneford branch
- **Description:** A linen sheet two feet square, inked in black and pale green, marking the Jade Road from Stoneford through Windrest and Wolfsjaw to Jadehollow and Mistmere. Every inn is named. Every ferry-fee is noted in the margin. The Mossbarrow is not on it.
- **Typical user:** merchants, couriers
- **Rarity:** common
- **Storyline links:** A (the absence of the Mossbarrow on every official map is the first breadcrumb); D (straight-line cloud sightings pencilled in and later erased)
- **Notes:** Updated every five years. The current edition still lists a ferryman dead three winters.

### Weather-Stone / *storm-pebble*
- **Category:** travel
- **Origin:** Free North, folk-tradition; adopted by Union couriers
- **Description:** A thumb-sized pebble of dark slate, tied into a leather pouch, worn against the skin beneath the shirt. In dry air it is dry. In coming rain it darkens, the leather pouch staining a shade damper.
- **Typical user:** shepherds, couriers, any walker of the high moor
- **Rarity:** common
- **Notes:** Not a magic-stone. A hygroscopic mineral, read honestly. A Faith commoner keeps one alongside a pilgrim-stone, and does not confuse them.

### Fire-Striker Kit
- **Category:** travel
- **Origin:** every culture
- **Description:** A small iron striker curled for the finger, a piece of flint, a tin of charred linen tinder. Carried in a leather pouch that hangs off a belt or cloak-toggle. The tin is stamped with the owner's mark.
- **Typical user:** every traveller
- **Rarity:** common
- **Notes:** A wet striker is a cold night.

### Climber's Rope / *Greyharbour cord*
- **Category:** travel
- **Origin:** Union Greyharbour ropers
- **Description:** Three-strand hemp rope, inch-thick, tar-treated black at the ends to stop fraying. Coiled in six-fathom lengths. Every tenth fathom marked with a dyed thread: red at five, green at ten.
- **Typical user:** miners, Depth-Walkers, sailors
- **Rarity:** common
- **Storyline links:** E (Listener cells buy by the coil under a standing Exchange contract)
- **Notes:** The rope knows its weight. Do not ask it for more.

### Waterskin / *road-skin*
- **Category:** travel
- **Origin:** every culture
- **Description:** A goat-hide skin, two quarts, stitched at the seam with waxed gut. A horn stopper tied by a cord. Old skins stain the water faintly sour; new ones taste of the tanner.
- **Typical user:** every traveller
- **Rarity:** common
- **Notes:** A Free-North skin is lined with clan-dye and turns the water faintly blue on long marches. No one has died of it.

### Camp Kettle / *three-leg pot*
- **Category:** travel
- **Origin:** every kingdom, Union-forged
- **Description:** A cast iron pot with three stubby legs, handle-bail of twisted iron. Blackened inside and out. A small hinged lid, holes for a suspending chain.
- **Typical user:** every traveller
- **Rarity:** common
- **Notes:** Heats water for a dozen men or stew for four. Heavier than the horse wants.

### Iron Travelling-Bell
- **Category:** travel
- **Origin:** Union practice, adopted by Faith for fog-travel
- **Description:** A small iron hand-bell, four inches tall, a leather strap at the crown. The clapper is a chip of river-flint, not iron, so the tone is soft. Hung off the lead rider's saddle in fog.
- **Typical user:** caravan-master, septon in fog-valley, fog-walker who has broken habit
- **Rarity:** common
- **Storyline links:** C (the Herald carries one; she has not rung it in nine years)
- **Notes:** Honest purpose: collision-warning in bad visibility. Folk purpose: keeps the hollow raven from following.

### Union-Pattern Courier Satchel
- **Category:** travel
- **Origin:** Union
- **Description:** A flat leather shoulder-bag, a buckled flap, inside three oilskin-lined pockets sized for folded letters, a wax tablet, and a sealed contract. The strap is sewn to bear a full ledger's weight without creasing.
- **Typical user:** Caul & Sons courier, Exchange clerk
- **Rarity:** uncommon
- **Storyline links:** C (Jenn's satchel, the Herald's letter folded inside the inner pocket)
- **Notes:** A courier's satchel is her office. It is not surrendered except at death.

---

## IV. Tools & Crafts

### Smith's Anvil-Peg / *the forge-log*
- **Category:** tool
- **Origin:** every forge
- **Description:** A hardwood log, chest-high, set in packed earth, the anvil pinned to its top with an iron peg. The wood is charred black at the rim from stray sparks. A smith's hand-prints darken the near side.
- **Typical user:** every smith
- **Rarity:** common
- **Notes:** A forge without a peg is a forge without a memory. The peg outlives the smith.

### Durm's Cold-Set / *the refusal hammer*
- **Category:** tool
- **Origin:** Windrest; Durm's forge
- **Description:** A heavy cold-chisel, the head flat and dulled from being struck against metal that would not cut. The handle is a fresh one, replaced last autumn. The previous three handles are stacked beside the forge.
- **Typical user:** Durm (only)
- **Rarity:** scarce (unique tool)
- **Storyline links:** D (Durm's attempts on the un-hammerable metal lump; each failure stored in the stacked handles)
- **Notes:** A smith keeping four handles means he does not want to throw the memory away.

### Carpenter's Adze
- **Category:** tool
- **Origin:** every kingdom
- **Description:** A curved blade set perpendicular to a short haft, the edge kept shaving-sharp. Used for hollowing beams, squaring keels. Wrapped in a leather sheath when not at hand.
- **Typical user:** Free North ship-carpenters, Crown beam-cutters
- **Rarity:** common
- **Notes:** A clumsy carpenter's adze has cost more toes than every border war.

### Surgeon's Kit / *Merle's roll*
- **Category:** tool
- **Origin:** apothecary guild, every town
- **Description:** A linen roll, two feet wide, pockets stitched along its length. Inside: iron probe, two hooked needles, catgut, bone-handled scalpel, a small copper bowl, a twist of wax-sealed river-heal leaf. The whole rolls tight and ties with a bone peg.
- **Typical user:** apothecary, field surgeon, midwife
- **Rarity:** uncommon
- **Storyline links:** A/B (Merle at Stoneford; the roll is Grandmother Green's pattern)
- **Notes:** A good roll is thirty years of knowing where the fingers must go in the dark.

### Midwife's Chair
- **Category:** tool
- **Origin:** Faith cathedral-orphanages, Free North clan-halls
- **Description:** A low wooden chair with a half-moon seat, rubbed to a shine by generations of use. Carried between hearths on a shoulder-strap.
- **Typical user:** every midwife
- **Rarity:** common
- **Notes:** The chair is older than the midwife. The midwife is older than anyone else in the room.

### Cartographer's Compass-Rose
- **Category:** tool
- **Origin:** Union cartographer guild
- **Description:** A brass plate four inches across, a spinning iron needle on a pivot, the needle pointing always to *winter north* (the direction from which the longest cold wind comes). Packed in a turned-wood case lined with red felt.
- **Typical user:** Union cartographer, Exchange courier
- **Rarity:** uncommon
- **Notes:** Not a magnetic compass in any modern sense — calibrated by wind-memory, not by lodestone — but it does what a lodestone does, honestly enough.
<!-- writer-only -->
- **Real mechanic:** Actually a magnetised needle. The "winter north" vocabulary is the indigenous reading; the physics is ordinary.
<!-- /writer-only -->

### Miner's Headlamp-Rig
- **Category:** tool
- **Origin:** Jadehollow, Deepvein
- **Description:** A stiff leather cap, a brass clip at the brow holding a small horn lantern the size of a fist. The wick is cotton-twisted; the fuel a cheap tallowcap rendering. Burns two hours of shift before refill.
- **Typical user:** every miner
- **Rarity:** common (Jadehollow)
- **Storyline links:** E (poor Listeners use this when they cannot get Glowfen Rush)
- **Notes:** Smokes. The cap smells of a man's whole working life after a year.

### Scribe's Lap-Desk
- **Category:** tool
- **Origin:** Crown Archivist guild, Union clerk-schools
- **Description:** A flat wooden board, hinged along one side, opening to an inkwell, a well for sand, a groove for pens. The underside bears the scribe's name in pricked dots. Used on the road when no table is given.
- **Typical user:** archivist, Union clerk, Faith preceptor
- **Rarity:** uncommon
- **Storyline links:** A (Archivist Naryn's lap-desk at Wolfsjaw; the half-burned Northern Ban was in its lowest drawer)
- **Notes:** A desk that has travelled is a desk with a scribe still living.

### Brewer's Mash-Paddle
- **Category:** tool
- **Origin:** every hearth, every tavern
- **Description:** A long wooden paddle, hickory or ash, the flat end blackened by years of stirring hot wort. A notch cut at the grip names the brewery by count of strokes: Mira's paddle has two notches, the second re-cut last winter.
- **Typical user:** innkeeper, cathedral cellarer
- **Rarity:** common
- **Notes:** Borrowed between cottages. Never loaned out of the town.

### Potter's Wheel, Valley-Pattern
- **Category:** tool
- **Origin:** Fog valleys; adapted from a Faith cathedral design
- **Description:** A foot-kicked wheel set low in a valley-kiln compound, the stone head worn smooth at the centre, rough at the rim. The axle squeaks in time with the kick.
- **Typical user:** fog-walker potter, valley artisan
- **Rarity:** uncommon
- **Storyline links:** C (the Herald's un-glazed clay masks are fired at such a kiln)
- **Notes:** The masks are thrown, not moulded. A practised thrower makes a blank in under a minute.

---

## V. Currency & Documents

### Ashcrown Royal Silver
- **Category:** currency
- **Origin:** Crown, southern mint
- **Description:** A silver disc the diameter of a thumbnail, four-knot stamped on the obverse, the reigning king's profile on the reverse. Struck deep. Rings clear when dropped on stone.
- **Typical user:** every kingdom accepts it
- **Rarity:** common (in the coinage of means)
- **Notes:** The Reach's preferred large-weight currency. A merchant pays warehouse rent in silver, tavern tabs in copper.

### Honest-Copper
- **Category:** currency
- **Origin:** Union, Greyharbour Exchange
- **Description:** A thin copper disc, crossed scales on the face, a number on the reverse for the year struck. The edge is milled — a Union innovation — so clipping shows. Stamped *Honest Weight* around the rim.
- **Typical user:** dockhand, day-labourer, every small-purchase trader
- **Rarity:** common
- **Notes:** Three honest-coppers to a Faith cathedral copper, six to a Free-North blood-coin (informal rate).

### Faith Cathedral-Copper
- **Category:** currency
- **Origin:** Faith, nine cathedral mints
- **Description:** A thin copper disc, four-knot on the obverse, the pattern-ring on the reverse. Discoloured with use. Accepted only for tithe, for cathedral-goods, for blessed-stones at the Mistmere gate.
- **Typical user:** Faith subject
- **Rarity:** common (Faith towns), discounted (elsewhere)
- **Notes:** A Faith commoner keeps a pouch of cathedral-copper for tithe and a pouch of royal silver for trade.

### Free-North Blood-Coin
- **Category:** currency (debt-token)
- **Origin:** Free North
- **Description:** A small iron disc, the clan's sigil pressed into the face, the owed-debt scratched into the reverse with a clan-knife. Never polished. Accumulates rust as it travels.
- **Typical user:** clansfolk owing, clansfolk owed
- **Rarity:** common (Free North)
- **Storyline links:** C (Brenna sent the Herald a Greyhold-sigil blood-coin — *I have received, and I owe you a word*)
- **Notes:** Not spent. Owed. A blood-coin in a man's purse is a promise he has not yet kept.

### Exchange-Paper / *merchant letter*
- **Category:** currency (credit)
- **Origin:** Union, Greyharbour Exchange
- **Description:** A folded sheet of rag-paper the size of a palm, the Exchange's crossed-scales in blue wax at the fold, the weight and payee written in a clerk's hand. Numbered, dated, witness-signed.
- **Typical user:** merchant-to-merchant, large-weight transfer
- **Rarity:** uncommon
- **Notes:** Redeemable at any chartered Union port. Forging one carries ten years' loss of charter.

### Silver Ticket / *guild-rider pass*
- **Category:** document
- **Origin:** Guild of the Ashen Arbitration (dormant), Union carriage-guild (active)
- **Description:** A small silver plaque, the size of a coin, stamped with a sigil of three interlocking wheels, a rider's guild-name pricked along the lower rim. Pinned inside the coat.
- **Typical user:** chartered guild courier, long-road rider
- **Rarity:** scarce
- **Storyline links:** A (a Silver Ticket was found under the Stoneford tavern hearth beside the old Guild brass token — same three-wheel mark)
- **Notes:** Three tiers exist and are not much written about. The ticket opens some gates and costs others.

### Brass Ticket / *road-ticket*
- **Category:** document
- **Origin:** Union carriage-guild
- **Description:** A brass disc the size of a coin, the three-wheel sigil pressed shallow, the rider's guild-name on the reverse. Plain. Worn on a cord at the throat under the shirt.
- **Typical user:** journeyman courier, road-guard
- **Rarity:** common (along trade roads)
- **Notes:** The brass tier is the entry tier. Most couriers never hold another.

### Sealed Letter, Crown Form
- **Category:** document
- **Origin:** Crown court
- **Description:** A folded parchment sheet, the four-knot ring pressed into dark red wax at the fold (or, on the most private letters, a wax without the centre-knot — a blank pressing). The writing is in Crown southern, slow and small.
- **Typical user:** royal envoy, Morning Table clerk
- **Rarity:** uncommon
- **Storyline links:** C (every Crown note of the summit passes in this form)
- **Notes:** An unopened Crown letter is worth what the king remembers. An opened one is worth a Linden blade, asking how.

### Honest-Weight Writ
- **Category:** document
- **Origin:** Union, Exchange-posted
- **Description:** A full-sheet document, two seals (sender and witness) along the bottom, the contract clauses numbered and read aloud at signing. Posted on the Exchange wall for thirty days before filing.
- **Typical user:** every merchant agreement
- **Rarity:** common
- **Notes:** The Union's core legal instrument. A writ not entered in the Central Ledger is not a writ.

### Pilgrim's Pass
- **Category:** document
- **Origin:** Faith
- **Description:** A strip of undyed linen the length of a forearm, a Septa's thumbprint in grey ash at one end. Tied to the wrist. Admits the bearer to any cathedral cloister for a night's sleep.
- **Typical user:** pilgrim
- **Rarity:** common (Faith)
- **Notes:** Unsealed. Unwritten. Read by the pattern of the ashprint, which no two Septas make alike.

---

## VI. Consumables

### Ash-Cake / *royal ration*
- **Category:** consumable (food)
- **Origin:** Crown
- **Description:** A dense dark flatbread, baked twice — once soft, once hard — with rendered pork-fat and a ribbon of grey salt pressed through the middle. Bites dry. Softens with ale. Keeps three weeks in a waxed bag.
- **Typical user:** royal courier, Voss horse
- **Rarity:** common (Crown issue)
- **Notes:** A Crown rider eats three ash-cakes a day and nothing else between capitals.

### Stone-Bread / *septon biscuit*
- **Category:** consumable (food)
- **Origin:** Faith
- **Description:** A hard biscuit of rye flour, grey salt, and goat-fat, baked until it rings when struck against a stone. Grey. Breaks teeth taken dry.
- **Typical user:** pilgrim, septon on circuit
- **Rarity:** common (Faith)
- **Notes:** A pilgrim's ration is three a day. Softened in goat-milk, it is a meal. Soaked in blood, it is a Free-North scandal.

### Blood-Sausage / *clan-smoke*
- **Category:** consumable (food)
- **Origin:** Free North
- **Description:** A thick sausage, dark almost to black, made of sheep's blood, rendered fat, barley, hill-salt, and thyme, stuffed in gut and smoked in rafters for three weeks. Cut in finger-thick coins. Eaten cold with cheese.
- **Typical user:** every clansfolk
- **Rarity:** common (Free North)
- **Notes:** Taboo to the Faith (*ink for food*). A Union merchant will eat it and note the price. A Crown envoy will refuse it politely.

### Salt-Fish Fillet / *Caul cure*
- **Category:** consumable (food)
- **Origin:** Union, coastal
- **Description:** A fillet of cod or pollack, split, salted heavy, dried until stiff as board. Sold in half-pounds stamped *Honest Weight, Honest Word*. Wrapped in waxed linen.
- **Typical user:** every Union hearth; traded inland
- **Rarity:** common
- **Notes:** Three meals a week in any Caul household. Soaked overnight before cooking. Eaten dry on the road.

### Wind-Meat / *high-cure*
- **Category:** consumable (food)
- **Origin:** Free North upland
- **Description:** A strip of mutton hung in the high-valley wind for two months, no smoke, only cold and air. Blackened on the outside, dark red within. Chewed, not cut.
- **Typical user:** clan-scout, ridge-runner
- **Rarity:** common (Free North)
- **Notes:** A week's wind-meat in a leather pouch weighs a pound and feeds a scout four days.

### Ship's Biscuit / *Union double-bake*
- **Category:** consumable (food)
- **Origin:** Union
- **Description:** A hard barley cake, double-baked, pale beige, stamped on one face with the Caul house-words. Keeps three months in a dry hold.
- **Typical user:** Union courier, sailor
- **Rarity:** common
- **Notes:** Not eaten dry except in bad weather. A cup of thin beer softens it enough for teeth that still want to serve their owner.

### Amber Tea / *leaf of the long breath*
- **Category:** consumable (drink)
- **Origin:** Crown (ostensibly imported); unknown true origin
- **Description:** A dried leaf the colour of old honey, brewed for a fixed four minutes in a brass cup, the steep-time counted in slow breaths by the server. The cup clouds faintly even in warm air.
- **Typical user:** Crown royal-born; the King-Apparent's inner retinue
- **Rarity:** restricted
- **Storyline links:** C (Darrik at the Morning Table; Alric's travel-brew at the Jade Lantern); Tobiah's Mistmere warehouse holds a consignment he has not read
- **Notes:** Drunk only by the royal line. Offered as gift only at summit. A commoner served amber tea has either been brought into a royal secret or is about to disappear.
<!-- writer-only -->
- **Real mechanic:** A far-side preservative compound. Extends lifespan; thins hair in late middle age. Crown vocabulary: *preservative compound*. Indigenous vocabulary: *the leaf of the long breath*.
<!-- /writer-only -->

### Widow's-Mint Tea
- **Category:** consumable (drink / medicine)
- **Origin:** Faith, commoner hearths
- **Description:** Dark-mint leaves dried on a stone, steeped in hot water until the brew runs green-black. Drunk at dusk for grief, for sleep. A small pinch of honey permitted.
- **Typical user:** Faith widow, the sleepless
- **Rarity:** common
- **Storyline links:** C (Malen drinks this nightly; it does not help)
- **Notes:** Calms the stomach. Does not calm the mind, whatever the septons say.

### Ashroot Chew
- **Category:** consumable (medicine)
- **Origin:** northern woods
- **Description:** A pale bitter root, sliced and dried, kept in a small tin. A sliver chewed on a long ride; the bitterness lingers an hour.
- **Typical user:** courier, night-rider
- **Rarity:** uncommon
- **Notes:** Keeps a man awake for a night. Two nights will cost him the third day.

### Greenbane Poultice
- **Category:** consumable (medicine)
- **Origin:** moor-women; denied by the Faith
- **Description:** Crushed greenbane leaves bound in a square of undyed linen, soaked in hot water, pressed to a fevered chest. Smells of bruised pepper.
- **Typical user:** midwife, apothecary
- **Rarity:** scarce (actively suppressed)
- **Storyline links:** A/B (Merle's stock; Grandmother Green's last Jadehollow patch)
- **Notes:** The one reliable treatment for green-lung fever. Carrying a pouch of it in a Faith town is a fine and a sermon.

### River-Heal Bandage
- **Category:** consumable (medicine)
- **Origin:** every kitchen garden
- **Description:** A broad grey-green leaf, bruised in the palm, laid sap-down over a cut. Held with a strip of linen. Smells faintly of iron.
- **Typical user:** every hearth
- **Rarity:** common
- **Notes:** Stops a small bleed. Not enough for a deep cut. Still reached for first.

### Clan-Ale / *feast-draught*
- **Category:** consumable (drink)
- **Origin:** Free North
- **Description:** A dark barley ale brewed in single-cask batches, drawn only at feast. Pours thick. Tastes of smoke and heather. A pint slows a warrior. Three pints stops him.
- **Typical user:** clansfolk at feast
- **Rarity:** scarce outside Free North
- **Notes:** A clan-hall opens one cask at the midwinter Circle and one at the summer Run. A third is unheard-of.

### Jawbeer / *sour-rye*
- **Category:** consumable (drink)
- **Origin:** Wolfsjaw garrison; Jadehollow cellars
- **Description:** A sour rye beer brewed with northrye grain. Cloudy. Tastes like a cellar smells. Preferred by garrison cooks and Jadehollow miners.
- **Typical user:** soldiers, miners, garrison staff
- **Rarity:** common (Wolfsjaw, Jadehollow)
- **Notes:** Cheap. Keeps a week in clay. The Faith cathedrals will not serve it and accept it as tithe anyway.

### Pilgrim Wafer
- **Category:** consumable (sacred food)
- **Origin:** Faith, cathedral-baked
- **Description:** A small disc of unleavened flour-and-water bread, pale, blessed by a Septa, placed on the tongue of a supplicant during the Pattern-rite. Made from cathedral-granary grain only.
- **Typical user:** supplicant at rite
- **Rarity:** uncommon
- **Notes:** Eating a wafer returned is the Faith's quiet shame — the offender must eat his own broken oath in public before the Septa.

---

## VII. Miscellaneous

### Pilgrim's Grey Stone
- **Category:** misc (ritual)
- **Origin:** Faith, Mistmere cathedral altar
- **Description:** A small smooth pebble of wet-ash stone, size of a thumbprint, blessed at the altar and given to a pilgrim at the tenth day. Kept in a pouch at the belt, at the hearth, or in the palm of a sleeping hand.
- **Typical user:** every Faith pilgrim
- **Rarity:** common (Faith)
- **Notes:** Folk belief: the stones hear prayers and sometimes answer. Septons discourage this. The High Septa, in private, practises it.

### Clan Brooch / *plaid-pin*
- **Category:** misc (cultural)
- **Origin:** Free North, each clan distinct
- **Description:** A bronze brooch cast to the clan sigil — Greyhold a cairn-knot, Stoneshield a shield-eye, Karn a single axe. Pin and clasp on the back. Worn at the left shoulder, pinning the plaid.
- **Typical user:** every clansfolk
- **Rarity:** common (to the clan)
- **Notes:** A brooch is given at the child's first hearth-ash. Kept for life. Buried with the body.

### Four-Knot Prayer Cord
- **Category:** misc (ritual)
- **Origin:** Faith, commoner practice
- **Description:** A length of undyed linen cord two feet long, tied in the four-knot pattern at each end and at the middle. Worn at the wrist in place of a hat removed at the cathedral gate.
- **Typical user:** pilgrim
- **Rarity:** common
- **Notes:** Kept for the length of a pilgrimage. Burned at its end.

### Counting-String / *Union worry-knot*
- **Category:** misc (personal)
- **Origin:** Union, commoner practice
- **Description:** A hemp cord two feet long, seven plain knots at even spacing, worn at the wrist or pocket. Fingered when counting, when worried, when waiting at the Exchange.
- **Typical user:** Union merchant, apprentice
- **Rarity:** common (Union)
- **Notes:** No theology. A comfort. A Union child's counting-prayer.

### Sailor's Knot-Sampler
- **Category:** misc (cultural)
- **Origin:** Stoneford wharf; Greyharbour ropers
- **Description:** A short cord hung beside a door, tied in six knots representing six voyages. New knots added on return; old ones untied only when the hand who tied them has died.
- **Typical user:** coast clansfolk, Union dockhands
- **Rarity:** common (coast)
- **Notes:** A door with an empty cord is a door of a new family.

### Child's Wooden Pony / *shalepony-toy*
- **Category:** misc (children's)
- **Origin:** every carpentry shed
- **Description:** A whittled pony the length of a hand, a tuft of wool tacked for the mane, the eyes two beads of dark horn. Carried everywhere for four years and then forgotten in a chest.
- **Typical user:** Reach children
- **Rarity:** common
- **Notes:** A Greyhold carpenter carves the mane longer. A Mistmere one leaves it unpainted.

### Bone Gaming-Pieces / *four-knot stones*
- **Category:** misc (gaming)
- **Origin:** every tavern
- **Description:** A set of twelve small bone counters, one face flat, one face notched with a four-knot, played on a grid scratched into a tabletop. Rules vary town by town.
- **Typical user:** drinkers, off-duty garrison
- **Rarity:** common
- **Notes:** Stoneford rules and Wolfsjaw rules will not agree on whether a centred counter can jump a corner. Arguments have outlasted empires.

### Bone Whistle / *shepherd's call*
- **Category:** misc (tool / signal)
- **Origin:** Free North, Wolfsjaw moor
- **Description:** A four-inch shinbone of a moor-hare, two finger-holes bored, one air-hole at the mouth. Hung from a cord around the neck. Carries a call a half-mile across moor in still air.
- **Typical user:** shepherds, ridge-runners
- **Rarity:** common (moor)
- **Storyline links:** D (Bram's whistle; two notes for a lost ewe, three for a wolf, one held long for the named-wolf)
- **Notes:** A whistle is tuned by breath, not by reed. No two sound alike.

### Old-Tongue Potsherd
- **Category:** misc (pre-collapse)
- **Origin:** buried across the Reach; surfaced in ploughed fields
- **Description:** A shard of fired grey clay, the edge glaze-smooth, the inner surface bearing a fragment of old-tongue script — a line, three characters, a half-word. The glaze is cold to the touch even at a summer hearth.
- **Typical user:** ploughman, mason, child
- **Rarity:** uncommon
- **Notes:** *Pre-collapse.* Ordinary when found; treasured when sold; suppressed when read by a scholar. No commoner reads the script. Most potsherds end as cottage door-weights.
<!-- writer-only -->
- **Real mechanic:** Pre-collapse (old-tongue era) pottery. Ordinary utility ware of the colonial period. Surface fragments are not relic-class — they are archaeology. A complete vessel would be catalogued under relics.
<!-- /writer-only -->

### Buried Coinage / *old-penny*
- **Category:** misc (pre-collapse)
- **Origin:** buried across the Reach
- **Description:** A small, tarnished coin, not matching any living mint — the edges regular as if cut by a tool no Reach smith uses, the obverse bearing a face in clean profile, the reverse a geometric knot that is not quite a four-knot.
- **Typical user:** children who find them; moor-women who sell them
- **Rarity:** scarce
- **Notes:** *Pre-collapse.* Worn on cords by some, pocketed by others. Union clerks log them under *foreign coinage, unattested mint, sentimental weight*. Faith septons confiscate and bury.

### Valley-Pipe / *fog-walker reed*
- **Category:** misc (instrument)
- **Origin:** Fog valleys
- **Description:** A simple reed pipe, six finger-holes, a beeswax-sealed mouth-piece. Made by the walker who plays it; unplayed by anyone else.
- **Typical user:** fog-walker, cairn-hermit
- **Rarity:** uncommon
- **Notes:** Played at the common fire of a mist-meet. Never at a kingdom's table.

### Cathedral Bell-Rope
- **Category:** misc (ritual)
- **Origin:** Faith, Mistmere and the nine cathedrals
- **Description:** A thick hemp rope, three-strand, greased annually, ending in a loop sized for two hands. The rope hangs three stories from the bell-chamber to the cloister floor.
- **Typical user:** cathedral bell-ringer, novice
- **Rarity:** restricted (cathedral)
- **Notes:** Rung nine nights at the winter solstice. The bell-rope of Mistmere has been replaced twice in a century. The old ropes are stored, coiled, in the cathedral's north cellar.

### Hearth-Root Ash-Box
- **Category:** misc (ritual)
- **Origin:** Free North, clan-hearths
- **Description:** A small iron box, the size of a fist, holding the ash of the clan's hearth-root tuber, burned after the autumn naming. Kept at the chieftess's right hand during the winter Circle.
- **Typical user:** chieftess, clan-elder
- **Rarity:** restricted (clan-line)
- **Storyline links:** C (Brenna carries hers to Mistmere; the other three crowns do not recognise it)
- **Notes:** The ash is touched to a child's navel at the first hearth, to a warrior's forearm at the first oath, to a chieftess's brow at the blooding. When the box is empty, the clan is held to have ended.

### Un-Glazed Clay Mask-Blank
- **Category:** misc (cultural / Fog)
- **Origin:** Fog valley-kilns
- **Description:** A plain un-glazed clay mask, eye-holes and nostril-vents cut, no mouth, no mark. Fired at a valley-kiln in under a morning. The wearer makes her own and replaces it when it cracks.
- **Typical user:** the Ashen Herald; any fog-walker who takes on an arbiter's speaking at a mist-meet
- **Rarity:** scarce
- **Storyline links:** C (the Herald's; Endpoint 5 — the player receives a fitted mask at the Mistmere harbour at dusk)
- **Notes:** The mask is not a hiding. The mask is a speaking. The clay is thick enough to change a voice, thin enough to carry it.

### Fog Cairn-Sign
- **Category:** misc (signal)
- **Origin:** Fog
- **Description:** Three flat stones stacked at a path's fork, the uppermost balanced at an angle the wind will not take for a day. A mist-meet is called by the sign. A fog-walker passing a cairn-sign does not touch it. She reads it and walks on.
- **Typical user:** fog-walker
- **Rarity:** common (fog valleys)
- **Notes:** Not architecture. Not language. A practice.

---

## VIII. Quick Reference

### By storyline

- **Line A (Guild's Buried Charter):** Silver Ticket, Brass Ticket, Scribe's Lap-Desk (Naryn), Road Lantern, Jade Road Map (erasures), Butcher's Knife
- **Line B (World Before the Fog):** Old-Tongue Potsherd, Buried Coinage, Scribe's Lap-Desk, Pilgrim-Staff (Silas), Greenbane Poultice (Merle)
- **Line C (Four-Crown Intrigue):** Four-Knot Thumb-Ring (Darrik), Amber Tea, Greyhold Plate Inlay (Brenna), Clan-Knife (Ylva / Brenna), Hearth-Root Ash-Box (Brenna), Septa's Robe (Malen), Widow's-Mint Tea (Malen), Merchant-Chain (Tobiah), Exchange Coat (Tobiah), Iron Travelling-Bell (Herald), Un-Glazed Clay Mask-Blank (Herald), Sealed Letter Crown Form, Voss Side-Sword (Alric), Linden Long Spear (Ironfist), Union-Pattern Courier Satchel (Jenn), Free-North Blood-Coin (Brenna to Herald)
- **Line D (Iron Dragon Returns):** Durm's Cold-Set, Smith's Hammer, Bone Whistle (Bram), Fogwort (wash), Miner's Headlamp-Rig, Jade Road Map (straight-line cloud sightings erased)
- **Line E (Depth-Walkers):** Climber's Rope, Sapper's Pick, Miner's Headlamp-Rig, Ship's Biscuit, Exchange-Paper (Listener-Exchange contract), Brass Ticket (Kestrel network)

### Most distinctive culture kit

The **Free North** has the most distinctive weapons-and-wear kit: the Greyhold longaxe, the clan-knife, the forearm-oath scar, the clan-plaid, the pale-line inlay, the hearth-root ash-box, and the blood-coin together form a material culture that is legible at thirty paces and cannot be mistaken for any of the other four. The **Union** runs second — the Exchange coat, the merchant-chain, the honest-copper, the exchange-paper, and the crossbow together build a culture of written weight that is almost as visible.

### Taboos to honour

- A clan-knife is never loaned.
- A plaid is never worn across clans.
- A four-knot ring is never removed, and never by any hand but the wearer's fire.
- A Faith subject will not swear on wood or paper; only on stone, wafer, or Septa's palm.
- A Union merchant will not swear abstractly; only on a written clause.
- A fog-walker wears no kingdom-mark under the ash.
- Amber tea is offered only by a Crown royal; being offered it outside court is either a summit moment or a disappearance.
- The un-glazed mask is made by the wearer. It is not given.

---

## IX. Quest Item Registry (Wave 4 wiring)

Canonical IDs for items emitted by quests, dialogues, and theft-paths across T001–T005. Player-facing names follow indigenous prose; bracketed line tags map to storyline.

### T001 — Stoneford

- **ITM.DOC.SILAS_SEALED_LETTER** *(silas_sealed_letter)* — A folded oilskin slip closed with a thumb of grey wax. Septon Silas's hand. The seal is an unbroken circle around a single pressed leaf. To break it is to read; to read is to carry. [Line B]
- **ITM.DOC.HERALDS_LETTER** *(heralds_letter)* — A single page of merchant-cipher closed by a four-knot seal whose centre is empty. The paper smells faintly of cold iron. The reader's hand begins to shake before the eye understands why. [Line C]
- **ITM.DOC.SILAS_GUILD_BRANCH_LETTER** *(silas_guild_branch_letter)* — Silas's letter of introduction to the Jadehollow guild branch, sewn shut along the fold with white thread. Not to be opened on the road. [Line A]
- **ITM.DOC.SHARD_RUBBING** *(rubbing_of_the_shard)* — A square of soft paper pressed dark with charcoal: the shard's inscription, mirrored, in a hand older than the Ban. The paper creases easily; the hand does not fade. [Line B]
- **ITM.CONS.GLOWFEN_RUSH_JAR** *(glowfen_rush_jar)* — A fist-sized clay jar packed with damp moss and three living rush-stems that hold a green glow for one night. Merle's hand-mark is on the lid. Open only at need. [utility]
- **ITM.DOC.CHURCH_CIPHER_FRAGMENT** *(church_cipher_fragment)* — A torn quarter of parchment in the chapel's old running-cipher. Reads like prayer until you turn it sideways. [Line A]
- **ITM.TOK.BRASS_ONE_DOT** *(brass_one_dot_token / brass_token / guild_brass_token)* — A thumb-weight brass disc, the face stamped with one dot off-centre. The Guild's lowest trial token. Heavier than it looks; warmer than it should be. [Line A]
- **ITM.REL.STONE_SHARD_T001** *(stone_shard_T001 / ancient_stone_shard)* — A palm-length grey shard with a hairline of pale metal threading through it. Cool in the hand even on summer roads. Silas carries it wrapped in lambswool. [Line B / Tier-E]

### T002 — Windrest

- **ITM.DOC.NORTH_GATE_PASS** *(north_gate_pass)* — A waxed wooden chit cut to the Captain's tally. Holed once for the cord. Good for one outbound passage of the north gate, no return stamp. [travel]
- **ITM.DOC.GOVERNOR_WRIT** *(governor_writ)* — A folded parchment under the Governor's red seal, the ribbon tied in the Stoneford double-loop. Carries authority without naming an instruction. [admin]
- **ITM.WPN.MILITARY_SHORTSWORD** *(military_shortsword)* — A barracks-issue shortsword, the grip wrapped in oiled hemp, the pommel struck with the keep's tally. The edge is dressed but not loved. [equipment]
- **ITM.DOC.NOLE_DIRECTION_NOTE** *(noles_direction_note)* — A scrap of birch-bark with three landmarks scratched in charcoal: the leaning cairn, the dry creek, the fire-scar pine. Signed with a traveller's slash. [Line D]
- **ITM.MAT.DURM_LUMP_LOAN** *(durm_lump_loan)* — A dull grey ingot the size of two fists. Cool to the touch, refuses the file, takes no hammer-mark. Loaned, not given; Durm wants it back. [Line D / Tier-E]
- **ITM.TOOL.DIRECTIONAL_LANTERN_E** *(directional_lantern_E)* — A hooded oil-lantern with a single shutter cut to throw light eastward. Yannic's mark burnt into the base. [Line E]
- **ITM.TOK.GREYHOLD_TOKEN** *(greyhold_token)* — A thumb of dark horn carved with the Greyhold pale-line. Recognised by Free-North hands; a question to anyone else. [Line C]
- **ITM.DOC.VOSSEL_INTRO_LETTER** *(vossel_intro_letter)* — Preceptor Vossel's letter to the monastery at Mistmere, addressed in his careful copyist's hand. Sealed with a wafer of faith-grey wax. [Line B]

### T003 — Mistmere

- **ITM.DOC.SARA_CASE_NOTES** *(sara_case_notes)* — A bundle of tied paper slips, each a single observation in clipped Septan shorthand. The hand is steady; the content is not. [Line B]
- **ITM.TOK.WOLFSJAW_BADGE** *(wolfsjaw_badge)* — A bronze pin in the shape of a broken jaw. Survivors only. Worn turned inward. [Line C]
- **ITM.DOC.MERICK_AUDIENCE_SEAL** *(merick_audience_seal)* — A wafer of faith-grey wax with the Magister's three-finger press, fixed to a slip naming the bearer. [admin]
- **ITM.DOC.EILIN_SLATE_RUBBING** *(eilin_slate_rubbing)* — A rubbing of Eilin's cell-slate: two glyphs and one date-mark. Same hand. Older than the Ban. [Line B]
- **ITM.DOC.WALL_GLYPH_RUBBING** *(wall_glyph_rubbing)* — Charcoal rubbing of the monastery wall-glyph 上下相通 — *above and below, one passage*. Pressed onto soft paper still smelling of incense. [Line B]
- **ITM.DOC.DEEP_HEARINGS** *(deep_hearings_book)* — Brother Kael's bound book in the monastery library: a hand-copied record of voices heard at the Chasm-mouth across four centuries, organised by date, weather, and listener. The cover is plain calf, the spine cracked twice. Reading it for one full evening will leave the reader hearing a faint second voice for three days. [Line B / E]
- **ITM.DOC.FAITH_DEEPVEIN_PACT** *(faith_deepvein_pact)* — A folded vellum, sewn rather than sealed, between the Faith and the old Deepvein chapter. The signatures are in two hands; one is shaking. [Line A / B]

### T004 — Jadehollow

- **ITM.MAT.UNCUT_CRYSTAL** *(uncut_crystal)* — A dull-faced stone the size of a knuckle, milk-white with one clear window. Mine-debt currency at the Hollow. [trade]
- **ITM.CONS.HEALING_SALVE** *(healing_salve)* — A small horn pot of greenbane-and-tallow paste. Smells of crushed leaf and old fat. One thumb-scoop closes a clean cut by morning. [consumable]
- **ITM.CONS.UNAGING_TEA_DREGS** *(unaging_tea_dregs)* — A finger-width of dark wet leaf scraped from the bottom of Envoy Alric's cup. The leaf does not soften; the smell is amber and old smoke. Holding the dregs makes the tongue numb. [Line C / Tier-E]
- **ITM.DOC.CROSSER_SKETCH** *(crosser_sketch)* — A folded charcoal sketch on miner's paper: a crude figure climbing upward out of a hatched dark, captioned in Crosser-hand *from below, we may rise*. The lines tremble. [Line E]

### T005 — Mistspire / summit

- **ITM.DOC.HARBOUR_WALL_RUBBING** *(harbour_wall_rubbing)* — A long strip of soft paper rubbed against the Greyharbour seawall: a six-line list of ships' names in old-tongue, three of which are not in any Union ledger. [Line C / E]
- **ITM.WPN.THORNWOOD_CANE** *(thornwood_cane)* — A walking-cane of black thornwood, the head turned to a blunt knot. Heavier than it looks. The grip remembers the previous hand. [equipment]

### Indigenous-term glossary (editor note)

- **pale-alloy** *(dungeons-design D001/D005/D007/D008/D009/N001, ambient prose)* — Grandfathered as the in-world indigenous sensory gloss for kor-nor-family metal. Reads as compound-noun in player view, not as modern metallurgy. Do not normalize to "alloy" alone; do not strip the prefix. If a future writer needs an alternative, prefer "pale-metal" or "kor-nor-like metal" — both already legible inside the world.

### Cross-line registry

- **ITM.TOK.BRASS_ONE_DOT** also serves as the *cave-annex trial token* for the Mossbarrow approach (see T001 → D001 hand-off).
- **ITM.DOC.HERALDS_LETTER** is the letter pursued by Jenn through the dockside chase (T001 → T005 Jenn arc).

