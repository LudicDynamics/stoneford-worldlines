# 玩家日志

## Day 1
我抵达了Stoneford。雾气像灰一样贴着水面。人们谈起镇外的Mossbarrow时都压低了声音。
