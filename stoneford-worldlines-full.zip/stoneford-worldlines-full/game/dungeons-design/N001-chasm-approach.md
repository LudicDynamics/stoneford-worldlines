# N001 — The Great Chasm Approach

## Snapshot
A named pit, not a dungeon; the northern edge of the world where the continent opens into a wound wider than any rider has followed. The Listeners have mapped the first two descents; the third and below are named, not walked. Players come to see the mist-line, to test a Listener's rope, or because a name was spoken that requires a descent to unsay.

## Location
- Nearest town: T003 Wolfsjaw Pass, via D004 Brokenspine Watchtrail
- Region: Beyond the Grey Reach, at the north edge of the continent
- Terrain approach: North from D004 Tower Seven along a trackless ridge (R010). Sixteen leagues of windswept stone, no water, no shelter. The trail ends where the ground does. No bird crosses. No rope has reached the bottom. No bridge has ever stood.

## Historical layers
- **Pre-collapse.** The Chasm pre-dates the waves. The colonists did not cross it; they went around it, by the unending road (which the Listeners now gloss as *the transit shelf*). The waves came down by other routes. The upper-rim descent shafts on the south lip are colonial — cut, rimmed, pegged — and their function was not climbing but lowering: cargo, equipment, once perhaps a person tied into a cradle.
- **Faith-era.** The Faith named the Chasm *the wound of saints*. A saint's-road cairn-line runs along the last league of the approach. Malen believes a saint lies at the bottom; she has not been told otherwise by her predecessors.
- **Guild-era.** The Listeners, who are the Guild's deep-water arm, have mapped the first two levels of descent and have instrumented the third with rope-signals only. No Listener has returned from the fourth. The named tiers follow the Relic-tier system, because the tiers *are* the relic-tiers in their clearest form.
- **Current.** The wind on the rim is steady and cold. The mist fills the pit. At dusk, when the mist thins, a watcher sees a far wall — the rumour of stone. No more than that. Veyl has stood at this rim; Kestrel has descended to the second tier twice; Sula has stood at the rim once, and has not descended. Hallen claims, in his raving, to have descended to the fourth. Hallen is not believed.

## Structure — descent tiers (Abyss-core)

**The descent is the dungeon.** Five levels are named. Levels 1–2 are **accessible** in v0.1 — playable, survivable with correct relics. Levels 3–5 are **described for future** — named, instrumented, rope-signalled, but no surfacing has been made from them in living memory.

Each descent incurs a **cost** — a price the Chasm takes that the traveller does not agree to, because the bargain is not offered in words. Costs are described per tier. Costs do not heal with time.

### The Rim / *the wound's edge* / Tier — Surface
- **Listener name:** *the standing-place* / **Faith name:** *saint's mouth* / **Free North name:** *the old stop* / **Common name:** *the rim*
- **Description.** A shelf of dark stone twenty paces deep before the drop. The stone is clean. No dust settles here; the wind keeps it.

  Wind from the pit steady, upward, warm at the rim in winter, cool in summer — backwards from what the valley beyond would give. A hand held out at the edge feels the warmth first on the palm, then on the wrist; it climbs the arm like slow water. In winter the warm updraft softens the ice on a traveller's beard; the beard drips not down but up, tiny beads climbing half a finger before the wind takes them.

  Cairns of stacked stone mark distances: a cairn every hundred paces for the last league, each with a small pale-stone chip set into the top. The chips are colonial-cut — clean edges, flat faces, no chisel-mark. The cairns are not; they are Faith-hands, rough, re-stacked after every windy winter by a saint's-road pilgrim who has never come back in anyone's memory.

  At the edge, the ground is honest. No lip, no crumble. The rock ends, and where it ends the eye has trouble agreeing with the foot. A blindfolded traveller walked toward the edge takes one more step than sight would place: the mist softens the horizon, and the last pace is not where the next pace would be.

  A single **Hollow Raven** roosts at the northmost cairn. It does not fly across the pit. It does not fly at all, most days; it watches. Its feathers are pale at the throat where a raven's feathers should be black — the mist has bleached the vanes over seasons, and the shafts beneath are still dark, so the bird has two colours when the wind parts its plumage. It eats what a traveller leaves. It does not take what a traveller offers.

  The cairn-line runs to the edge and stops. The last cairn is three paces from the drop — not more, not less. Pilgrims in Malen's grandmother's time set a cairn closer, on a night of low mist, and the next morning it was not there. No stones on the ground below where it had stood. No stones on the shelf. The cairn had been eleven stones tall and it was simply gone, and the pilgrims who had built it were the ones who reported its absence; they were believed because they reported it together.

  A pace back from the edge, a shallow hollow worn into the rock — the sitting-place. Two centuries of Listeners have sat in this hollow with their backs to a cairn and their knees drawn up, waiting for weather. The hollow fits a body the size of a small man. A tall man sits in it and his knees are too high. A child sits in it and is lost. Sula has sat in it once. She has not sat in it twice.

  In clear hours — half an hour, maybe, before dusk, when the mist thins from the surface and the far wall rumours itself as a grey line at the horizon — a watcher at the rim can count to two hundred before the mist closes again. The count is steady. Two hundred is the average. A patient watcher has recorded counts from one hundred and forty to two hundred and sixty; the variation has no pattern that a Guild clerk can read.

  *The rim is free.* Standing here takes nothing. Standing here for long, though, is its own patience; the wind does not tire, and the watcher does.

- **Hazards.** Wind. The edge itself — a traveller blindfolded and walked forward loses footing at the wrong step; the edge is not where sight would place it (Mist-illusion). A single **Hollow Raven** roosts at a rim-cairn; it does not fly across the pit.
- **Creatures.** None resident. Ravens.
- **Items / relics.** *Climber's Rope / Greyharbour cord* (ordinary). **Soft-Rope (B-0031)** if loaned by Sula. **The Held Breath (C-0015)** recommended. **Slow-Stone (C-0055)** for lantern-oil. **Bone-Lamp (B-0062)** for descent work.
- **Clues / fragments.** The cairns' pale-stone chips, read with **Wet-Eye (C-0021)**, show faint old-tongue roots: *reh* on the northmost three, *dun* on the last. Great-cliff, ending.
- **Cost.** None. The rim is free.
- **Exits.** Down to Tier 1.

*Ambient.* The shaft's pale-alloy pegs, when tapped with a knife-hilt, give back a note that is not a metal's note. Iron rings. Bronze hums. These pegs answer with a sound that is between a bell and a held breath — a soft, short, almost-vocal *uh*, pitched at the same note every peg, shaft after shaft. A Listener new to the pegs taps them on descent because she cannot help herself. A Listener who has been here many times does not tap. The note is the note of the pegs; it is not meant for her.

*Ambient.* A pilgrim from Wolfsjaw, a woman of sixty, walked the last league to the rim in a summer eight years ago and sat in the sitting-hollow for a day. She did not speak to the Listener who had brought her. At dusk she stood, walked three paces to the edge, and stopped. She stood at the edge for the count of a hundred and then turned and walked back. She returned to Wolfsjaw in the Listener's company. She did not describe what she had seen. She entered the Mistmere ward three months later, not for madness but for a quiet unwillingness to eat. She died that winter. Her name was Mela. Malen has read her record. Malen does not know why she keeps reading it.

*Ambient.* The wind's temperature on the rim is measurably warmer at the moment when the sun goes below the western ridge. The warming lasts a count of forty and then the wind returns to its steady value. The phenomenon is predictable. Obra tallied it. Vela tallies it. No one asks what the warming is. The Listeners who have been here long call it *the sigh.* The Faith does not know this name.

*Ambient.* A Listener sat here for two days, once, and kept a tally of the wind's temperature change. The tally is in the Guild cabinet. It shows no pattern a clerk can read. The Listener was Obra, four winters dead now. She sat in the hollow and the hollow fit her. She wrote the tally in pencil on a slate, wiped it to a master sheet at the hour, and slept between the middle cairn and the northmost, wrapped in a Guild cloak weighted with a stone. She did not dream, she said. She had come to the rim for the not-dreaming.

*Ambient.* The pale-stone chips in the cairn-tops catch lantern-light differently from ridge-stone. Where a ridge-flint will throw back a hard white point, the pale-stone gives the light back softer, wider, a small moon in the palm. Pilgrims have tried to pry one out. The chips do not come loose. The cairns can be unstacked around them, and have been, and the chip sits where it sat, flush with the air, as though it were held from below.

*Ambient.* There is a patch of lichen on the shelf-stone, three paces back from the edge, the shape of a hand with the fingers spread. The lichen is grey-green and tough. It does not spread; it has been that size for as long as Vela has kept the watch. The shape is the shape of a right hand, palm down, fingers splayed. A traveller who fits her own hand to it finds the span a little too large for a woman and a little too small for a man.

### Tier 1 — The Shallow Descent / *the first pit* (Listeners) / *saint's first step* (Faith) / Shallow-find tier
- **Descent-work.** Rope-and-peg descent, forty paces, along a pre-cut shaft rimmed in pale-stone. The pegs are not Listener iron — they are older, pale-alloy, set by a hand not local. They are evenly spaced to the hand's span; the spacing does not vary by a finger. Grip-rubbed, but uncorroded. A hand laid on a peg feels the peg slightly warmer than the shaft-wall beside it.

  The shaft opens into a ledge-chamber.

- **Crossing the threshold.** The first pace onto the ledge, the traveller feels the breath leave them in a way they had not expected. Not a gasp. A small emptying. The lungs give up a measure of air that they had held without knowing, and draw in less to replace it. The count of a breath becomes slightly longer. Most travellers do not notice at this tier. They will, at the next.

  Sula calls this *the toll in advance.* The price is set here. The collection comes below.

  The sensation in the chest is small. A Listener new to Tier 1 may mistake it for the shaft's thin air, for the change of pressure from rim to ledge, for the first kick of descent-nerves. It is not any of these. A Listener who has been here before feels the difference. It is not breathlessness. It is a smaller organ, somewhere inside the breath, handing over a small thing it was holding. The handing-over is quiet. The thing that is handed is not nameable. Obra, who descended seven times in her life, described it in her Guild log as *the step where the lung becomes a tenant.*

  On the threshold, some travellers have wept without warning. The tears are not grief. They are a physical spilling, as when a man's nose runs in cold air and he does not know his nose is running. Sula's senior at Mistmere wept the first time. He did not weep the second. He has said, when asked, that he ran out of that kind of tear.

- **Description.** A chamber the size of a small chapel, carved into the cliff-face inside. The floor is flat and dry. The ceiling is too regular to be a mason's work.

  The outer wall is the Chasm itself — a lip, a drop, and beyond it the mist. The mist here is warm and faintly metallic; it condenses on skin as warm water and does not chill. A handrail of pale-alloy runs along the lip; it has not rusted and it is warm to the touch on the side facing the pit, cool on the side facing the chamber.

  Three stone benches set against the inner wall. Not carved by miners — cut, set, squared by a hand that worked too clean. A sitting man on the middle bench finds the bench exactly the right height; it does not fit Listener bodies and it does not fit Faith bodies. It fits bodies no one has asked about.

  On a bench, an iron cup. Listener tin, Guild-issue, twenty years old. It has been set down carefully, handle to the wall. A drop of water in the bottom catches lantern-light.

  The cup belongs, by its stamp, to a Listener named Sera Vell, who died at T004 of a cough ten winters ago. Her name is on the base, scratched in the hand of a young woman who had not yet learned to steady her knife. She left the cup. Whoever left it did so carefully; a careless setting-down leaves a cup handle-out, for the next drinker. Handle-to-the-wall is how a Listener leaves a cup when she does not expect to drink from it again. Whoever left it, on her way down or on her way up, knew what she was doing.

  The chamber's acoustics are wrong for its size. A hand-clap here does not ring; it is eaten by the ceiling before it becomes a ring. A whisper, though, carries — Kestrel has proven this with Parn at the far bench, two whispers at twelve paces, both heard. The chamber likes small sounds and mutes large ones. Sula has noted this in her log and has not explained it. She does not explain what she cannot measure twice.

  Along the seam where the pale-alloy handrail meets the wall, a line of finer dust — not stone-dust, not lamp-soot — sits in a thin ridge. The dust is pale blue. It is Slow-Stone, powder-fine, swept there by a hand over a generation of housekeeping. No one visits often enough to leave this much dust. The dust is, Kestrel has said quietly, what happens to Slow-Stone when it sits in a warm mist for a long time. He does not say how he knows.

- **Hazards.** The wind at the lip. The mist condenses on skin as warm water. A lamp held over the lip brightens; a lamp held a pace back burns normal.
- **Creatures.** None resident.
- **Items / relics.** The iron cup is recent (Listener). Under the third bench, a **Listener chalk-mark**: Ylva's sign. A pale-stone tile, pried loose, sits on the middle bench — one tile of the Tower Six floor-pattern, carried down by Ylva. *Slow-Stone*-dust along the bench-seam — blue, almost powder-fine, swept into the join where the bench meets the floor.
- **Clues / fragments.** Ylva's chalk reads (Listener shorthand): *Tier one safe. Tier two with mask. Tier three: I am not ready.* The third line is lower than the first two, as if written kneeling. Ylva has been absent for three years; this chalk is the most recent confirmed sign.
- **Cost of descending to Tier 1.** **Breath.** The traveller's unaided breath is shortened by one heartbeat. The loss is not felt at this tier; it is felt at the next. The Guild has documented this for three generations. Sula calls it *the toll in advance.*

  *Cost in the flesh.* A Listener who pays this cost three times — three Tier-1 descents in a life — becomes easy to spot, if you know what to look for. Sula's senior at Mistmere is one. He speaks in short sentences because a long sentence runs him short of breath before its end. He eats slower than he used to. He climbs the cathedral stair one step at a time, pausing on the landing where the saint's finger is being repainted. He does not complain.

  His name is Branic. He has been a Listener for forty years. In his small room at the Mistmere edge-station, above his cot, he has pinned a page from a child's primer — a breathing exercise, the kind a midwife teaches a newborn's mother. He reads it before sleep. He does the exercise. The exercise no longer works the way it worked before the third descent, but he does it anyway, because the work that does not work still knows that he is working. He has said, to Sula, in what he may have meant as humour: *the Chasm took a little of my breath. I keep the rest closer for having lost it.* Sula did not laugh. Sula nodded. She has the breath of a woman who has not yet gone down.

- **Exits.** Up (peg-ladder). Down (a second shaft, rimmed in darker alloy, dropping sixty paces) to Tier 2.

*Pre-encounter traces at Tier 1.* There are no creatures at Tier 1, and still the chamber is not empty. The cup on the bench is a trace. The chalk on the wall is a trace. The pale-stone tile carried down by Ylva is a trace. Three generations of Listeners have left marks in this room without meaning to. A careful observer finds: a dent in the middle bench where heavy packs have been set down; a polish on the pale-alloy handrail at the exact span a short woman grips when she leans to look over; a faint scuff-line along the floor at the lip, where boots have halted.

The handrail's polish is worn brightest at Kestrel's grip-span and at Sula's grip-span. The two spans overlap at the end of the rail. In that overlap, the metal is brightest. Both have leaned at the same spot, many times, never together. Neither has seen the other's polish. Both have left it.

*Ambient.* The walk between the rim and the Tier-1 shaft-head is forty paces. A Listener counts them. The count is steady; forty is forty every time. But a Listener on her first descent counts thirty-eight, or forty-three, or forty; and a Listener on her twentieth counts forty. The count settles, as the body learns the distance. Ylva wrote in her cell-book, before she vanished: *I have stopped counting. The walk is the walk.*

*Ambient.* A Listener — Obra, who died four winters ago — used to sit on the middle bench for an hour before each descent. She said the bench remembered her. The Guild thought she was soft-headed. After her death, the bench was warm the next time a Listener sat on it, though the chamber is always cool.

*Ambient.* At the back corner of the chamber, where the pale-stone meets the natural cliff, a tiny runnel of condensation — not enough to drip, just enough to wet the join — has laid a green stain a finger wide down the wall. The stain smells of nothing. A Listener who tastes it (and one has, for the record) reports a clean mineral water, not metallic, not sweet. The stain does not grow and does not fade.

*Ambient.* Ylva's chalk marks on the back wall have been dusted over, twice, by Kestrel on his cache visits. He dusts them with the side of his hand, not to hide them, but the way a man brushes his own writing to see if it still reads. The marks read. He has never written beside them. He has only read and gone down.

### Tier 2 — The Bone-Rooms Rim / *the second pit* (Listeners) / *the drinking-ledge* (Crossers) / Bone-rooms tier
- **Descent-work.** Sixty paces of rope-and-peg, with two rest-ledges. The shaft is warmer than Tier 1's shaft by a measurable step. A palm pressed to the shaft-wall at the first rest-ledge is warm; at the second rest-ledge, warmer; at the bottom, the wall is wet-warm, like a breath held against stone.

  The mist here drifts sideways at intervals, as though a door below is opening and closing. The drift is not regular. A climber braced on a peg may feel the mist lean across their face, then lean back, then again, in no rhythm that can be counted against.

- **Crossing the threshold.** Stepping off the rope onto the Tier-2 ledge, the traveller feels nothing at first. Then, a count of ten later, the inside of the mouth feels dry in a way water does not fix. The throat does not hurt. It is not a thirst. It is a sense that something, in the cavity of the mouth, is gone — a softness, a shape that the tongue used to find. A name would be on the tongue. It is not quite ready yet. It will be, on surfacing.

  A Listener's old rule, written in a cell at D003: *go below with a name in mind, so you know which one was taken.*

  Kestrel's method is to write the name down before descent and then fold the paper and seal it with wax. On surfacing, he opens the paper. The name on the paper is, he says, always familiar. The familiarity is the point. He knows a name has gone; the paper tells him which. He has twelve such papers in a drawer at T004. The first four are creased soft by re-reading; the last eight are crisp. He does not re-read the recent ones. A Crosser named Enna has asked him why. He has said: *because I do not yet know whom I lost, and the paper would tell me, and I would have to go to the funeral.*

  The mouth-dryness is specific. It is not the dryness of thirst and it is not the dryness of fever. Water wets the tongue and the tongue is wetted and the dryness is still there, underneath, a smaller dryness in a smaller mouth inside the mouth. A Listener who has paid this cost once describes it as *a cupboard has been emptied in a house you live in and did not know about.*

- **Description.** A wider ledge, long enough for four to stand abreast. The ledge's stone is darker than Tier 1's; it is wet at the rim and dry at the inner wall. A single Listener lamp-hook has been driven into the wall at head-height; its hook has been re-hammered twice.

  The inner wall opens into a small room — **the bone-room proper** — pale-walled, dry, roofed flat. The room is empty of bones. The name is a tier-name, not a description.

  On the back wall of the room: a single carved line in old-tongue, *bren-ehn-dun* — body-silence-ending — read by Eilin from a Kestrel rubbing as a **funeral inscription**. The cut is crisp. A finger traced along it finds the bottom of the cut smooth as glass.

  Below the inscription, fine scratches in a later hand: a tally, forty-seven marks, each a Listener who has surfaced from this tier. The tally stops three years ago. The last mark is tentative; the maker's knife hesitated on the down-stroke, and the mark has a small hook at the bottom.

  The room is slightly warmer than the ledge. A candle set on the floor at the inscription burns straight. A candle set on the ledge gutters.

  The bone-room's floor, where it meets the back wall, has a seam the width of a hair running the full length. Water does not come up through it. Air does not come up through it. A thread laid across it does not lift. But a Bone-Lamp held close to the seam shows the stone on one side of the hair is a shade paler than the stone on the other. The pale side is toward the Chasm. The slightly-less-pale side is toward the rock. The seam is where the pale-stone chamber meets the mountain. The chamber was set into the cliff, not cut from it.

  Along the inner wall, at knee-height, a row of small marks — not a tally, not script, just spaced indentations, each the size of a thumb-tip, cut into the pale-stone in a line that runs the width of the room. Thirty-seven of them. Eilin has measured the spacing: consistent to within a hair. She has no gloss. Kestrel has theorised fingerprint-register — that each mark fit a finger, and was made with the finger, and held something in place the finger was pressing. Sula will not let him press his finger into one to test.

  The floor under the inscription has been worn smooth by kneeling. Three distinct kneeling-wears: one to the left, one directly below the cut, one to the right. The wears are Listener-patterns — left-kneel is the reading-kneel, right-kneel is the rubbing-kneel, centre-kneel is the copying-kneel. Eilin taught the pattern. The Listeners use it. The wears predate Eilin by decades.

  A small pool of condensate collects at the north-west corner of the room. The pool is the span of two hands. It does not evaporate and it does not freeze; it is always warm. Its surface holds a lamp-reflection so still that a Listener, watching the reflection, can count her own heartbeat in the faint tremor the floor takes from her pulse.

- **Hazards.** Unaided breath shortens further. The Tier-1 heartbeat-shortening, unfelt there, is felt here: each breath is a half-measure. A climb back up on unaided breath is possible but punishing; most Listeners cry the last three peg-lengths. The mist's warm condensation begins to carry a metallic taste (Slow-Stone-family). The **Held Breath (C-0015)** should be worn here for any stay over an hour.
- **Creatures.** None. A single **Cave-Salamander** lives in the ledge's seep-runnel. Its skin is pale. It does not move when a hand passes over it.
- **Items / relics.** Kestrel's cache, locked in a pale-alloy box set in the room's floor: a coil of **Soft-Rope**, a **Bone-Lamp**, a wrapped **Deep-Kindle (C-0003)** copy (the one "held with knowing irregularity in Kestrel's possession"). A single **Distant-Voice Stone (Tier-E)** rumoured to be hidden here by a Faith-turned-Crosser two generations ago — Guild does not confirm; Kestrel does not deny. The box's hinges are pale-alloy. They do not squeak.
- **Clues / fragments.** The tally's last mark is in Ylva's hand. The *bren-ehn-dun* wall and the Zone-6-of-D004 tile-writing are linked: the same hand, possibly the same inscription-campaign.
- **Cost of descending to Tier 2.** **Name.** The traveller forgets, on surfacing, one proper name they cared about — not a friend's name, but a smaller name: a childhood pet, a street, a dead aunt. The forgetting is partial; the name is at the tip of the tongue for months. A PC who descends to Tier 2 three times cumulative loses a major personal-name (friend, lover). Sula's contract expressly limits her cells to two Tier-2 descents per year.

  *Cost in the flesh.* Kestrel has descended to Tier 2 twice. Somewhere in his memory there is a boy whose name he used to know. He knows there was a boy. He knows where the boy stood, in a lane behind his mother's house, and what the boy's hair looked like in rain. He does not know the boy's name. When he tries, the sound *T—* rises and stops. He has trained himself not to try in company, because the stop is visible on his face.

  The boy was Kestrel's cousin by his mother's sister. They played at a well in the lane. The well is still there. Kestrel has been back to the lane once, as a grown man, and stood at the well, and waited for the name. It did not come. He stood for an hour. The lane's current children watched him from a doorway and did not approach. He left the lane with a stone from the well-lip in his pocket. He keeps the stone in a drawer at T004 beside the twelve sealed papers. He has not opened the drawer in a year. He knows, because he told Parn once, that the stone in the drawer will not bring the name back. He keeps the stone anyway. It is what he has of the boy that the Chasm did not take.

  Orvin, the cobbler of Tier 3 cost, has descended to Tier 2 as well. He has lost a smaller name: a cat, he thinks, or a neighbour. He is not sure. The Tier-3 loss has taken more from him than the Tier-2 loss did, and he can no longer properly hold the Tier-2 loss's outline. He has one cost on top of another, and the lower cost is eroding the upper one. The Guild has a word for this, too: *compounding.* The word is rarely used aloud.

- **Exits.** Up. Down (a knotted rope hangs into a shaft wide enough for one person at a time; the shaft goes a hundred paces) to Tier 3.

*Pre-encounter traces at Tier 2.* No resident creatures means no body-heat, no droppings, no tracks. And yet the room is lived in. The bone-room smells, faintly, of a thing that is not Listener's tallow and not Listener's oil. A herb, Kestrel says — and Kestrel knows — but the herb is not named in any Guild cabinet's catalogue, nor in any Faith herbal, nor in any Fog-walker physic. The scent is strongest near the wall where the cache is set. It is thinner at the doorway. A Listener who has sat in the bone-room long enough to grow accustomed to the smell, on surfacing, finds for a day that the Reach's own smells — the lake, the tea, the pine-wood — seem paler than they were. Something from the room has rinsed her nose.

The Tier-2 ledge-wall, where a Listener stands a pace from the chamber-threshold, carries a faint pale residue from palm-contact. A generation of Listeners has leaned on that wall with one palm while unslinging a pack with the other. The palms have left a long, low oval that catches lamp-light at a different angle than the surrounding stone. The oval is at the height of Kestrel's palm. It is also at the height of Ylva's palm. It is also, at the lower edge, at the height of the palm of a woman smaller than either. That woman is not in any Listener roll.

*Ambient.* At Tier 2, when a Listener speaks softly to herself — a habit, for company — the room takes the sound and gives it back, a count later, in a register half a step lower than her own voice. The effect is not an echo. It is a replacement. A Listener who is not used to it stops speaking to herself after the first descent. The Listeners who stay speaking-to-themselves are noted in Sula's private margins. The note is three words: *ready for more.*

*Ambient.* A Listener at Tier 2, eleven years ago, reported that when she stood in the bone-room and kept silent, she heard a single breath taken in the corner behind her. She did not turn. She wrote it down. She did not descend again.

*Ambient.* Kestrel's cache, opened, carries a faint scent of a herb none of the Guild recognise. The scent is on Kestrel's hands for a day after he visits.

*Ambient.* The ledge's seep-runnel, where the cave-salamander lives, runs a thin film of water from a crack high in the chamber-wall. The water, traced upward by lantern, disappears into a hair-thin seam that is not large enough to pass a needle. The water is warm at the salamander and cool at the seam's mouth. Somewhere in the stone between, the water is heated. The Guild has a word for this. The word is *unresolved.*

*Ambient.* On the ledge's outer rim, chalked in a hand that is neither Ylva's nor Kestrel's, three small marks arranged as a triangle point-down — Listener sign for *I did not come back the same.* The chalk is old enough to have taken the mist's damp and set in place, a chalk-ghost rather than a chalk-mark. Whoever made it was making a record of herself for the next Listener's eye. No one has signed.

### Tier 3 — The Wet-Silence / *the sound-dead level* (Listeners) / *the saint's throat* (Faith, unused) / Wet-tier — NOT playable in v0.1
- **Descent-work.** A hundred paces of rope, unbroken, one person at a time. The rope is **Soft-Rope**, already in place, left by Ylva three years ago. It twitches sometimes when no one is on it. The twitches are small and slow; a Listener at the Tier-2 shaft-rim, watching, has counted as many as nine in an hour and as few as none for a week.

- **Crossing the threshold (described).** The last Listener to cross this threshold and return to speak of it was Ylva, and her rope-signals are all that remains of her reporting. She described the threshold in three signals, which Sula's clerk transcribed as follows: *the air tastes*, *I have nothing to say*, *I am hearing*.

  The first signal — *the air tastes* — is interpreted: at the Tier-3 shaft-foot, the air is thick enough to carry its own flavour, metallic, sweet-sour, like old coin laid on the tongue.

  The second — *I have nothing to say* — is interpreted as the voice-cost beginning. A Listener who has just crossed feels the sentence on their tongue dissolve mid-speaking; the words form, but the intent for them to be heard goes missing.

  The third — *I am hearing* — is the corridor beginning to speak. Ylva's signal-knots for this phrase are the only Listener signals in the entire slate where she has double-tied the knot, as if to be sure.

  The physiology of the crossing, as Ylva knotted it and Sula's clerk extended by inference: at the Tier-3 floor, the ear itself becomes a receiver for things the mouth cannot report. A Listener may hear a sentence that was never spoken in her presence and know, as she hears it, that the sentence is not a memory and not a hallucination but a reception. The sentence arrives with the weight a heard sentence has. Its source, if sourced at all, is the corridor. No Listener who has returned has reported what the sentence was. The sentence does not survive surfacing. Orvin has said only: *I heard something. I do not know what I heard. I know I was told.*

  The voice-cost is felt, on return, as a small gap between intention and sound. A Listener wishes to speak; the wish arrives at the throat; the throat shapes the words; and somewhere between throat and listener's ear, a small piece of the sound goes missing. The words are correct. The words are audible. But the sound that should carry the words does not fully carry them, in a crowd, and the voice is the first voice to be lost under others.

- **Described appearance.** From Tier 2, a Listener at the shaft-rim can lower a **Bone-Lamp** on a cord and see, at the shaft's foot, a floor of pale-stone flagged in a ring-of-dots pattern. The pattern is the **colonist crest mark** — the same mark under D004 Tower Seven's brazier, the same under D006's vault-block.

  Beyond the ring, a corridor recedes, lit at intervals by something not a lantern — soft, steady, white. The light does not gutter. It does not move. A Listener at the Tier-2 rim, dropping the lamp, sees her own lamp's yellow against the corridor's white and the contrast is the contrast of moon against a distant candle.

  Faint sound comes up the shaft. The sound is not wind. It is a murmur of many voices, none of them distinguishable, none of them in any language the Listener recognises, and — strangely — none of them loud. This is how the **Speaking House (Tier-F)** is rumoured.

- **Hazards (described).** The air is wet. Unaided breath is halved. A **Held Breath** mask lasts half a day; at Tier 3, most of that half-day is spent at the shaft-foot before the return climb is possible. **Slow-Stone**-oil lanterns burn blue steadily; ordinary oil lanterns die within a hundred breaths. Human speech, above a whisper, does not propagate in the corridor beyond — the floor absorbs it. A Listener who whispers is heard by the Listener beside her. A Listener who speaks aloud is heard by no one. Ylva's second knot was on this.
- **Creatures (described, not confirmed).** A **Wet Speaker (C-0008)**-family voice is heard at intervals. A figure — **Road-Walker (M006)**-like — has been seen at the end of the corridor, walking away, not turning. Ylva's third set of signals, which Sula has not made public, describe the figure: *tall. a hand raised. walking in the light.*
- **Items / relics (rumoured).** **The Speaking House** (Tier-F) sits at the end of the corridor. **The Counting Child** (Tier-F) is heard here — the voice is in this corridor, if anywhere. A single **Distant-Voice Stone** might be surfaced from the shaft-foot; Sula has forbidden the attempt.
- **Clues / fragments.** Ylva left a rope-signal slate at the Tier-2 shaft-rim. The slate is knotted with three signals per descent. Her last signals read: *lamps wet*, *voices at distance*, *I can go no further without a second*. No second has come.
- **Cost of descending to Tier 3.** **Sound.** The surfacer loses, permanently, the ability to pick their own voice out of a crowd. A PC who descends can speak alone; in company of three or more, their voice is not distinguishable to the others, even when they are the only one speaking. This cost is the same cost **The Whistler (B-0012)** levies transiently — here it is permanent.

  *Cost in the flesh.* The Faith-turned-Crosser who hid the Distant-Voice Stone — a man named Orvin — is the only living bearer of this cost that the Guild will confirm. Orvin lives in Mistmere and works as a cobbler. In his shop, alone, he can be heard. In the market, among his neighbours, his voice goes under the other voices like a stone under a stream. He has learned to write. His neighbours have learned to watch his face.

  Orvin's shop is on a narrow lane behind the cathedral. The sign above his door is a shoe, painted black, paint flaking. He keeps a slate hanging by a nail inside the door for the customers who need to be told something the voice cannot carry. The slate reads, on most days: *take a seat. I will come.* He wipes it in the evening and writes it again in the morning. The hand is patient and small. His apprentice Imre — his daughter — has been taught to speak for him in the market when the crowd is thick. She is nine. She does it well. A neighbour has said, watching them: *he lost the voice, but the daughter is the voice now.* Orvin heard the neighbour say this. He nodded. It was the one time his nod was loud.

  Orvin's shop-cat, a grey tom of no name, sits on a stool by the window and stares at Orvin's mouth when he speaks alone. The cat does not stare at other people's mouths. Whatever is in Orvin's voice, the cat can still hear it, or the cat has learned that the mouth is where the voice should come from. The cat is old. It does not climb the stool as easily as it once did.

- **Exits (described).** Up, by the same rope. Down — there is no shaft down from the corridor's visible reach. The corridor itself, not descended, is the end of playable depth even in v0.2.

*Pre-encounter traces at Tier 3.* The tier is not playable and cannot be entered in v0.1; what reaches the party is traces of traces. A Listener at the Tier-2 shaft-rim, looking down with a Bone-Lamp, sees at the shaft-foot the pale-stone floor, the ring-of-dots crest, the corridor's white light at distance. The light does not flicker. The stone does not wear. The Listener cannot report a living thing she has seen there, because she has not seen one; she has only seen that the stone is clean. Ylva's own report, transcribed from rope-signals, lists no body, no motion, no resident shape. She saw the corridor, and the corridor saw her, and she climbed back up.

The figure at the corridor's end — Ylva's *tall. a hand raised. walking in the light.* — appears in her record without prelude or follow. She did not signal it a second time. She signalled it once and then signalled her return. Sula's clerk has read the signal slate five hundred times. There is no ambiguity in the knots. There is only the one sighting.

*Ambient.* The rope at Tier 3 is, according to three separate Listener observations, slightly more worn at its middle third than at its ends. Something has gripped it, midway, many times. Nothing has been seen on the rope.

*Ambient.* A Listener who lowers a Bone-Lamp to the shaft-foot and leaves it there for a full count of a thousand finds, when she raises it, a single grain of pale dust on the lamp's hood. The dust is not stone-dust. Kestrel has tested three such grains. He will not say what they are.

*Ambient.* Orvin the cobbler, in Mistmere, has a daughter of nine. She is the one person in the market who hears his voice without training her ear to it. Her name is Imre. Orvin has said, once, to a Listener who asked: *she was in me before I went down. I did not leave her behind. Whatever they took from my voice, they took from the part that was not yet her.* The Listener wrote this down and gave it to Sula. Sula read it and put it in a drawer she does not open.

*Ambient.* A Listener at the Tier-2 rim, listening for the rope's twitch, hears — sometimes, not always — a small regular sound from below, the sound of stone being set down on stone with care. The sound is not the rope. The sound is not the wind. It is, by the Listener's own account, the sound a mason makes when he sets a block.

### Tier 4 — The Lantern-Dies / *the killed-light* (Listeners) / Lantern-Dies tier — NOT playable in v0.1
- **Descent-work (described).** Below the Tier 3 corridor, rumour places a further shaft reached only by crossing the corridor to its end. No Listener has crossed it. Hallen claims he did. His claim is not corroborated.

- **Crossing the threshold (from Hallen's account).** Hallen, transcribed by Sula's clerk thirty years ago: *the light stopped wanting to be light. my lantern went out. I went on. I saw.*

  The transcription is incomplete. Hallen was raving. The clerk caught three more phrases before the raving became unreadable: *my candle was my hand*, *my hand was not warm*, *I could see by not-seeing*.

  Sula's clerk at the time, an old man named Jerem, wrote at the bottom of the transcript, in his own hand and not the official one: *he is not raving. he is describing. he does not have the words.* Jerem was dismissed from clerk duty the week after. He did not protest. He took a post at a hedge-village and tended sheep for the last years of his life. He did not speak of Hallen again. His post-duty book, found after his death, contains a single line on the first page: *the raving man saw a room. I believed him.*

  Whatever Hallen did on that tier, he did it unsighted and walked. He did not crawl. The clerk's transcript is clear: Hallen's knees, on return, were clean. A crawler's knees would not be. Hallen had walked in the dark by a light that was not his light. The Faith reading of this is the saint-through-the-veil reading. The Crown reading is in the folio and is not available. The Listener reading, written in Ylva's hand in a margin on the rope-signal slate Sula keeps: *he walked because the light did not need him to see.*

- **Described appearance.** Hallen's account, transcribed by Sula's clerk thirty years ago: *a chamber with a long window, a road beyond the window, a sun nailed to a tower. The lanterns did not burn. I saw by another light.* The Crown's sealed folio, which the party cannot read, contains a single line: *If the Window is real, it is not to be broken.*

  Hallen's cell drawings (D003 Cell 7) show the Long Window consistently: a tall rectangle set in a stone wall, a road beyond, a tower with a sun nailed to it. If the Crown's folio is to be trusted — and Darrik believes it is — then the Window is a thing, not a figure.

- **Hazards (described).** All open-flame lanterns extinguish. Sight requires relic-light: the **Bone-Lamp** brightens only for a count of forty, then dims. The **Small Sun (D-0011)**, if carried here, reportedly warms tears. Hallen's own tears, when he raves of this tier, are reported by the Septons to be warmer than his face.
- **Creatures (described).** None. Hallen described no living thing at this tier. The absence is itself a cost. The Faith's reading: *at the killed-light, the saints have already passed through and are not turning back.*
- **Items / relics (rumoured).** **The Long Window (Tier-F)**. **The Lantern-Killer (D-0001)** is the catalogue-name for the tier because the surfacer-site matches this depth.
- **Clues / fragments.** None a PC may gather in v0.1.
- **Cost of descending to Tier 4.** **Light.** The surfacer, for the rest of their life, sees small lights at distance as dimmer than they are. Stars fade. Candles across a room are less bright. The cost is the **Lantern-Killer**'s cost, banked on the surfacer.

  *Cost in the flesh.* Hallen, in D003 Cell 7, sits in the grey light of his grilled window and draws. The light in that cell, to anyone else, is adequate for charcoal work. To Hallen, it is a dusk that has not yet committed to becoming night. He draws anyway. He does not complain of the light. He did, once, years ago: the Septons noted it and then stopped noting it, because the complaint was always the same. *The light is not where it used to be.*

  At dusk on clear days, Hallen sets his charcoal down and looks out through the grill. He can see, through the grill, a slice of the street and, when the lamplighter passes, the lamp being lit. The lamp is three paces from the grill. To Hallen, the lit lamp is faint. He waits for the lamplighter to pass a second time, coming back down the street, and for the lamp to be lit in his seeing — because, he has told the septa who sits with him, the lamp in being lit is more a lamp than the lamp lit. The lighting-of is when he can still see. The lit-lamp after is thin. The septa has written this down. She has not known what to do with what she wrote. It sits in her book.

  On the feast of Saint Hellon, when the cathedral across the city lights a hundred candles on its altar and the light spills out the window into the square, Hallen — whose cell is nowhere near the cathedral — reports that the candles are dim. The septa keeps the day's record. She does not know if he is reporting what he sees or what he remembers. Hallen no longer knows either.

- **Exits (described).** Up. Further down — not described by any returner. Hallen did not describe a down.

*Pre-encounter traces at Tier 4.* Hallen's wall drawings in D003 Cell 7 are the only surviving record. The rectangular Window; the road beyond; the tower with the sun nailed to it. He draws it and re-draws it, and the re-drawing is consistent. The Window is in the same wall every time. The road goes to the same tower every time. The sun is always nailed. The nails are, in his drawings, four. He does not draw the figure that, in the Crown's folio, the Window contains. He may not have seen the figure. He may have seen the figure and have been unable to draw it. Sula, who has read his drawings in charcoal and watched him draw on fresh paper, has offered both readings without choosing between them.

The raving phrase *I could see by not-seeing* is the phrase a Listener will not repeat aloud. It is underlined in every Listener cell's reading-book in a hand no Listener will own. The underline appears during the first night a new Listener reads the phrase, and she finds it underlined when she opens the book the next morning, and her cell-mate denies having marked it. The underline is always fresh. Sula has stopped replacing the books.

*Ambient.* A Listener at Tier 2, once, lowered a Bone-Lamp on three ropes tied together, to the full hundred paces of Tier 3's rope and then fifty paces further. The lamp dimmed at the fifty-paces mark and then, according to the Listener, did not dim further — it simply was less a lamp. The Listener raised it. It brightened again as it rose, but for an hour after surfacing she could not read her own Guild-mark on the lamp's hood.

*Ambient.* Hallen in his cell at D003, when given a candle at dusk, will hold his palm before the flame and watch the back of his hand. He is not testing whether the candle burns. He is testing whether his hand shows the light. Sometimes, he says, it does not; the candle burns, the flame is yellow, his hand is a flat grey shape in front of it, and the light does not pass. He does not panic when this happens. He puts the candle down and waits. By the count of a hundred his hand is a hand again. The Septons have noted: he does not shake during these counts. Whatever Hallen is waiting for has come often enough that he has learned to wait for it.

*Ambient.* The Crown's sealed folio on the Long Window is kept in a cabinet at Ashcrown that only one living clerk can open. The clerk is Darrik's second cousin. He has read the folio once. He has not slept through the night since.

### Tier 5 — The Floor That Is a Wall / *the far face* (Hallen's own words) / Beyond-tier — NOT playable, not surveyed
- **Descent-work.** Not attempted.

- **Crossing the threshold (hypothesis, Crosser).** If Hallen's phrase is read as Kestrel reads it — *below and beyond are one; the floor is the far wall* — then the crossing at Tier 5 is a rotation, not a descent. The traveller does not fall further; the direction of "down" rotates, and the far wall of the Chasm becomes the floor the traveller stands on.

  This is Crosser theory. It is not a Faith teaching. It is not a Listener report. It is Kestrel's reading of a madman's sentence, and Kestrel has made his workshop in D008 on the basis of this reading.

  The threshold, in the hypothesis, is not a threshold of descent but of orientation. The traveller's weight, at the rotation, is no longer on the soles of the feet pressing the pale-stone floor of the corridor; it is on a new floor, which was the far wall. The far wall is made of the same stone the corridor was made of; the stone does not change. The weight changes. The sky becomes a direction the traveller leaves behind.

  Kestrel's workshop codex, in the margin beside this hypothesis, carries a single question in his smallest hand: *does the returner return upward, or does he return through the far wall, to the far side?* He has not written an answer. He has made a small smudge beside the question, as if he had started to and stopped.

- **Described appearance.** Hallen's line: *Below and beyond are one. The floor is the far wall.* The Crosser sketch "from below, we may rise" is the Tier-5 hypothesis rendered in Kestrel's hand: if Hallen is correct, the far side of the Chasm is reached not by crossing but by descending.
- **Hazards.** All costs of the above, cumulative. The descent is terminal for every named attempt in Faith memory.
- **Creatures.** Unknown.
- **Items / relics.** Unknown.
- **Clues / fragments.** The Crosser sketch (T004 library deep archive). Hallen's raving at D003 cell 7.
- **Cost of descending to Tier 5.** **Self.** The surfacer, if they surface, returns as someone the people who knew them no longer recognise. This is the catalogued cost. No one has paid it and returned.

  *Cost in the flesh (hypothesis).* The Faith teaches that the saint at the bottom is not the saint who descended. A saint's-road pilgrim who reaches the bottom becomes a figure the pilgrim's mother, meeting them on the road home, would not greet. This teaching is older than the Faith's current doctrine. Malen has read it. Malen does not speak of it.

- **Exits.** None observed.

*Ambient.* No ambient. Tier 5 has no witness.

*Ambient.* A Faith teaching from before the current doctrine, which Malen can recite and will not: *the saint at the bottom is not the saint who went down. The saint who went down is nowhere now. The saint at the bottom is a stranger wearing the saint's face.* Malen has dreamed this teaching three nights running in the last month. She has not told anyone. She has begun, without noticing, to stand longer at the drum in Zone 4 of D003.

*Ambient.* Kestrel's workshop codex, in his own hand, carries the Tier-5 hypothesis in two forms: *Hallen's reading,* and, beside it, *my reading.* His reading is the same as Hallen's. He has underlined his own, not Hallen's. The pen-pressure on the underline is hard enough to have gone through the page.

## Storyline links
- **Line B — World Before the Fog.** Eilin's inscription work benefits directly from Tier 2's *bren-ehn-dun* wall and Tier 3's shaft-foot pattern (described only).
- **Line E — Depth-Walkers (central).** The Chasm is the Listener and Crosser common ground. Sula's descent-limit is Tier 2. Kestrel's hidden cache is at Tier 2. The Tier-4 sketch is the Crosser thesis.
- **Line D — Iron Dragon Returns.** The Chasm is the hero's ground. Veyl will stand at the rim; the *sun nailed to a tower* phrase echoes Hallen's raving. A straight-line cloud seen from the rim is a major D beat.
- **Line A — Guild's Buried Charter.** The Guild's rope-inventory, Soft-Rope leasing, and Ylva's tally-mark descent-log are Guild records the Charter arbitrates.
- **Line C — Four-Crown Intrigue.** The sealed Crown folio's *If the Window is real, it is not to be broken* is a royal Tier-4 directive. Darrik knows about the Window. Malen does not.
- **Named NPCs.** Archdepth Sula (rim, once). Navigator Kestrel (Tier 2 cache). Ylva (Tier 2 tally, absent). Hallen (Tier 4 claim, absent — he is in D003). Listener Vela (Tower Seven watches the approach trail from the south).
- **Quest hooks.** (1) Retrieve Ylva's rope-signal slate from Tier 2 for Sula. (2) Retrieve an item from Kestrel's cache. (3) Drop a signal-stone at Tier 1 for Malen (she does not know this is what she asked for). (4) Document the Tier 2 wall inscription for Eilin. (5) **Do not** descend below Tier 2.

## Writer notes
<!-- writer-only -->
Tiers 3–5 are the Abyss-core: named, costed, instrumented, but off-limits in v0.1. Their existence should be felt at Tier 2 (the rope that twitches, the mist that drifts sideways, the voice at distance). The cost-ladder is structured to bank irreversible narrative losses on the PC; in v0.1, a PC can absorb Tier 1's breath-toll and one Tier-2 name-loss without mechanical cripple, but repeated Tier-2 descents punish. Tier 3+ costs are for v0.2+ reveals. The far side — the dead modern civilization — is at Tier 5. Hallen is right. He will not be believed. Keep him right.

The "Cost in the flesh" paragraphs are prose-only tethers: each tier's cost has a living bearer in the world the PCs can meet. Sula's senior at Mistmere (Tier 1 breath). Kestrel (Tier 2 name, the T— boy). Orvin the cobbler (Tier 3 sound). Hallen (Tier 4 light). No Tier 5 bearer lives. This gives the DM an NPC per tier who is the cost made visible.

The "Crossing the threshold" paragraphs at each tier are designed to be read aloud. Short sentences. Sensory-concrete. Do not let any DM soften them. The Abyss does not soften.
<!-- /writer-only -->

## Descent-cost ladder (summary)
| Tier | Name | Cost | Playable |
|------|------|------|----------|
| Rim | *the standing-place* | none | yes |
| 1 | Shallow Descent | breath (heartbeat shortened) | yes |
| 2 | Bone-Rooms Rim | name (one small proper name lost per descent; cumulative) | yes |
| 3 | Wet-Silence | sound (voice no longer audible in crowd; permanent) | no — described |
| 4 | Lantern-Dies | light (distance-dim; permanent) | no — described |
| 5 | Floor-is-the-Far-Wall | self (unrecognisable on return) | no — not surveyed |

## Map sketch
```
[D004 Tower Seven]
      |
   (R010 — trackless)
      |
[The Rim / cairn-line]
      |
  ===shaft===  ← pegs, pale-alloy
      |
[Tier 1: Shallow ledge-chapel, Ylva chalk]
      |
  ===shaft===
      |
[Tier 2: Bone-room, bren-ehn-dun wall, Kestrel cache]
      |
  ---rope---  ← twitching, Ylva's
      |
[Tier 3: wet-silence corridor, colonist ring-crest floor]  ← described
      |
  (no visible shaft; cross to end)
      |
[Tier 4: lanterns die, Long Window]  ← described
      |
  (no described shaft)
      |
[Tier 5: the floor is the far wall]  ← not surveyed
```
