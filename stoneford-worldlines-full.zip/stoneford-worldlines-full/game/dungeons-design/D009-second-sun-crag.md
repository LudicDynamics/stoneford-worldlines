# D009 — The Second Sun Crag

## Snapshot
A ruined landing-beacon outpost atop an isolated crag two days east of Wolfsjaw Pass, where a single Listener at the wet-silence level saw, through a crack in a wall, a round bright thing lighting a chamber beyond. The chamber has never been reached. Players enter for the Faith's quiet curiosity, for the Crossers' surveying, or because the crag casts a glow at midwinter that has been mistaken for a second dusk.

## Location
- Nearest town: T003 Wolfsjaw Pass
- Region: The Grey Reach, eastern spur between T003 and T004
- Terrain approach: Two days east from Wolfsjaw through pine and scree. The crag is a dark stone finger standing alone, a hundred paces proud of the forest. A stair cut into its west face leads to a weathered door. The door opens with a push.

## Historical layers
- **Pre-collapse.** A First-Wave landing-beacon station — a single tall hall built into the crag's summit, with a deep shaft below for power and for a central luminary. When the waves came down, this station was one of three known beacons. The other two are under Mistmere (buried) and at a site not yet located. The Second Sun is the station's central luminary — still, rumour insists, lit.
- **Faith-era.** The Faith consecrated the crag as *the hermit's lamp* six centuries ago. A saint lived in the upper hall for three winters. She left writing on the wall. The writing is the Faith's claim; the Listeners read it differently.
- **Guild-era.** A Listener named Halvon surfaced here twenty years ago, worked the wet-silence, saw through a crack the *round bright thing*, reported it, died within the year of wet-lung. No surfacing since.
- **Current.** The Faith does not maintain the crag. Animals den in the upper hall in winter. The Listeners do not visit. Kestrel has been twice and has not dug.

## Structure — surface ruin + sealed sub-level

### Zone 1 — The Stair / *the saint's ascent*
- **Description.** A stair of dressed stone, narrow, fifty steps, cut into the west face of the crag. The steps are uneven — the upper half has been worn by rain-runnel; the lower half is sharp still. A climber who looks down from the twentieth step can see the trail below as a thread.

  A hand-rail of iron, rusted, clinging to the cliff by spikes driven into cracks. Two spikes have given up and the rail hangs slack between the third and the fourth. A climber uses the rail by habit and by prayer, not by trust.

  A shrine-niche at the midpoint, the saint's image in it weather-worn beyond reading. The niche is barely two hands deep. The wind cannot reach inside it, but the rain has. The paint is long gone; the stone of the saint's face is smooth where cheeks and forehead would be, and shallow where eyes would be.

- **Hazards.** Loose steps. Wind at the top is constant — a steady west wind that lifts a cloak and does not set it back down.
- **Creatures.** **Hollow Ravens** roost in the niche. Two of them. They do not call. They watch.
- **Items / relics.** None.
- **Clues / fragments.** A coin in the shrine-niche — *Faith Cathedral-Copper*, recent. Someone has been here in the last season. The coin sits on a small cushion of raven-down; a raven has laid down over it and got up again.
- **Exits.** Up to the hall door.

*Ambient.* The stair's lower steps, cut sharp still, carry a pattern of fine chisel-marks the upper weathered steps have lost. A reader of masons' work — and there is one in Wolfsjaw, Archivist Naryn — would recognise the marks as colonial, not Faith. The lower courses were cut by the first hands that worked this crag. The Faith added the upper half with their own tools centuries later. The join between the two is at the shrine-niche.

*Ambient.* The ravens in the shrine-niche have dropped, over years, a small collection of objects at the saint's foot: a bone button, a copper clipping, three pale small stones, a fishhook. The ravens bring things. The niche collects them. A pilgrim who sees the collection sometimes takes an object; the ravens, within days, bring another.

### Zone 2 — The Upper Hall / *the saint's cell* (Faith) / *the beacon hall* (Listener records)
- **Description.** A long hall cut into the crag-top. Twelve paces by five. The ceiling is high and domed — higher than the crag's outer silhouette suggests; the dome is hollowed into the stone above.

  The walls are pale-stone on the lower course, local stone above. The join between the two courses is invisible to the eye but findable by the hand: the pale-stone is cooler, and the transition from cool to warm, running a palm up the wall, is a clean line.

  The floor is swept — by wind, or by hand. No one can say which. A visitor who leaves a footprint in the dust finds the footprint present the next day but faint; a second day and it is gone.

  In the centre of the floor, a circular inset of pale-stone, the span of a man, with a small round grating at its centre. The inset's stone is lighter in colour than the wall's pale-stone, not by much. The grating is pale-alloy, its bars finger-thick, its pattern a simple cross. Cold air drifts up through the grating. The draught is steady. A lamp held over the grating burns with a bent flame — the flame leans upward, against the draught, as a lamp's flame leans away from a draught; here it leans with it. This is not how lamps behave.

- **Hazards.** The grating is loose. A dropped lantern falls through; the fall is long enough that the lantern breaks at the shaft-bottom with a delay a count can measure.
- **Creatures.** A pair of **Hollow Raven**. An **M008 Mire-Hulk** cannot climb the stair; no large fauna here.
- **Items / relics.** On the north wall, a line of the old tongue painted in a faded saint's hand: *vel-kor-thal* — *unending-shining-dwelling* — the compound that occurs in the Iron-Dragon warning. The saint's paint is gone from *vel*; only the lower two roots read clearly. A close look at the painted-away *vel* shows a faint outline — the saint wrote it, then later scraped it. The scraping is crude. She changed her mind.
- **Clues / fragments.** The paint is old. The roots *kor-thal* match Zone γ of D008. Eilin's rubbing of the D008 wall, set beside a rubbing of this wall, is a B-line revelation.
- **Exits.** Down the shaft (Zone 3) — with rope, breath-mask, and Bone-Lamp. Back to stair.

*Ambient.* The grating's bent-flame effect is easiest to reproduce with a candle held at wrist-height over the grate. The flame leans up. A second candle held alongside leans up also, same angle, same degree. Two candles held a hand apart do not interfere with each other; each leans its own way. A Listener who maps this pattern across the grate finds the lean is strongest at the centre, weakest at the rim. The draught is not a single direction. It is a column.

*Ambient.* The saint's scraped *vel*: the scraping was done with a knife, in haste. Small cuts in the pale-stone beside the scrape show where the knife slipped. The scrape is deep enough that the original paint-colour is gone, but the pigment has sunk into a hairline crack below and left a pink shadow. The saint stopped before removing the shadow. She may not have known it was there.

### Zone 3 — The Beacon Shaft / *the saint's chimney* / Shallow-find grade
- **Description.** A vertical shaft, rimmed in pale-alloy, dropping thirty paces. The rim is smooth; a rope run over it does not fray.

  Pegs in the wall every three feet. The pegs are pale-alloy, the same as the Chasm's Tier 1 pegs in colour and in feel. A hand on the peg is warmer than the shaft-wall beside it.

  At the bottom, a round room the span of a small barn. Pale-stone walled. The wall is continuous — no seam, no brick-line, no chisel-mark. Empty — or very nearly empty. In the middle of the floor, a pedestal of pale-stone, and on the pedestal, a broken cradle of pale-alloy — the luminary's mount. The cradle is bent at one lobe, as if a weight had been pressed down sharply and then lifted. The luminary is not in the mount. The luminary is gone.

  The air is still. A lantern set on the pedestal burns brighter than it should; a lantern set at the wall burns weak.

- **Hazards.** Dust-cough air. The shaft is a one-way drop without rope.
- **Creatures.** None.
- **Items / relics.** The empty cradle. A single pale-alloy bolt on the floor, a finger long, square-headed — a fastener, not native to this world's smithing. A scrap of **Soft-Rope** left by Halvon, perished on the rope where it was tied, the perishing stopping three fingers short of the knot.
- **Clues / fragments.** The pedestal's base is inscribed: *kor-reh-ehn-ast* — shining-cliff-silent-one. "The first silent shining-cliff." A name, or a title, or a place; Eilin has not resolved. The letters are cut clean into the pedestal's base, and they read the same whether lit from above or below.
- **Exits.** Up. East through a low doorway into Zone 4.

*Ambient.* The pale-alloy bolt on the floor is square-headed and slightly warm. A finger on the bolt feels a warmth the shaft-wall does not share. The bolt has not been picked up by Halvon or by Kestrel; it has lain on the floor where it fell, for decades or longer, and the dust has not quite buried it. The floor nearby shows a small circle of bolt-missed dust, as if the bolt had rolled.

*Ambient.* The empty cradle on the pedestal carries a faint polish at its rim, as though the luminary had been turned many times in its mount before being removed. The turning would have been gradual — a long slow rotation, a quarter-turn per month, over years. Something was being adjusted. The adjustment stopped mid-turn; the last position sat three quarters of the way from its start. The pedestal's stone around the base shows the wear of the adjuster's feet.

### Zone 4 — The Wet-Silence Corridor / *the sound-muted way* / Wet-tier
- **Description.** A corridor, low and wet, leading east from Zone 3. The ceiling is a hand above a kneeling man's head. The walls are pale-stone. The floor is wet to the ankle — not standing water, but a film that does not drain.

  Sound does not propagate — a spoken word falls dead within a pace. The speaker feels the word in their mouth, shaped, released; the listener beside them does not receive it. A Listener new to this kind of corridor may speak once, hear no answer, and understand; the rule is silent and sharp.

  Lanterns must burn Slow-Stone-mixed oil. Ordinary oil lanterns die within thirty breaths — the wick steps down to a red coal and then to nothing. Slow-Stone-oil burns blue, steady, for the full watch.

  The corridor ends at a wall with a crack.

- **Hazards.** Unaided breath halves. Held Breath required. Bone-Lamp for sight. Wet-lung cost for extended exposure (Halvon's fate — a slow rot in the lung-wall that the Faith-physic named *the returnee's pneumonia*).
- **Creatures.** None.
- **Items / relics.** None to surface.
- **Clues / fragments.** None writable; sound-dead. A Listener with chalk in a Wet-Eye-hood can write on the wall, but the next Listener cannot read it — sound-dead carries over to sight, faintly, in these corridors; marks made here look fainter to later eyes than they were made.
- **Exits.** Back. **The Crack** (Zone 5).

*Ambient.* Halvon's rope, perishing three fingers short of the knot, perishes in a clean ring. The rope on one side of the ring is still good; the rope on the other is dust. The perishing is not a fray; it is a cut-off. A Listener who understands rope sees at once: this rope did not rot with time. It was aged by exposure to something the rope beyond the ring was not exposed to. The ring marks a boundary the rope crossed.

*Ambient.* The wet-silence corridor's film of water on the floor has, at one point, a small pale shape pressed into it — the shape of a palm, lying flat. The palm-print is not fresh. It has been there as long as Halvon's slate. Whose palm it was is not known. Halvon did not press his palm to the floor. Halvon's note does not mention it.

### Zone 5 — The Crack / *Halvon's view* / Tier-F witness point, not entry
- **Description.** A crack in the pale-stone wall, thumb-wide, handspan-long. The crack is at a kneeling man's eye-height. The stone around the crack is cool, but the stone of the crack's far lip — reachable by a finger through the crack — is faintly warm.

  Kneeling, lantern held to one side, a viewer sees through the crack into a chamber beyond. The chamber is well-lit — not by any lantern, not by fire. A round bright thing the height of a man hangs in the centre of the chamber, glowing softly yellow, surrounded by rubble. The glow is steady; it does not flicker. The glow has a colour the viewer's eye cannot rest on — not because it is painful, because it is unfamiliar.

  The walls of the far chamber are pale-stone, clean-cut. The floor is pale-stone, and dust lies on it in an even layer that has not been disturbed.

  A figure-shape is visible on the floor, not moving. A body, or what remains of a body. The clothing is not a robe. The clothing is something else. The figure lies on its back with one arm extended, as if pointing at the bright thing. The arm has not fallen to the side. It stays raised.

  The chamber cannot be entered from this side in v0.1; the wall does not give.

- **Hazards.** Extended viewing warms the viewer's face. The warmth is not the warmth of fire. It is a dry warmth, as from a stone that has stood in sun all day. Extended viewing (over an hour) produces the same dream as the **Ancient Stone Shard**: a straight line drawn across the sky.
- **Creatures.** None visible except the floor-figure. The floor-figure does not move.
- **Items / relics.** **The Second Sun / Tier-F / catalogue entry only.** Visible, not surfaceable.
- **Clues / fragments.** Halvon's last rope-signal slate, still tied to the crack's rim peg, reads: *I see it. I cannot reach it. It does not warm the room.* Eilin's gloss on "it does not warm the room" is: *the luminary is not a hearth.* The slate's knots are tight. Halvon tied them in wet-silence; his hands were wet; the knots are the knots of a man who did not want to leave an ambiguous record.
- **Cost.** None for witnessing. Prolonged viewing (a full day) gives the bearer the same shard-dream permanently.
- **Exits.** Back the way come.

*Ambient.* The viewer's eye, pressed to the crack, adjusts slowly to the chamber's light. The first count is a glare; the second count is the bright thing's outline; the third count is the floor and the figure. A Listener who tries to draw what she sees finds her hand will not close on the pencil in the cold of the wet-silence corridor. She must draw by memory, surfacing. The drawings made from memory disagree with each other in small things: the figure's arm is raised in all drawings, but the hand's angle differs; the figure's clothing is described differently by every drawer. The bright thing is drawn the same.

*Ambient.* Halvon's slate has on its reverse a single extra knot not counted in the main signal-system. The knot is a Listener's mark for *I am afraid and I do not wish to be.* The mark is old. Halvon tied it last. Sula has seen it. Sula has not transcribed it.

## Storyline links
- **Line B — World Before the Fog (central pre-Fog evidence).** The upper hall's inscription and the pedestal's *kor-reh-ehn-ast* line give Eilin two fresh sentences. The Second Sun, witnessed, is the clearest visible pre-collapse artefact in the Reach — but it cannot be surfaced, which protects the premise.
- **Line E — Depth-Walkers.** Kestrel has been here twice; Sula's standing list "to-reach" contains the Second Sun. A Crosser team might attempt to widen the crack (not in v0.1).
- **Line A — Guild's Buried Charter.** Halvon's slate is a Guild-lost document.
- **Line C — Four-Crown Intrigue.** Malen, told of a "saint's lamp that still burns," would send a quiet pilgrim-delegation. She has not been told.
- **Line D — Iron Dragon.** Weak tie: the hall's painted *kor-thal* compound shares a root with the Iron-Dragon warning.
- **Named NPCs.** Halvon (dead, slate present), Kestrel (visitor), the unnamed saint (inscription, absent).
- **Quest hooks.** (1) Retrieve Halvon's slate for the Guild. (2) Take rubbings of both inscriptions for Eilin. (3) Draw the far chamber's floor-figure for Kestrel. (4) Do not widen the crack.

## Writer notes
<!-- writer-only -->
The Second Sun is a large illumination installation or reactor pile in a collapsed far-side chamber, isolated by the crack. The floor-figure is a human-sized shape — probably a colonist who did not leave. Do not describe it in modern terms; it is a shape on the floor, not moving. The Crack is a windowed-premise-breach: a PC can see a clean colonial interior and cannot explain it in any modern term, because they do not have the vocabulary. This is the design trick — the premise stays hidden because the player cannot read it. The "colour the eye cannot rest on" is a prose-only tell; the light is a familiar modern warm-white, and to a pre-industrial eye it has no category. Keep it unexplained.
<!-- /writer-only -->

## Map sketch
```
[Stair up the crag]
       |
[Zone 2: Upper Hall / vel-kor-thal paint / grating]
       |
(shaft, rope + pegs)
       |
[Zone 3: Beacon shaft-bottom / empty pedestal]
       |
[Zone 4: wet-silence corridor — Held Breath, Bone-Lamp]
       |
[Zone 5: the Crack → Second Sun visible beyond]
       |
(far chamber: unentered, Tier-F)
```
