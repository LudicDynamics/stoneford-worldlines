# D007 — The Fogmoor Hide

## Snapshot
A Fog-walker outlaw camp dug into a peat-bog between Stoneford and Windrest, four days from any patrol and a day and a half from any road, where "the line" — Veyl — has wintered three times. Players enter because a caravan was robbed there and the Guild's patrol cannot find it, because Veyl left a message in the Windrest forge that points here, or because the Fogmoor raiders have been taking only Jade-Road caravans and the pattern is too specific to be simple banditry.

## Location
- Nearest town: T001 Stoneford / T002 Windrest Keep
- Region: The Grey Reach, Fogmoor fen
- Terrain approach: The road from Stoneford to Windrest (R001) carries patrols. Off the road, due south in summer and due north-east in winter, the moor is fen-country — peat hags, open water, reed-islands. The camp is on a reed-island a hard day's slog from the road. The path in is marked by **Fog Cairn-Signs** — two for friends, three for strangers with news, four for turn-back.

## Historical layers
- **Pre-collapse.** The moor was drier then. A single pale-alloy post — a trail-marker — stands knee-deep in peat at the island's centre. The camp's current fire-pit is beside it.
- **Fog-era.** The moor fogged up after the waves' second century. Fog-walkers — a cultural group neither Crown nor Faith — settled the edges. The Fogmoor Hide has been reused for generations by whoever needed it.
- **Current.** Veyl "the Line" wintered here three years ago. Twice more since. He is not here now, but his winter-gear is stored in the low-hut. The current tenants are a small band — four people — who took Jade-Road caravans last spring under Veyl's planning.

## Structure — surface camp, hide-and-seek

### Zone A — The Approach / *the cairn path* / Fog-walker convention
- **Description.** The reed-islands lead one to the next across peat and shallow water. The reeds are tall — a man's height — and the path is not visible from three paces off-track.

  Each crossing is a sequence of stepping-stones set a pace apart, or, where stones run out, a plank laid on the peat and weighted at both ends with a rock. The planks are hand-hewn. The rocks are river-stones. A Fog-walker who has walked the path before steps in a rhythm; a stranger stumbles.

  The path is marked by small cairns. Each cairn has a code: two stones for a quiet welcome; three for strangers expected; four, a warning to leave. The cairns sit on tussocks of grass that the reeds do not overtake. A Fog-walker does not need to look at the cairn; they feel the tussock underfoot.

  In fog, the path is legible only by the cairns. In clear weather, a stranger can see ten paces. In fog, three.

- **Hazards.** Peat sinks — a misstep is a chest-deep drop, and the peat closes around the leg like a fist. **Mire-Hulk (M008)** lives in the third fen west of the path; its passage is a long mud-smear broken by sunken prints the size of a shield.
- **Creatures.** M008 Mire-Hulk (approach encounter). **Fogwort** patches (fog-induced madness if burned indoors; outdoors, used as signal-smoke); the fogwort in these fens is particularly pale, its heads the colour of old snow.
- **Items / relics.** *Ash Cloak / fog-walker cloak*. *Valley-Pipe / fog-walker reed*.
- **Clues / fragments.** The current cairn-sign is three stones: *strangers expected with news.* The tenants have been waiting for someone. The top stone of the three has been set flat-side up; in fog-walker convention, flat-side-up means *today, not in a week*.
- **Exits.** Onto the island.

*Ambient.* The cairn-tussocks under the reed-path are, by Fog-walker reckoning, alive — the grass on them does not die in winter, and in the wettest springs the tussocks float a finger higher than the surrounding peat. Rhu teaches apprentices to step on tussock-centres, not tussock-edges. A wrong step is a peat-drop.

*Pre-encounter traces (Mire-Hulk).* A long smear of mud across a fen west of the path reads, to a patient eye, as a single continuous passage — the Hulk's last transit was two days ago, moving north. The smear is still soft at its edges. A raven has walked a little way along the smear and stopped where the smear began to firm. The raven's footprints are delicate against the churn.

### Zone B — The Outer Camp / *the fire-pit*
- **Description.** A reed-island, a hundred paces across, raised two feet above the water. The island is higher at the centre and lower at the rim; the rim is always wet, the centre is dry enough to sit on.

  A fire-pit beside the pale-alloy post. The pit is stone-lined, well-used, the stones blackened on their inner faces. Ash piled to one side. The ash is grey and feather-light; a breeze lifts it in small spirals that do not carry.

  Four reed-thatched lean-tos, set at the four compass directions a fog-walker reads: toward-road, away-from-road, toward-rising, away-from-rising. The toward-road lean-to has its door-flap tied open. The others are closed.

  A drying-rack of fish runs along the north edge of the island. The fish are lake-fish, not fen-fish; they were brought in. The rack's frame is pale-alloy — salvaged, bent, lashed with hide. The alloy does not rust in the fen-wet. Over time the Fog-walkers have come to trust the rack without knowing why.

- **Hazards.** Sentries — two, one at the cairn-path's last crossing, one at the north fish-rack. Dogs — none (the moor eats dogs).
- **Creatures.** Four Fog-walker outlaws. A **Hollow Raven** pair on the post's top — they are not pets. They have simply found the post a good vantage and the outlaws have decided not to disturb them.
- **Items / relics.** *Clan-Knife*, *Horn-Recurve Bow*, *Bone Whistle* — each outlaw's kit, kept on the body, not stored. *Wind-Meat / high-cure* in the drying-rack.
- **Clues / fragments.** The outlaws speak a clipped Stoneford dialect with a Windrest lilt on the vowels. Their leader is a woman called Rhu, who has Veyl's handwriting in a small book on her belt. The book's cover is worn at the corners. She touches it absent-mindedly when she thinks.
- **Exits.** To the low-hut. To the pale-alloy post (a shallow dig at its base).

*Ambient.* The fire-pit's ash has a faint warmth at the centre even on cold mornings when no fire has been lit the night before. The warmth is below the point of a bare hand feeling it — a thermometer would read the difference; a palm would not. Rhu has laid a palm on the ash many times. She does not know the ash is warm. The warmth is in the ground, not in the ash.

*Ambient.* Rhu's small book of Veyl's handwriting has a dog-eared page — the only dog-ear in the book. The page carries a single sentence in Veyl's clipped hand: *when the line falls, the line continues.* Rhu has read this sentence many times. She does not know that Veyl wrote it after a dream, and that the dream was of a road with a bright thing at the end of it.

### Zone C — The Low-Hut / *Veyl's winter* / private hut
- **Description.** A turf-roof hut, the roof grown over with the same moss as the island. Door of skin — deer-hide, scraped, oiled. The inside is dim and warm; warmer than the outer camp. A banked coal in a stone bowl keeps the damp down.

  A bunk, a strap-chest, a lantern hung from a rafter. Cold. Clean. A second bunk rolled against the wall — Veyl keeps a second bunk because Veyl travels with a second sometimes, but not always.

  The hut smells of tallow, of a man's sweat gone stale, of the particular smoky-herb of fogwort used as a lamp-wick additive (one pinch in ten, Fog-walker practice). A second smell — leather, and a finer oil — is under the rest. That smell is Veyl's.

- **Hazards.** A trip-wire across the threshold — Rhu's insurance. The wire is **Soft-Rope** cordage, Listener-grade; a loan from Kestrel, presumably. The wire is set a hand's breadth above the sill; a tall man steps on it; a short woman clears it.
- **Creatures.** None.
- **Items / relics.** In the strap-chest: a folded *Greymantle Cloak*, a *Sapper's Pick / miner's pry*, a *Courier-Dirk / Windrest slip*, a pinch of **Slow-Stone**, and a flat wooden box. Inside the box: a **Brass-beetle** case of matches, a scrap of **Sky-Ivy** pressed, and a copy — not the original — of the **Colonist Crest Fragment (Tier-E)**, cast in wax by a careful hand. The wax is thick, the impression crisp. The original is in Veyl's own pocket.
- **Clues / fragments.** Veyl's notebook (hidden under the bunk-boards) has entries in two hands. The first hand is Veyl's: dates, place-names, a tally of "straight-line-cloud" sightings (eleven in four years). He writes in a clipped script; he does not use more words than he must. The second hand is a woman's — dated, terse, signed only with the glyph *sai*. She reports relic-trades at Jadehollow and a Crosser's request. The second hand is Rhu's correspondence with Kestrel. The two hands meet on one page — a marginalia in Veyl's hand, *who writes this?*, answered in Rhu's, *a friend.*
- **Exits.** Back to outer camp.

*Ambient.* Veyl's smell — the leather-and-fine-oil — sits under the hut's other smells without mixing with them. A visitor who has met Veyl once recognises it. A visitor who has not met him does not mistake it for a nose-trick; it is definite, low, a man's smell kept in a small room. Rhu does not notice it. She has lived with it too long.

*Ambient.* The banked coal in the stone bowl is refreshed every dawn. The coal is a specific hardwood, carried in from Windrest. Rhu burns nothing else here. The choice is not for scent; the choice is because the hardwood, burnt slow, does not smoke. The hut has no chimney.

### Zone D — The Post Dig / *the pale stake*
- **Description.** Around the pale-alloy post, the peat has been cut back to show a collar of pale-stone a handspan below the surface. The peat-cut is ragged on the east side — it is an old dig, re-opened. On the west side, it is clean: Rhu opened it.

  The collar is inscribed: *thal-reh-dun-u* — dwelling-cliff-end-prohibited. Do-not-dwell-at-the-edge. The letters are cut clean into the pale-stone. The peat has not stained them.

  A small, deliberately Fog-walker carved mark has been added below, in a different hand: two stones and a dash — *friends rest here*. The Fog-walker mark is knife-cut, not chisel-cut. The pale-stone took the knife-cut shallow; the pale-stone is harder than the knife. Two knives have been blunted on it. The Fog-walkers know this and have not tried a third.

- **Hazards.** Peat-sink. Standing water in the cut.
- **Creatures.** None.
- **Items / relics.** The post itself — un-hammerable, **Unbreakable Metal (kor-nor)**-family, a single slim rod. The post is cool to the touch at all seasons. Veyl has considered removing it; he has not. If any PC tries, the rod will not come; the peat will give first, and a PC pulling against the rod will end chest-deep in cold peat with the rod still standing and their weight not on it.
- **Clues / fragments.** The inscription is one of the most explicit visible colonial warnings a PC can read without dispensation. Eilin has a rubbing via Rhu's second-hand notes.
- **Exits.** Back.

*Ambient.* The cut around the post has its own small microclimate: standing water in the peat-cut runs a slightly different colour from the surrounding fen-water — a clearer brown, slightly warmer. The difference is small enough that a new outlaw will not notice. Rhu notices. Rhu drinks only from the cut's water, unboiled, when she has been out long. She has not been sick.

### Zone E — The Caravan Cache / *the stolen row*
- **Description.** A second, smaller reed-island a hundred paces south-east of the camp, screened by tall reeds. The crossing between the two islands is a narrow plank on peat, weighted at both ends. The plank sags in the middle; a heavy crossing sinks it to the ankles.

  On the cache-island, a stack of wagon-crates under oiled canvas. The canvas is fresh — last year's. The crates are branded with Jade-Road merchant marks; one brand is still legible, *CAUL & SON / consignment*.

  The contents are Jade-Road consignments: *Jade Road Map*-family trade charts, *Counting-String / Union worry-knot*, *Honest-Copper* bundles, *Ashcrown Royal Silver*, *Brass Ticket* rolls.

- **Hazards.** Single sentry with a Horn-Recurve. He sits against a crate and watches the water. He has been warned about the rushes; a rustle in the rushes that is not wind makes him stand.
- **Creatures.** One outlaw.
- **Items / relics.** Trade-goods (as listed). A sealed merchant-letter addressed to Tobiah Caul, unopened. The seal is Union-wax, a merchant hexagon.
- **Clues / fragments.** One of the Jade-Road map-tubes contains a second, hidden rolled sheet — a Crosser working-sketch (a small copy of "from below, we may rise"). The sketch is in Kestrel's own hand. Rhu is a Crosser agent working under Veyl's cover. Veyl does not know.
- **Exits.** Back to the camp path.

*Ambient.* The cache-island sentry, a man called Tem, watches the water in long bored patience. He has a pipe he does not light. He has a small tally-scratch on the crate beside him, one scratch per hour of watch, grouped in fives. He has been on this watch for the last twelve days; Rhu is rotating the guards slowly. Tem has begun to hum a four-note phrase that he does not know is the same phrase Hallen hums in D003 Cell 7. Neither man has met the other. Neither knows the tune.

## Storyline links
- **Line D — Iron Dragon Returns (central for Veyl).** Veyl's notebook is a Line D clue inventory. His matchbox and pressed Sky-Ivy echo his established kit. The post is Free-North-metal family — ties to Line C (Brenna).
- **Line E — Depth-Walkers.** Rhu is a Crosser cell under Veyl's cover; Kestrel supplies her with Soft-Rope; the hidden sketch is an E-line fragment placed at a D-line location (which is not the deep-archive T004 library canon copy, but a working copy — canon-compatible).
- **Line C — Four-Crown Intrigue.** The Jade-Road raids' target-pattern suggests crown-side caravans were being sieved for relic-shipments. The unopened Caul letter is a C-line wedge.
- **Line A — Guild's Buried Charter.** Guild patrols have failed to find this camp for four years. Either the Guild is incompetent, or the Guild knows. A-line suspicion fodder.
- **Line B — World Before the Fog.** The Post Dig's *thal-reh-dun-u* is a clean pre-collapse warning inscription — B-line rubbing.
- **Named NPCs.** Rhu (band-leader, Crosser), Veyl "the Line" (absent, winter ghost), three unnamed outlaws, Navigator Kestrel (absent, correspondent).
- **Quest hooks.** (1) Guild patrol commission: find and clear the camp. (2) Tobiah's commission: recover the unopened letter. (3) Kestrel's quiet ask: protect Rhu's cover. (4) Bram's worry: Veyl wintered here.

## Writer notes
<!-- writer-only -->
The post is a fragment of the same kor-nor family as Brenna's armour — a colonial-era trail-marker still in situ. Rhu is a Crosser agent; her double-loyalty (Veyl-front, Kestrel-back) is the cross-line knot here. Veyl must not be present in v0.1 at this location; his gear is the tell, not the man. If Veyl is pressed narratively to appear, he appears at Windrest or on the road, never here. The post's coolness-at-all-seasons is an embedded-colonial-metal property; leave it unexplained in player-facing text.
<!-- /writer-only -->

## Map sketch
```
          [R001 Grey Road]
                 |
          (off-road, peat)
                 |
          [cairn path / 3-stone sign]
              /  |  \
   [M008 fen] [island] [fens]
                 |
         [Zone B: fire-pit, post]
           /     |      \
      [low-hut][dig][reed-screen ↘]
                            |
                   [Zone E: caravan cache]
```
