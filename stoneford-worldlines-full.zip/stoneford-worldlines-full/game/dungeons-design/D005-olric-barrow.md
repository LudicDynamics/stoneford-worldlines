# D005 — Olric's Barrow

## Snapshot
A Faith-era crypt cut into the cliff below Wolfsjaw Pass, holding the two-century grave of Keeper-Commander Olric the Silent — the Guild's first Magister, buried without his name — and a Faith-guarded stair that nobody has legally opened in forty years. Players enter for the Guild's founder-seal, for a Faith suit that requires witness of the grave, or because a sealed letter at Tower Three of D004 was meant to be delivered here.

## Location
- Nearest town: T003 Wolfsjaw Pass
- Region: The Grey Reach, northern mountain spur
- Terrain approach: Half a league south-west of T003 along the Faith's pilgrim path. A cliff-face door framed with pale-stone salvaged from no one knows where. Two Septons stand watch in summer; none in winter, when the ice seals the door.

## Historical layers
- **Pre-collapse.** A small First-Wave waystation stood on this rock shelf — a single room, cut from the cliff, lined with pale-stone. The waystation was a rest-stop, nothing more. Its door-frame survived. The rest did not.
- **Faith-era.** Three hundred years ago, the Faith expanded the waystation into a crypt for the keepers of the Northern Ban. Olric the Silent was buried here two hundred years ago, at the back of the new crypt, in a niche lined with the old waystation's surviving pale-stone. The Faith does not say his name aloud. The grave's plaque reads only *the keeper*.
- **Guild-era.** Magister Corvin Ashford-Reed believes, correctly, that Olric's niche carries the first draft of the **Northern Ban** — the decree that quotes the stone shard's text. The Faith will not allow a Guild reading. The Faith's refusal is on record; the record is the half-burned copy now at Archivist Naryn's cabinet in Wolfsjaw. The original is at D005.
- **Current.** The door is sealed by Faith law. The inner stair is guarded against readers, not against thieves. A thief might pass; a scholar is stopped at the gate.

## Structure — surface crypt, functional zones

### Outer Ward — The Pilgrim Door / *the Keeper's Gate*
- **Description.** A door of dark oak banded with iron, recessed in a pale-stone frame that is older than the door by five centuries. The oak is three fingers thick; the iron bands are forge-black with two centuries of tallow-polish.

  The pale-stone frame is a different thing. Its colour does not match the mountain-stone around it; its stone is the colour of a winter cloud, and its edges are straight where a mason's chisel would leave them curved. The corners of the frame are sharp. A finger drawn along the top lintel finds no chisel-scarp, no tool-track — only the stone, patient.

  The Faith seal — a knotted four-point — is pressed into the oak with fresh wax. The wax is renewed each quarter-moon. The septon who renews it uses the same ring his grandfather used. The ring's pattern is slightly worn on one lobe; the wax carries the wear.

- **Hazards.** Two Septons in summer; a pilgrim's challenge. The Septons are old and one of them is half-deaf; the other watches.
- **Creatures.** None.
- **Items / relics.** *Pilgrim's Pass* required. *Pilgrim's Grey Stone* if challenged.
- **Clues / fragments.** The pale-stone frame carries faint roots: *ehn-thal* — silence-dwelling. Eilin has a rubbing. The rubbing is in her third codex-box, the one she does not show to the Faith.
- **Exits.** Inner antechamber.

*Ambient.* The summer Septons are brothers — twins, from a village on the Shale's upper bend — and they have kept the door for twenty-nine summers. They speak little. They sit on a bench of their own carving. They eat cold lamb and hard bread at noon. The half-deaf one is the elder by a quarter-hour; the other has learned to nod where a word is expected. A pilgrim who greets them in the Faith-form is let pass; a pilgrim who does not is asked, by the younger, in a voice so soft it is itself a kind of deafness, *what have you come to hear?*

### Antechamber — The Reading Room *(Faith-use)*
- **Description.** A stone room, ten paces across, with a narrow table and a single book on the table. The book is a register of pilgrim-readings. Its cover is dark *Seal-Leather*, worn smooth at the spine by generations of septon thumbs.

  The walls are painted with a frieze of the Faith's saints; the paint is faded at waist-height where robes have brushed for two hundred years. The saints above waist-height are bright enough to read their attributes: a finger to the lips, a book held open, a child at a hem. Below waist-height, the paint is a slow grey smear and the saints lose their faces.

  The air is dry. A lantern set on the table burns steady; the flame does not flicker at a whisper, but flickers at a hand-motion. A septon present will not comment on this; a visitor who notices it is usually a Listener, and the Listener will note it privately.

- **Hazards.** The register tracks names; any PC who registers truthfully will be searchable by Faith agents afterward. A septon who suspects a false name will not challenge; he will make a small mark in the margin with his thumbnail.
- **Creatures.** A duty Septon may be present.
- **Items / relics.** The register — bound in *Seal-Leather*. A *Cathedral Bell-Rope* hangs at the wall, running up a small bell-shaft to the summer-Septons' post. The bell-rope's end is frayed. A septon has been practising a knot on it, absent-minded.
- **Clues / fragments.** The last five entries are in the same hand. The book has been tampered with: two entries' ink dates disagree with their neighbours' by a year. The ink of the two tampered entries is slightly glossier than the surrounding entries — the paper has not had time to take the ink flat. A reader who sees this can guess: someone is back-dating Faith visits to Olric's grave.
- **Exits.** West into the Keepers' Hall. North into the Faith's small chapel (not dungeoned — exit into Wolfsjaw).

*Ambient.* The antechamber's lantern has an eccentric flame: it leans at a whisper but not at a breath. A visitor who leans forward to sign the register and speaks the keeper's name under her breath sees the flame bend inward toward her. A pilgrim who simply breathes does not see the flame move. The difference is in whether there is intent behind the sound. The septons have known this for generations. They do not mention it.

### Keepers' Hall / *the long room* / Faith name: *the saints' corridor*
- **Description.** A long vaulted chamber, twelve paces by four. The vaulting is low; a tall man stoops by habit under the second arch. The stone is dressed cliff-rock, not pale-stone; the Faith built this hall themselves.

  Each side wall holds six stone niches; each niche holds a carved stone coffin. Twelve coffins. The coffins are labelled only with numbers in old-tongue: *ast* through *keth-dun*. These are the Keepers of the Northern Ban.

  Eleven of the twelve coffins are dated and named on a secondary brass plate bolted beside the stone. The brass is polished in parts, tarnished in others. A hand passes over the plates at shoulder-height by habit — pilgrim tradition — and the hand-brightened strip runs down the hall, one strip per plate.

  One — the twelfth, *keth-dun*, at the far end — is labelled only *the keeper*. No date. No second name. The brass plate is smaller than the others, and newer; it was re-fixed a generation ago by a septon who did not approve of blankness and who, for his disapproval, made the blank plate himself, neater than the original.

- **Hazards.** The air is dry and dust-heavy. A lantern sets the dust glowing; a long breath in the hall tastes of the centuries the hall has held.
- **Creatures.** **Silent Mouse** — multiple — nest in the brass plates. They do not run from light.
- **Items / relics.** Eleven brass plates bear Keeper names, dates, and a single-line epitaph. Plate Twelve is blank.
- **Clues / fragments.** The eleven named plates, read in sequence, give the succession. Two names are visibly over-stamped (the original name chiselled out and a new name set). The over-stamps are crude — the re-cut letters sit a hair off the baseline. A reader familiar with Guild records can identify the over-stamps as the two Keepers who attempted the Faith's internal destruction of the **Northern Ban** seven and fifteen years ago respectively.
- **Exits.** Back. North into Olric's Niche.

*Ambient.* At the hall's midpoint, a small pilgrim-rest — a stone bench along the east wall — bears the polish of two hundred years of waiting pilgrims. The polish is brightest at a span fit for two sitters side by side. Pilgrims come in pairs. They wait here together, then proceed one at a time to Olric's niche. The waiting-pair is the custom. Neither of the current summer Septons knows why.

*Ambient.* The twelfth plate's blankness has, across generations, drawn a small ritual: a visiting septon lays his palm on the blank brass at the end of the hall and leaves it there for the count of a slow breath. The palms have polished the blankness to a deep gleam. The brass, polished this way, reflects a little more warmly than the named plates.

### Olric's Niche / *the last coffin* / Guild-private name: *the founder's room*
- **Description.** A small alcove off the far end of the hall. Three paces deep, three paces wide. The coffin is set into the back wall, pale-stone where the hall is cliff-stone. Above the coffin, a niche of pale-stone — original waystation stone, salvaged and set as an honour-marker.

  The niche holds a folded document, unsealed, and beside it a single relic: a small hand-bell of pale alloy. The bell is the size of a woman's fist, the clapper a length of dark-wood tapering to a bone tip. A rubbing of the bell's lip, taken by a Listener two generations ago, shows faint roots along the rim.

  The coffin's plaque reads *the keeper*. A traveller who kneels at the coffin and reads the plaque finds the letters cut deep; the cut-bottoms are smooth. Beneath the plaque, the stone has a faint groove worn into it where, for two centuries, a septon's thumb has pressed at the end of each service.

- **Hazards.** The alcove is colder than the hall by five degrees. The cold is not draught-cold; it is a held cold, as from a cellar that has never been opened to summer. A Faith ward — a line of salt and blood-wax across the threshold — is laid. Crossing the ward without dispensation triggers a silent alarm (a bell in the summer-Septon's post rings). The alarm-bell is small. It rings twice.
- **Creatures.** A **Windrest Revenant (M007)**-type figure appears here on nights the Guild has broken an oath. Hollow armour; it salutes and fades if addressed by its garrison roll-name, which is *Olric.* — this is the same name. The armour is Windrest-pattern. The plate at the breast has a dent that matches a known blow from the Khanate border war, two centuries gone.
- **Items / relics.** The folded document is the **original Northern Ban**, undamaged, in Olric's hand. It is not catalogued Tier-E in the relic ledger because the Faith denies its existence; the half-burned copy (Naryn's cabinet) is the publicly-known version. The hand-bell is a **Distant-Voice Stone (Tier-E)**-family object, larger, older — the Faith does not know it is a relic. Rung, it produces a low murmur as the bedside stones do. The murmur is not loud. It is felt in the sternum first, then the ear.
- **Clues / fragments.** The Ban's text quotes the **Ancient Stone Shard (Silas's)**: *vel-bren, kor-thal, san-tol, ven-u* — the colonist warning roots. Olric's preface, in his hand: *this land is not ours. we hold it by borrowing. we shall not visit the lender.* The preface's ink is older than the Ban's main text by what a careful reader would call a decade — Olric drafted, waited, and then wrote the Ban.
- **Exits.** Back into Keepers' Hall.

*Ambient.* Olric's plaque is inscribed in a hand that is, to a Faith-trained reader, too steady — the septons of that time did not cut so cleanly. Corvin has examined rubbings and has privately concluded that Olric cut his own plaque before his death. The stone underneath the cut carries, faintly, the wear of a second inscription pre-emptively scraped — as if Olric had first written a name and then removed it, before writing *the keeper.* The scraped space is the size of a name.

*Ambient.* The hand-bell on its stand gives a faint answering murmur when any bell in Wolfsjaw rings above ground. The Faith sexton who stands watch at Olric's niche in summer has noted this; he assumes the bell is pious. It is not pious. It is answering.

*Pre-encounter traces (Windrest Revenant).* On the nights the Revenant appears, the ward of salt-and-wax on the threshold dries to a crust and cracks; a septon finding the crack in the morning knows. The cracks are always shaped the same — a single line from east to west, as if a long hem had dragged across the threshold.

### Sub-level — The Waystation Remnant *(side branch, hidden door in Olric's Niche's floor)*
- **Description.** Below the niche, a square trap-door of pale-alloy, hinged, unlocked. The hinge does not squeak. The alloy is warm under a bare hand; a septon who ever found it would report the warmth as a saint's favour.

  Down three steps is the original First-Wave waystation room — six paces square, pale-walled, a single built-in pale-stone bench, a pale-stone basin in one corner that holds a finger's depth of still water always. The walls are clean. No lichen. No dust. The air is dry and the dryness is not the dryness of the hall above — it is a different dryness, older, as if the room had been breathing its own air for a thousand years.

  The bench is the length of a tall man lying down. The basin is set flush into the floor; its water does not evaporate and does not fill. A palm laid on the basin's rim finds the stone cool, and the water — if tasted — tastes of nothing. Not of stone. Not of rain. Of nothing.

  There is no candle-soot anywhere on the walls. No scratches. No marks. The room has never been slept in by any hand that left evidence.

- **Hazards.** The air is stale. A **Cave-Salamander** lives in the basin, pale, a finger long. It does not move. It looks at the water.
- **Creatures.** Salamander.
- **Items / relics.** The basin. The bench. A single pale-stone chip has fallen from the wall onto the bench; it is small, fingernail-sized, incised with a single glyph: *reh*. The chip is dust-free; it fell recently, or it does not gather dust.
- **Clues / fragments.** The room is the clearest surviving colonial interior in the Reach's accessible ground. Eilin would give a year's pay to enter. No PC has brought her yet.
- **Exits.** Up through the trap-door.

*Ambient.* The sub-level basin's water does not ripple at a shout. A visitor who leans over the basin and calls her own name into the water sees the surface unbroken. A hand dipped in the water wets the hand; the dip makes a ripple. Voice makes none. The water is listening for a different kind of disturbance.

*Ambient.* The bench's surface, run with a hand from head to foot, gives a faint sustained hum for the duration of the run. The hum stops when the hand stops. The bench does not vibrate to a tap. It vibrates to a drag. The Crossers would name this a mark of purpose; no Crosser has been down these stairs.

## Storyline links
- **Line A — Guild's Buried Charter (central).** Olric's niche holds the Guild's founding document and the untampered Northern Ban. Retrieving or documenting either is a Line A climax beat at T004–T005.
- **Line B — World Before the Fog.** The Ban quotes the shard. The sub-level waystation is the cleanest pre-Fog room accessible without royal dispensation. Eilin ≠ accessible; Vossel the Younger (T002) could be brought.
- **Line C — Four-Crown Intrigue.** The over-stamped Keeper plates are Faith internal politics; Malen's predecessors tried to destroy the Ban. A C-line reveal.
- **Named NPCs.** Archivist Naryn (T003, holds the half-burned copy), Corvin Ashford-Reed (T005, would read the original). Keeper-Commander Olric the Silent (dead 200y, interred here — Line A sub-soul figure).
- **Quest hooks.** (1) Retrieve the Ban's original for Corvin. (2) Ring the hand-bell once (Faith heresy, Distant-Voice reveal). (3) Bring Vossel to the sub-level. (4) Prove the over-stamps to Naryn.

## Writer notes
<!-- writer-only -->
The sub-level is a deliberate clean-colonial-room reveal that does not break the premise: pale walls, pale bench, still-water basin, a single glyph. No modern vocabulary is to be used; Eilin's later reading will treat it as a hermit's cell. The hand-bell's nature should not be stated in player-facing text; only its murmur is to be described. If the party rings it, Malen at T005 will, that night, report a saint's whisper she has not heard before. The basin's water-of-nothing is a passive condensation loop — the room is partly functional. Keep the prose pre-modern; let the impossibility accumulate on the player's ear without ever being stated.
<!-- /writer-only -->

## Map sketch
```
[Pilgrim door] — [Antechamber: register, bell-rope]
                       |
            [Keepers' Hall: 12 niches]
                       |
            [Olric's Niche: Ban, hand-bell, ward]
                       |
          (trap-door) [Sub-level: First-Wave waystation]
```
