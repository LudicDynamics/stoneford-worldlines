# D002 — Jadehollow Mines, Level Three

## Snapshot
The sealed third level of the Deepvein shafts beneath Jadehollow, closed by the mining company after the miners said they heard something digging from the other side. Players enter for the Guild's relic run, for Deepvein's tame-it-or-kill-it bounty, or because a Crosser cell needs a witness on the far side of the seal.

## Location
- Nearest town: T004 Jadehollow
- Region: The Grey Reach, eastern mountain-vein
- Terrain approach: The company road up from T004 ends at the Deepvein gate-house. Two guards check chits. Past the gate, the main adit runs east under the mountain. Level 1 is working (miners, cave-salamanders). Level 2 is half-worked. Level 3 has been sealed for eleven months: a wall of timber and stacked stone, caulked with Slow-Stone-mixed pitch at the edges.

## Historical layers
- **Pre-collapse.** Beneath the bone-rooms of Jadehollow lies the colonial-era transit shelf — a long level chamber cut with tools no miner's tool marks. The Third Wave used this shelf to stage the jade-vein's first cartage. When contact ended, the transit shelf was never re-entered from the far-side end. Something has been coming back toward it.
- **Guild-era.** Deepvein Mining Company opened the shafts two hundred years ago. Level 3 was productive for a decade, then struck the bone-rooms and was mined cautiously — Guild Listeners worked alongside miners, pulling up **Twelve-Below (B-0018)** and (later) **Speaking House** rumours. The wet gallery below held the **Jade-Sleeper (M004)**.
- **Current.** Eleven months ago, the senior shift-captain heard a regular, percussive *tock* coming from the east face — not the irregular patter of settling stone but a deliberate rhythm. Three nights of it. Then miners began to hear a child counting in the old tongue: *ast, bel, keth, dun, sai.* The Deepvein directors sealed Level 3 from the working side. The seal has held. The sound has not stopped; it has got slower.

## Structure — mine levels with tier correspondence

Level 1 is operational (not dungeoned here). Level 2 is Shallow-find, still worked. Level 3 below the seal is Bone-rooms tier. Level 4 (the flooded gallery) is Wet-silence tier and holds the Jade-Sleeper.

### Zone A — The Gate-House & Adit / *the company mouth*
- **Description.** Stone archway, company crest (a jade drop inside a hexagon) cut shallow above. Somebody has chalked a tally mark beside the crest — forty-odd marks — and somebody else has tried to wipe them off. The chalk remains as a grey stain.

  The adit runs into the mountain at a steady downslope. The first twenty paces are daylight. After that, oil lamps hang from iron hooks, one every ten paces. Each lamp has a hood. The hoods are soot-black on the near face and clean on the far face. Men come out of here; they do not go in.

  The rails are narrow-gauge, pitted with ore-dust. They ring under a boot like bell-metal. An ore-cart left at the siding has a name scratched into its flank — *Teo* — and a second name scratched out beneath it. The air smells of cold stone and of coal-smoke that has nowhere to rise.

- **Hazards.** Deepvein guards (company). Ore-carts on rails — runaway carts kill one miner a year, reliably. Dust-cough air after the tenth lamp.
- **Creatures.** Company men, not monsters. One of them is the dog-boy Perr, thirteen, who speaks to the carts as if they were animals and is not wrong to.
- **Items / relics.** *Miner's Headlamp-Rig* available for requisition. *Brass Ticket / road-ticket* required for entry.
- **Clues / fragments.** A posted notice, re-pasted monthly: *Level 3 is Closed by order. No claim of seniority overrides this closure.* Signed by Old Shepherd Bram's nephew, a shift-captain. The paste on this month's copy is still tacky. Below it, half torn away, a second notice — a Guild memo, countersigned by Sula, the countersignature smaller than the main hand.
- **Exits.** Inward to Level 1 working-face (not dungeon). Down the drop-shaft to Level 2.

*Ambient.* The adit's lamps are kept by a lamp-boy named Hen, twelve years old, who has inherited the job from his father, who inherited it from his. Hen trims the wicks at dawn, before the shift goes in, and at dusk when the last shift comes out. He knows each lamp by its hook-number. The tenth lamp, which hangs at the air's change of taste, he calls *the bad one.* It is the lamp that smokes first. He trims it twice a day.

*Pre-encounter traces (Deepvein guards).* The guard-house beside the gate has a slate where the morning's pass-chit numbers are chalked. The slate is wiped at shift-change. At the bottom of the slate, half-wiped, one chit-number stands unerased: 4-1-1. It has been the bottom chit for the last three weeks. The guards have noticed. They have not asked. The chit-holder, if any, has not been seen leaving.

### Zone B — Level 2, Deepvein Working-Face / *the shallow dig*
- **Description.** A long chamber half-worked. Jade veins branch in the wall like pale green roots, and some of them are wet. Water drips from the ceiling in a slow, uneven pattern; the pattern is the mountain breathing. The floor is loud with gravel.

  Four side galleries, two collapsed. The two that stand are lit by single wall-lamps. The two that have fallen are not lit. A miner's rule: do not look into the dark branches. A miner's practice: look anyway.

  The Listener Ren's dig camp is still pitched in the north gallery — a canvas roll, a kettle with tea gone to sludge, a marked-up map pinned to a board, a rope neatly coiled and dusted. Ren is in T005 now; she has not returned in six months. The kettle has not been moved. The coil of rope has, and it has been put back in slightly the wrong place by somebody who wanted it to look untouched.

- **Hazards.** Loose ceiling in the collapsed galleries — a pebble falls, and then, two counts later, a second pebble, and then nothing, for hours. A pocket of **Coinflower** bloom in the north gallery (taboo: do not bring coinflower indoors; the blooms are the colour of old silver and smell of turned milk).
- **Creatures.** **Cave-Salamanders** along the water-runnels (harmless; ring M004's pool on the level below). **Lamp-Moths** at every flame — their wings sound like paper being folded.
- **Items / relics.** *Road Lantern / guild-lantern*, *Fire-Striker Kit* in Ren's camp. A pinch of **Slow-Stone (C-0055)** in a tin, the tin lid pressed down hard, the metal around the lid rimed with faint blue frost even in summer.
- **Clues / fragments.** Ren's map shows Level 3's sealed side, drawn in confident ink. The east end of Level 3 — beyond the seal — is drawn in pencil, lighter, with a single question mark. A margin-note in her hand: *the tock follows my lantern. It waits for me to listen.* Pinned next to the map: a Listener's rubbing of the seal's outward face, showing a single glyph pressed into the pitch — *reh* (great-cliff). The glyph is clean. Somebody pressed it deliberately.
- **Exits.** Down to Zone C (Level 3 sealed chamber) via the drop-shaft. Across a squeeze-passage to Zone F (flooded gallery — locked until seal is breached).

*Ambient.* Ren's kettle, when lifted, is heavier than it looks: there is a finger of condensed black liquid at the bottom that has been there for six months. It smells of nothing. A Cave-Salamander has drowned in it; the salamander is at the bottom, pale, preserved, eye-open. The kettle has been there for the count-of-missing-Ren. Nobody has tipped it out. Nobody quite wants to.

*Pre-encounter traces (Lamp-Moths).* Before the moths swarm a lantern, the paper-folding sound begins half a minute off, faint, from the direction the moths will come from. Ren's camp has a small notebook of times-of-moth, kept on the map-board's back, which reads, in twenty entries, the same minute of dusk within a count of five. The moths are clockwork. Ren had begun to find this significant.

### Zone C — The Seal Chamber / *the caulked wall* (company) / *the waiting face* (Listeners)
- **Description.** A round chamber ten paces across. The east wall is the seal: dark timber cross-beamed with iron bands, the gaps filled with pitch gone black and glossy. The pitch reflects a lantern like still water.

  The pitch bulges outward in two places, gently, as if something on the other side is pressing it with a flat palm and thinking. One bulge at chest height. One at the knee. The chest bulge is the width of a man's hand. The knee bulge is the width of a child's knee. The bulges do not move while anyone is watching. They are, the next day, measurably further out.

  The air in the chamber is two degrees warmer than the corridor. The difference is felt first in the fingers, then in the cheek. A lamp set on the floor here burns whiter than it does in the corridor. Nobody has explained this. A rope is tied to a ring in the floor and runs into a crack in the pitch at the east wall's base. The rope twitches. It has been twitching, on and off, for eleven months. The twitches are not rhythmic. They are not random either.

- **Hazards.** Carbon-monoxide pocket if a lantern is left burning too long (the chamber vents poorly; a lit lamp in the closed chamber turns a man's lips blue inside half an hour). The *tock* — once per breath now, very slow — can be heard with an ear to the wall. It is a small, hard sound, as of a single pebble dropped on a plate. Anyone who holds their ear to the wall for longer than a count of forty hears a child's voice counting: *ast, bel, keth, dun, sai*. The voice is neither near nor far. It is in the ear. Sanity-grade cost (writer discretion).
- **Creatures.** None visible, this side of the wall.
- **Items / relics.** **The Measured Breath (D-0019)**, if the party carries it on loan from the Guild, pins to the far end of its run when brought within two paces of the seal. A *Hearth-Root Ash-Box* set by the company; the ash is renewed weekly to check for movement in the pitch. This week's ash has a fingerprint in it. Not a miner's finger.
- **Clues / fragments.** The bulging points on the pitch are two: one at chest height, one at knee height. A knee-print. A hand-print. Both smaller than a man's. The rope's far end is out of sight; an experienced climber can guess thirty paces of play, not more. The rope is **Soft-Rope (B-0031)**, Guild-lent; it was knotted here by Ren eleven months ago and she has not returned to untie it. The knot is a Listener's bight, the kind Kestrel teaches; Ren did not know that knot before Kestrel.
- **Exits.** Back to Zone B. Through the seal into Zone D — **only if the seal is breached**. Breaching is a loud, slow job: hours of work, visible and audible from Level 2. Deepvein guards will come.

*Ambient.* The chamber's ceiling sweats a single slow drip that has cut a shallow cup into the flagstone below. The drip has not stopped in eleven months. The cup is half a finger deep. The water in the cup is warmer than the air. The cup's shape is perfectly round, as though bored by a mason, not by a drip. Nobody has explained the roundness; a drip at this angle should have cut an oval.

*Ambient.* A dog belonging to the shift-captain's nephew entered Zone C three months ago, walked to the pitch, sniffed the knee-bulge, and sat down with its back to the wall. It sat for an hour. When it got up, it walked to the door and waited to be let out. It has not entered the chamber since. The dog is old and patient and not known for drama. The nephew has not told his uncle.

*Pre-encounter traces (the tock).* An ear at the wall gives a count of one *tock* per breath. An ear at the wall for a count of forty gives, underneath the tock, a faint dragging sound — something being moved across stone, slowly, with pauses. The drag is not regular. It is not the tock's child. It is a second sound, kept separate, that stops when the tock stops.

### Zone D — The Transit Shelf / *the far-side digging* (Crossers) / *the level chamber* (Listeners)
- **Description.** Past the seal, the chamber continues. The floor is cut flat in a way no miner's chisel cuts — every stone the same plane, every join tight as a book's spine. The walls are pale, the colour of bone in summer, and they do not sweat. The ceiling is too regular; a rule laid against it anywhere reads the same span.

  In the centre of the floor is a hole the width of two men — round, black, not exhaling, not inhaling: **The Black Mouth / Tier-F / rumoured**. It is perfectly circular. The rim is smooth. A lantern lowered into it does not brighten the stone of the shaft, which has no texture for light to catch.

  A fresh trench runs from the east wall toward the seal, a span of forty paces, dug from the far side by a small implement that left a straight cut — not the ragged curve of a pickaxe-bite but a single straight line, as if somebody had drawn the trench with a ruler and the stone had obliged. The trench is empty now. The digger has withdrawn.

  Along the trench's edge, dust has settled in a pattern that is not a footprint. Something with a flat base, wider than a man's foot, narrower than a table. No boot-sole. No claw.

- **Hazards.** The Black Mouth. Do not drop anything in it. A rope lowered does not return; the rope, fed down, goes slack at thirty paces and remains slack however much more is fed. Standing too near the edge for a count of one hundred, the edge feels closer than it was. Turn your back and the edge is further. Neither is true. Both are felt.
- **Creatures.** None present. The digger has withdrawn back east along the transit shelf, where the air grows warmer and the ceiling lowers. (Not playable in v0.1; a rumour-space for v0.2+. The "child counting" is audible here, clearer, and stops when the party is silent. It resumes when any member of the party clears their throat.)
- **Items / relics.** The trench yields small pale-metal fragments — offcuts — that the Crossers would name as *kor*-family. The fragments are warm. A single **Slow-Stone** lump, larger than any in circulation, sits at the east wall. Its underside is wet.
- **Clues / fragments.** At the east wall, a stack of three small stones — a cairn — built by a hand not yet seen. The stones are from this side of the seal; somebody from the far side gathered them, here. On top of the cairn, a bent nail of pale metal. Kestrel will pay for this nail. Sula will forbid its surfacing.
- **Exits.** East into the transit shelf proper (not playable in v0.1 — described for future). Back west through the breached seal.

*Ambient.* The Black Mouth does not draw air. A hand held above it feels no updraft and no down. A feather dropped over the edge falls, and the fall is straight, and the feather is lost within three paces of falling below the rim — not because of darkness, but because the feather simply is not there to be seen, as if the Mouth's inside were not made of the same kind of space as the outside.

*Ambient.* The Slow-Stone lump at the east wall sweats its underside in a patient slow. The sweat gathers as a small pool on the flagstone beneath it. The pool has, on its surface, a thin film that catches lamp-light in bands of colour — not rainbow, not oil-slick, something else. Kestrel has seen this kind of film before; he will not say where.

*Pre-encounter traces (the digger, withdrawn).* The digger is not present but its recent passage is. The cut-end of the trench is clean. No pause-marks. No re-cuts. The stone at the cut's face shows faint parallel scoring, as if four tools had worked abreast. The scoring is at a height below a standing man's waist. The digger, if it is a standing thing, is not tall.

### Zone E — Bone-Rooms (side branch off Zone C) / *the bone-tier proper*
- **Description.** A narrow stair south from Zone C drops two turns into a dry chamber floored with pale knuckle-stones — the bone-rooms. The stones are not bones, despite the name. They are pale, knuckled, the size of a child's fist, and they fit together without mortar. A floor made of small decisions.

  Twelve-Below (B-0018) was surfaced here. The surface-site is still visible: a shallow pit in the floor where one knuckle-stone has been lifted and never replaced. The pit is dry. A finger dipped in the pit comes out warm.

  A Listener altar stands undisturbed at the chamber's far end: a flat stone with twelve chips of jade laid in a ring. The chips are of equal size. Five of them have been rotated since the last Listener visit; the rotation is not random.

- **Hazards.** Dry air that rasps the lungs. Loose knuckle-stones underfoot (balance checks). A knuckle-stone carried out of the chamber grows cold within the hour; in the chamber, they are warm.
- **Creatures.** **Silent Mouse** (E/A taboo: do not crush a blind-newt in a mine — extends by common Listener convention to the mice). A **Lamp-Moth** swarm in the far corner; they do not cross a chalk line laid across the floor.
- **Items / relics.** A second **Twelve-Below**-family plate, smaller, three indentations instead of twelve. Guild-undocumented. *Old-Tongue Potsherd* at the altar, its glyph half under a jade chip.
- **Clues / fragments.** The altar's chips are laid in a pattern matching the seal's outward glyph: *reh*. A note in Ren's hand on the altar: *if we stop hearing the counting, worry. the silence is worse.* The note is pinned down with a fourth knuckle-stone, the only one in the room placed by a human hand.
- **Exits.** Back to Zone C.

### Zone F — The Flooded Gallery / *the Jade-Sleeper's pool* / Wet-tier
- **Description.** Reached by a squeeze-passage from Zone B: thirty paces of crawling, belly to stone, water up to the elbows, the roof low enough that a man's pack scrapes a continuous sound along it. The crawl ends in a breath of warmer air.

  The passage opens into a low-ceilinged cavern, the ceiling a hand above a standing man. A warm pool sits at the centre, perfectly round, five paces across. Cave-salamanders ring the pool's rim, pale, the size of a finger, motionless. Their eyes are open. They are not looking at the water.

  The water is warmer than any other in the mountain. Steam lifts from it in thin columns that bend, near the ceiling, toward the east wall. A lantern held over the pool gutters. A lantern held over the rim burns steady.

  In the pool, curled, **a pale long-limbed beast breathes once a minute.** The breath raises the water's surface by a finger's width, and lowers it again. The count between breaths is exact.

- **Hazards.** The **Jade-Sleeper (M004)**. Dormant most of the year. Hunts for two nights in late winter — the two nights are the two warmest nights of that season, predictable to Bram and to no one else. Threat 5. Deepvein hides the body-count; the count stands at nineteen over forty years.
- **Creatures.** M004 Jade-Sleeper (dormant unless disturbed). **Cave-Salamanders** (harmless; if one is lifted from the rim, it goes cold in a hand within a count of fifty, and returns warm when set back).
- **Items / relics.** None to surface here without waking the sleeper. *Wet-Eye (C-0021)* sister-piece rumoured in the pool's bottom — Sula has a copy from this level, surfaced thirty years ago by a Listener who is no longer alive and who did not sleep for the last year of her life.
- **Clues / fragments.** Salamander shed-skins in a ring around the pool, a finger's width thick, paper-dry. Along the wall, a single line of the old tongue incised into wet stone: *bren-ehn* (body-silence, or sleeping-thing). A Listener's chalk mark below it reads *do not name*. The chalk is fresh. Somebody renews it.
- **Exits.** Back to Zone B.

*Ambient.* The pool's single-breath rhythm sets a clock for anyone standing at the rim. The body begins, within a count of thirty, to breathe with the pool. A Listener alone in the gallery and unbraced will find her own breath has slowed to the Jade-Sleeper's pace. The slowing is pleasant. It is difficult to break.

*Pre-encounter traces (Jade-Sleeper).* On the nights the Sleeper hunts, the salamanders leave the rim an hour before. On the nights it does not, they sit. The hunt-nights' salamanders have been seen to walk in a ring around the pool, against the sun's turning, before leaving. It is the only time these salamanders walk. The walk is Bram's one sign. He does not teach it to his nephew.

## Storyline links
- **Line D — Iron Dragon Returns.** Q_T004_01 (hibernating Frostwolf megabeast) resolves here — though the "Frostwolf megabeast" framing is Deepvein's lie; the real menace is the transit-shelf digger behind the seal. Q_T004_02 (Deepvein wants to tame the Jade-Sleeper) routes through Zone F. Old Shepherd Bram (T004) knows more than he says; his nephew signs the closure notice.
- **Line E — Depth-Walkers.** Crossers (Kestrel) want the bent nail from Zone D. Listeners (Sula) have a standing order that any cell hearing the counting child is to surface immediately. The party encounters this split through Yannic "Yan" Vello (T002), who wants to come with them as far as Zone B.
- **Line A — Guild's Buried Charter.** The Guild wants the seal opened quietly, documented, and re-sealed. The Measured Breath is their loan to the effort.
- **Line B — World Before the Fog.** Eilin reads the wet-stone inscription (*bren-ehn*) and will want a rubbing.
- **Named NPCs.** Old Shepherd Bram (T004), Navigator Kestrel (T004), the Listener Ren (currently T005), Yannic "Yan" Vello (T002), Deepvein directors (T004), the unnamed shift-captain nephew.
- **Quest hooks.** (1) Guild commission: reseal Zone C, quietly. (2) Deepvein commission: bring back the digger's offcuts to prove it is not a Frostwolf. (3) Crosser commission: retrieve the nail. (4) Sula's counter-order: do not breach the seal; surface any cell that has heard counting.

## Writer notes
<!-- writer-only -->
The digger on the far side is a small remote-operated or semi-autonomous mining unit from the dead far-side civilization, waking after a century and digging east-to-west toward the old transit shelf. It is not malevolent; it is executing an old order. The counting child is a calibration loop — a recording used to test audio equipment on the transit line — cycling through the surviving local node. If the party fully breaches the seal in v0.1, they find the trench empty (the unit withdraws at the sound of breaking pitch). The Black Mouth is the main transit shaft, still live in some sense. Sula fears it, correctly. Kestrel venerates it, correctly for the wrong reasons. Do not resolve in v0.1; keep the tock present, slowing. The dust-pattern along the trench edge is the unit's tracked base; leave it unexplained.
<!-- /writer-only -->

## Map sketch
```
[Gate-house] → [Adit] → [Level 1 working]
                           |
                     [drop-shaft]
                           |
                      [Zone B: Level 2 dig]
                       |       |       |
                [Zone C seal] [squeeze→F: pool, M004]
                   |      |
             [breach]   [Zone E: bone-rooms]
                |
          [Zone D: transit shelf + Black Mouth]
                |
          [east into transit — v0.2+]
```
