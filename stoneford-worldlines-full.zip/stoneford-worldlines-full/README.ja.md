# Stoneford-on-the-Shale

**Language:** [English](./README.md) · [简体中文](./README.zh.md) · [日本語](./README.ja.md) · [한국어](./README.ko.md)

> ステータス: Preview — WorldLines v0.1.0 の看板サンプル

> **免責事項：** Stoneford-on-the-Shale はファンによるトリビュートおよびパロディ作品です。George R.R. Martin の *A Song of Ice and Fire* その他言及される作品との類似は、創作および教育目的のみを意図しています。第三者の商標およびキャラクターは各権利者に帰属します。

> *三つの王国を看取った河の渡し。*
> ローファンタジー · 政治陰謀 · d20 判定 · 6-Agent Orchestrator。
> トーンドリフト：ローファンタジーの政略劇 × 陰鬱な怪物狩人フロンティア × 東洋的異界メタフィジックス。

**Stoneford-on-the-Shale** は WorldLines に同梱されるリファレンス
世界です。React における `create-react-app` のように、fork し、
名前を変え、自分の世界として送り出すためのスターターです。

`templates/stoneford-worldlines/` に配置され、
`neonrp game new --template stoneford` のデフォルト対象です。

---

## 設定

灰の希望（grim-hopeful）寄りのファンタジー。舞台は **The Grey Reach**、
朽ちゆく北の王国 **The Ashcrown** — 「力の代償、誓いの重み、北の沈黙」。
d20 判定、地に足の着いた魔法、家の政治。

プレイヤーは **Stoneford** から開始。River Shale 沿いの河港町で、
三つの家と五つの派閥がせめぎ合います。

### Stoneford 三家

| House          | Words                                   | 座                | 状態                       |
|----------------|-----------------------------------------|-------------------|---------------------------|
| **Blackwater** | *The River Remembers*                   | ギルド            | 現当主 Heron              |
| **Ashford**    | *From Ash, We Rise*                     | 宿                | 最後の相続人 Mira         |
| **Deepvein**   | *What Lies Beneath, We Claim*           | Jadehollow の鉱山 | Stoneford 不在            |

### 五派閥

Crown's Hand · The Faith · Free North · The Union · The Fog。

ドリフトノート全文は、より広い Ludic Dynamics ドキュメント
`task-storywriting/published/05-stoneford.md` を参照。

---

## クイックスタート

新規プロジェクトから：

```bash
neonrp init
neonrp game new --template stoneford
neonrp tui
```

TUI の `/init` 後でも：

```
/game new --template stoneford
```

---

## Agent アーキテクチャ

Stoneford は v2 Orchestrator パターン：trigger パターンを持つのは
Orchestrator のみ、ドメイン Agents は `task()` 経由で呼ばれ、単一の
状態を共有します。

```
Layer 1: orchestrator        — 状態 + ルーティング + 仕上げのナレーション（ローファンタジー政略劇調）
Layer 2: town-agent          — 街の全交互（ナビ / NPC / shop / guild / inn）
         dungeon-agent       — Mossbarrow 探索
         combat-referee      — d20 戦闘解決
         world-builder       — ワールドマップ更新
         rules-referee       — 非戦闘判定 + ルール整合性
```

| Agent             | レイヤ | 役割                                                    |
|-------------------|--------|---------------------------------------------------------|
| `orchestrator`    | 1      | 状態管理、ルーティング、ナレーション、ジャーナル        |
| `town-agent`      | 2      | 街: ナビ、NPCs、shop、guild、宿                         |
| `dungeon-agent`   | 2      | ダンジョン探索と部屋                                    |
| `combat-referee`  | 2      | d20 戦闘解決 + 状態効果                                 |
| `world-builder`   | 2      | ワールドマップ更新、地域 lore                           |
| `rules-referee`   | 2      | ルール照会、ハウスルール解釈                            |

---

## ワールドコンテンツ

**5 つの街**

| ID    | 名前              | 備考                                               |
|-------|-------------------|----------------------------------------------------|
| T001  | Stoneford         | 出発地。ギルド、店、宿、波止場。                   |
| T002  | Windrest Keep     | 軍駐屯地。House Stoneshield の守備隊。             |
| T003  | Wolfsjaw Pass     | 山道。密輸の検問所。                               |
| T004  | Jadehollow        | 鉱山町。Deepvein 氏族。坑夫ユニオンの蠢き。        |
| T005  | Mistmere          | 湖畔都市。Septry、祠、沈んだ区画。                 |

**旗艦ダンジョン 1 つ**

- **D001 The Mossbarrow** — Stoneford 近郊の 4 部屋古墳。Ashford 地下。

**クエスト**

- 5 街にまたがる 28 の名前付きクエスト（ギルド懸賞、派閥依頼、
  個人的な頼み）、ボス戦 1 本（*The Drowned Thing*）を含む。
- 3 本の絡み合う **backlines**（クエストを横断する政治陰謀）。

**ルール**

- d20 + 能力修正判定。
- HP、状態効果、死亡の帰結は世界史に記録。

---

## ディレクトリ構成

```
templates/stoneford-worldlines/
├── README.md                     <- ここ
├── LICENSE                       <- AGPL-3.0
├── agents/
│   ├── orchestrator/
│   ├── town-agent/
│   ├── dungeon-agent/
│   ├── combat-referee/
│   ├── world-builder/
│   └── rules-referee/
└── game/
    ├── meta/
    │   ├── run_state.json        # 場所、時刻、直近のアクション
    │   └── game-start.json       # オープニング + ブートストラップ読込
    ├── player/                   # 7 ファイル: profile / stats / inventory / ...
    ├── towns/                    # T001..T005
    ├── dungeons/                 # D001
    ├── rules/
    │   └── combat_rules.md
    ├── lore/                     # houses, religions, regions
    └── world/                    # world map, region index
```

---

## git submodule として使う

Stoneford は独自リポジトリに住み、検証済みバージョンをピン留めし、
エンジンと独立に更新できます。

```bash
# WorldLines ドキュメント / デプロイリポジトリ内で
git submodule add https://github.com/ludic-dynamics/stoneford-worldlines templates/stoneford-worldlines
git submodule update --init --recursive

# 後日更新
git submodule update --remote templates/stoneford-worldlines
```

`neonrp game new --template stoneford` 実行時の解決順：

1. `./templates/<name>/`（サブモジュールパス）
2. `~/.neonrp/templates/<name>/`
3. エンジン同梱フォールバック

## 自分の世界のために Stoneford を fork

```bash
cp -R templates/stoneford-worldlines templates/my-world
# その後:
#  - houses / towns / NPCs の名前を変更
#  - agent レイアウトは維持（再利用部分）
#  - agents/*/system.md をトーンに合わせて編集
neonrp game new --template my-world
```

---

## 関連

- [../../QUICKSTART.ja.md](../../QUICKSTART.ja.md)
- [../../CONCEPTS.ja.md](../../CONCEPTS.ja.md)
- [../../CLI_REFERENCE.ja.md](../../CLI_REFERENCE.ja.md)

---

## ライセンスと謝辞

Copyright © 2026 Ludic Dynamics.

stoneford-worldlines は **AGPL-3.0-only** で公開されます。全文は
[LICENSE](LICENSE) または https://www.gnu.org/licenses/agpl-3.0.html
を参照。ネットワーク越しにユーザーと対話する改変版を運用する場合、
対応するソースコードをそのユーザーに公開する必要があります。

先行プロジェクト `llm-rpg-starter` からのドリフト。ナラティブ設計は
Ludic Dynamics 創業者。d20 ルールはオープン SRD 慣習を参考。

Ludic Dynamics コミュニティ、そして本リリースを支えてくれた amber
はじめ友人たちに感謝を。
