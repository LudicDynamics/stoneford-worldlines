# Stoneford-on-the-Shale

**Language:** [English](./README.md) · [简体中文](./README.zh.md) · [日本語](./README.ja.md) · [한국어](./README.ko.md)

> 상태: Preview — WorldLines v0.1.0 의 대표 샘플

> **면책 고지:** Stoneford-on-the-Shale 는 팬 기반의 트리뷰트이자 패러디(parody) 작품입니다. George R.R. Martin 의 *A Song of Ice and Fire* 또는 기타 참조 작품과의 유사성은 오직 창작 및 교육 목적을 위한 것입니다. 모든 제3자 상표 및 캐릭터는 각 소유자의 재산으로 유지됩니다.

> *세 왕국보다 오래 살아남은 강의 나루터.*
> 로우 판타지 · 정치 음모 · d20 판정 · 6-Agent Orchestrator.
> 톤 드리프트: 로우 판타지 정치 음모 × 음울한 몬스터 헌터 변방 × 동양적 이계 형이상학.

**Stoneford-on-the-Shale** 는 WorldLines 와 함께 배포되는 레퍼런스
월드입니다. React 생태계의 `create-react-app` 같은 존재로, fork 하고
이름을 바꿔 자신의 월드로 출시할 수 있는 손맛 있는 스타터입니다.

`templates/stoneford-worldlines/` 에 있으며,
`neonrp game new --template stoneford` 의 기본 대상입니다.

---

## 세팅

회색 희망(grim-hopeful) 톤의 판타지, 쇠락하는 북방 왕국 **The Ashcrown**
의 **The Grey Reach** 가 무대 — "힘의 대가, 맹세의 무게, 북녘의 침묵".
d20 판정, 차분한 마법, 가문 정치.

플레이어는 **Stoneford** 에서 시작합니다. River Shale 강가의 항구 마을,
세 House 가 거하고 다섯 파벌이 얽힙니다.

### Stoneford 의 세 House

| House          | Words                                   | 거점             | 상태                       |
|----------------|-----------------------------------------|------------------|---------------------------|
| **Blackwater** | *The River Remembers*                   | 길드             | 현 당주 Heron             |
| **Ashford**    | *From Ash, We Rise*                     | 여관             | 마지막 후계 Mira          |
| **Deepvein**   | *What Lies Beneath, We Claim*           | Jadehollow 광산  | Stoneford 에 없음         |

### 다섯 파벌

Crown's Hand · The Faith · Free North · The Union · The Fog.

드리프트 노트 전체는 더 넓은 Ludic Dynamics 문서
`task-storywriting/published/05-stoneford.md` 를 참고.

---

## 빠른 시작

새 프로젝트에서:

```bash
neonrp init
neonrp game new --template stoneford
neonrp tui
```

TUI 에서 `/init` 이후:

```
/game new --template stoneford
```

---

## Agent 아키텍처

Stoneford 는 v2 Orchestrator 패턴을 씁니다: trigger 패턴을 가진 것은
Orchestrator 뿐이며, 도메인 Agents 는 `task()` 툴을 통해 호출되고
단일 상태를 공유합니다.

```
Layer 1: orchestrator        — 상태 + 라우팅 + 마무리 서술 (로우 판타지 정치극 톤)
Layer 2: town-agent          — 마을의 모든 상호작용 (내비 / NPC / shop / guild / inn)
         dungeon-agent       — Mossbarrow 탐험
         combat-referee      — d20 전투 판정
         world-builder       — 월드 맵 업데이트
         rules-referee       — 비전투 스킬 판정 + 규칙 일관성
```

| Agent             | 레이어 | 역할                                                   |
|-------------------|--------|--------------------------------------------------------|
| `orchestrator`    | 1      | 상태 관리, 라우팅, 서술, 저널                          |
| `town-agent`      | 2      | 마을: 내비게이션, NPCs, 상점, 길드, 여관               |
| `dungeon-agent`   | 2      | 던전 탐험과 방                                         |
| `combat-referee`  | 2      | d20 전투 해결 + 상태 효과                              |
| `world-builder`   | 2      | 월드 맵 업데이트, 지역 lore                            |
| `rules-referee`   | 2      | 규칙 조회, 하우스 룰 해석                              |

---

## 월드 컨텐츠

**5 개의 마을**

| ID    | 이름              | 비고                                               |
|-------|-------------------|----------------------------------------------------|
| T001  | Stoneford         | 시작 마을. 길드, 상점, 여관, 부두.                 |
| T002  | Windrest Keep     | 군사 주둔지. House Stoneshield 의 수비대.          |
| T003  | Wolfsjaw Pass     | 산길. 밀수업자 검문소.                             |
| T004  | Jadehollow        | 광산 마을. Deepvein 씨족. 광부 노조 동요.          |
| T005  | Mistmere          | 호수 도시. Septry, 사당, 가라앉은 구역.            |

**대표 던전 1 개**

- **D001 The Mossbarrow** — Stoneford 근처의 4 방 고분. Ashford 지하실.

**퀘스트**

- 5 마을에 걸친 28 개 명명 퀘스트 (길드 현상금, 파벌 의뢰, 개인 부탁),
  보스 조우 1 (*The Drowned Thing*) 포함.
- 3 개의 얽힌 **backlines** — 퀘스트를 가로질러 피어나는 정치 음모.

**규칙**

- d20 + 능력 보정 판정.
- HP, 상태 효과, 죽음의 결과는 세계사에 기록.

---

## 디렉터리 구조

```
templates/stoneford-worldlines/
├── README.md                     <- 여기
├── LICENSE                       <- AGPL-3.0
├── agents/
│   ├── orchestrator/
│   ├── town-agent/
│   ├── dungeon-agent/
│   ├── combat-referee/
│   ├── world-builder/
│   └── rules-referee/
└── game/
    ├── meta/
    │   ├── run_state.json        # 위치, 시간, 마지막 액션
    │   └── game-start.json       # 오프닝 서술 + 부트스트랩 읽기
    ├── player/                   # 7 파일: profile / stats / inventory / ...
    ├── towns/                    # T001..T005
    ├── dungeons/                 # D001
    ├── rules/
    │   └── combat_rules.md
    ├── lore/                     # houses, religions, regions
    └── world/                    # world map, region index
```

---

## git 서브모듈로 사용

Stoneford 는 자체 저장소에 있어, 알려진 좋은 버전을 고정하고 엔진과
독립적으로 업데이트할 수 있습니다.

```bash
# WorldLines 문서 / 배포 저장소 안에서
git submodule add https://github.com/ludic-dynamics/stoneford-worldlines templates/stoneford-worldlines
git submodule update --init --recursive

# 이후 업데이트
git submodule update --remote templates/stoneford-worldlines
```

`neonrp game new --template stoneford` 실행 시 CLI 탐색 순서:

1. `./templates/<name>/` (서브모듈 경로)
2. `~/.neonrp/templates/<name>/`
3. 엔진 패키지 기본값

## 나만의 월드를 위해 Stoneford fork

```bash
cp -R templates/stoneford-worldlines templates/my-world
# 그리고:
#  - houses, towns, NPCs 이름 변경
#  - agent 레이아웃은 유지 (재사용 가능한 부분)
#  - agents/*/system.md 를 원하는 톤에 맞게 편집
neonrp game new --template my-world
```

---

## 참고

- [../../QUICKSTART.ko.md](../../QUICKSTART.ko.md)
- [../../CONCEPTS.ko.md](../../CONCEPTS.ko.md)
- [../../CLI_REFERENCE.ko.md](../../CLI_REFERENCE.ko.md)

---

## 라이선스 및 감사

Copyright © 2026 Ludic Dynamics.

stoneford-worldlines 는 **AGPL-3.0-only** 로 공개됩니다. 전문은
[LICENSE](LICENSE) 또는 https://www.gnu.org/licenses/agpl-3.0.html
참고. 네트워크 상에서 사용자와 상호작용하는 수정 버전을 운영할 경우,
해당 사용자에게 대응 소스 코드를 공개해야 합니다.

선행 프로젝트 `llm-rpg-starter` 에서의 드리프트. 내러티브 디자인은
Ludic Dynamics 창립자. d20 규칙은 오픈 SRD 관례에서 차용.

Ludic Dynamics 커뮤니티, 그리고 이번 릴리스를 가능하게 해준 amber 및
그 밖의 친구들에게 감사를 전합니다.
