# Stoneford-on-the-Shale

**Language:** [English](./README.md) · [简体中文](./README.zh.md) · [日本語](./README.ja.md) · [한국어](./README.ko.md)

> 状态：Preview — WorldLines v0.1.0 的头牌样本

> **免责声明：** Stoneford-on-the-Shale 是受粉丝启发的致敬与戏仿（parody）作品。与 George R.R. Martin 的 *A Song of Ice and Fire* 或其他被引用作品的任何相似之处，仅用于创作与教育目的。所有第三方商标与角色归其各自所有者所有。

> *一座活过三个王国的河口渡口。*
> 低魔奇幻 · 政治阴谋 · d20 判定 · 6 Agents Orchestrator。
> 气质漂移：低魔政治权谋 × 阴郁怪物猎人边境 × 东方异界玄学。

**Stoneford-on-the-Shale** 是 WorldLines 附带的参考世界。对这个引擎来说，
它就像 React 生态里的 `create-react-app`：一个你可以直接上手、fork、
改名，然后用来发布自己世界的动手 starter。

它位于 `templates/stoneford-worldlines/`，是 `neonrp game new --template
stoneford` 的默认目标。

---

## 设定

灰希望（grim-hopeful）风味的奇幻，舞台设于 **The Grey Reach**——一个
衰败的北境王国 **The Ashcrown**——"权力的代价、誓言的重量、北方的沉默"。
d20 判定，低魔，家族政治。

玩家从 **Stoneford** 开始——River Shale 河畔的河港小镇，三家割据，
五方博弈。

### Stoneford 三大家族

| 家族            | 族语                                   | 座位             | 状态                       |
|----------------|----------------------------------------|-----------------|---------------------------|
| **Blackwater** | *The River Remembers（河记得一切）*    | 公会所          | 在任——由 Heron 掌家       |
| **Ashford**    | *From Ash, We Rise（自灰烬中升起）*    | 旅馆            | 仅存末裔 Mira             |
| **Deepvein**   | *What Lies Beneath, We Claim*          | Jadehollow 矿脉 | 长期不在 Stoneford         |

### 五大阵营

Crown's Hand · The Faith · Free North · The Union · The Fog。

完整漂移笔记见更大范围的 Ludic Dynamics 文档
`task-storywriting/published/05-stoneford.md`。

---

## 快速上手

从全新项目开始：

```bash
neonrp init
neonrp game new --template stoneford
neonrp tui
```

或在 TUI 中 `/init` 之后：

```
/game new --template stoneford
```

---

## Agent 架构

Stoneford 使用 v2 Orchestrator 模式：只有 Orchestrator 持有 trigger
模式，领域 Agents 通过它的 `task()` 工具被调用，共享同一份状态。

```
Layer 1: orchestrator        — 状态 + 路由 + 终章叙事（低魔政治权谋调式）
Layer 2: town-agent          — 城镇所有交互（导航 / NPC / shop / guild / inn）
         dungeon-agent       — Mossbarrow 探索
         combat-referee      — d20 战斗判决
         world-builder       — 世界地图更新
         rules-referee       — 非战斗技能检定 + 规则底线
```

| Agent             | 层级 | 角色                                                    |
|-------------------|------|---------------------------------------------------------|
| `orchestrator`    | 1    | 状态管理、路由、叙事、日志                              |
| `town-agent`      | 2    | 城镇：导航、NPCs、shops、guild、旅馆                    |
| `dungeon-agent`   | 2    | dungeon 探索与房间                                      |
| `combat-referee`  | 2    | d20 战斗判决 + 状态效果                                 |
| `world-builder`   | 2    | 世界地图更新、区域 lore                                 |
| `rules-referee`   | 2    | 规则查询、house-rule 澄清                               |

---

## 世界内容

**5 座城镇**

| ID    | 名字              | 备注                                              |
|-------|-------------------|---------------------------------------------------|
| T001  | Stoneford         | 起点城。guild、shop、旅馆、码头。                 |
| T002  | Windrest Keep     | 军事据点。House Stoneshield 驻军。                |
| T003  | Wolfsjaw Pass     | 山口。走私者检查站。                              |
| T004  | Jadehollow        | 矿镇。Deepvein clan。矿工工会暗流涌动。           |
| T005  | Mistmere          | 湖城。教堂、圣地、沉没街区。                      |

**1 个旗舰 dungeon**

- **D001 The Mossbarrow** —— Stoneford 附近的 4 房间古冢。Ashford 地窖。

**任务**

- 5 座城镇共 28 个命名任务（guild 悬赏、阵营请求、个人人情），
  含 1 个 boss 战（*The Drowned Thing*）。
- 3 条相互交织的 **backlines**——跨任务发酵的政治阴谋。

**规则**

- d20 + ability modifier 判定。
- HP、状态效果、死亡后果写入世界历史。

---

## 目录结构

```
templates/stoneford-worldlines/
├── README.md                     <- 你在这
├── LICENSE                       <- AGPL-3.0
├── agents/
│   ├── orchestrator/
│   ├── town-agent/
│   ├── dungeon-agent/
│   ├── combat-referee/
│   ├── world-builder/
│   └── rules-referee/
└── game/
    ├── meta/
    │   ├── run_state.json        # 地点、时间、最后一次操作
    │   └── game-start.json       # 开场叙述 + bootstrap 读取
    ├── player/                   # 7 个文件：profile / stats / inventory / ...
    ├── towns/                    # T001..T005
    ├── dungeons/                 # D001
    ├── rules/
    │   └── combat_rules.md
    ├── lore/                     # houses、religions、regions
    └── world/                    # 世界地图、区域索引
```

---

## 作为 git submodule 使用

Stoneford 放在它自己的仓库里，这样你可以钉住一个已验证版本、独立于
引擎去拉更新。

```bash
# 在你的 WorldLines 文档 / 部署仓库里
git submodule add https://github.com/ludic-dynamics/stoneford-worldlines templates/stoneford-worldlines
git submodule update --init --recursive

# 之后要更新
git submodule update --remote templates/stoneford-worldlines
```

`neonrp game new --template stoneford` 执行时按名查找：

1. `./templates/<name>/`（submodule 路径）
2. `~/.neonrp/templates/<name>/`
3. 引擎自带 fallback

## Fork Stoneford 构建你自己的世界

```bash
cp -R templates/stoneford-worldlines templates/my-world
# 然后：
#  - 重命名 houses、towns、NPCs
#  - 保留 agent 布局；那是可复用的部分
#  - 编辑 agents/*/system.md 以匹配你的基调
neonrp game new --template my-world
```

---

## 另见

- [../../QUICKSTART.zh.md](../../QUICKSTART.zh.md)
- [../../CONCEPTS.zh.md](../../CONCEPTS.zh.md)
- [../../CLI_REFERENCE.zh.md](../../CLI_REFERENCE.zh.md)

---

## 许可与鸣谢

Copyright © 2026 Ludic Dynamics.

stoneford-worldlines 基于 **AGPL-3.0-only** 发布。完整条款见
[LICENSE](LICENSE) 或 https://www.gnu.org/licenses/agpl-3.0.html。
若你在网络上运行本程序的修改版本并与用户交互，必须对这些用户开放
相应的源码。

漂移自更早的 `llm-rpg-starter` 项目。叙事设计由 Ludic Dynamics 的创始人
完成。d20 规则参考开放 SRD 惯例。

感谢 Ludic Dynamics 社区，感谢 amber 和其他让本次发布成为可能的朋友。
