# Stoneford-on-the-Shale

**Language:** [English](./README.md) · [简体中文](./README.zh.md) · [日本語](./README.ja.md) · [한국어](./README.ko.md)

> Status: Preview — headline sample for WorldLines v0.1.0

> **Disclaimer:** Stoneford-on-the-Shale is a fan-inspired tribute and parody work. Any resemblance to *A Song of Ice and Fire* by George R.R. Martin or other referenced works is for creative and educational purposes only. All third-party trademarks and characters remain property of their respective owners.

> *A river crossing that has outlived three kingdoms.*
> Low fantasy · Political intrigue · d20 dice resolution · 6-Agent Orchestrator.
> Tone drift: low-fantasy political intrigue × grim monster-hunter frontier × eastern other-world metaphysics.

**Stoneford-on-the-Shale** is the reference world shipped with WorldLines.
It is to this engine what `create-react-app` is to React: a hands-on
starter you can fork, rename, and ship your own world from.

It lives at `templates/stoneford-worldlines/` and is the default target
of `neonrp game new --template stoneford`.

---

## Setting

A grim-hopeful fantasy set in **The Grey Reach**, a decaying northern
kingdom called **The Ashcrown** — *"the price of power, the weight of
oaths, the silence of the north"*. d20 resolution, grounded magic,
family politics.

The player begins in **Stoneford**, a river-port town on the River
Shale, home to three Houses and caught between five factions.

### Three Houses of Stoneford

| House          | Words                              | Seat             | Status                       |
|----------------|------------------------------------|------------------|------------------------------|
| **Blackwater** | *The River Remembers*              | The Guild        | Active — Heron is head       |
| **Ashford**    | *From Ash, We Rise*                | The Inn          | Last heir — Mira             |
| **Deepvein**   | *What Lies Beneath, We Claim*      | Jadehollow mines | Absent from Stoneford        |

### Five Factions

Crown's Hand · The Faith · Free North · The Union · The Fog.

Full drift notes live in the wider Ludic Dynamics docs at
`task-storywriting/published/05-stoneford.md`.

---

## Quickstart

From a fresh project:

```bash
neonrp init
neonrp game new --template stoneford
neonrp tui
```

Or inside the TUI after `/init`:

```
/game new --template stoneford
```

---

## Agent Architecture

Stoneford uses the v2 Orchestrator pattern: only the Orchestrator owns
trigger patterns. Domain Agents are invoked through its `task()` tool,
over a single shared state.

```
Layer 1: orchestrator        — State + routing + final narrative (low-fantasy political voice)
Layer 2: town-agent          — All town interactions (navigation / NPC / shop / guild / inn)
         dungeon-agent       — Mossbarrow exploration
         combat-referee      — d20 combat adjudication
         world-builder       — World-map updates
         rules-referee       — Non-combat skill checks + sanity enforcement
```

| Agent             | Layer | Role                                                    |
|-------------------|-------|---------------------------------------------------------|
| `orchestrator`    | 1     | State mgmt, routing, narration, journaling              |
| `town-agent`      | 2     | Towns: navigation, NPCs, shops, guild, inn              |
| `dungeon-agent`   | 2     | Dungeon exploration and rooms                           |
| `combat-referee`  | 2     | d20 combat resolution + status effects                  |
| `world-builder`   | 2     | World-map updates, region lore                          |
| `rules-referee`   | 2     | Rule lookups, house-rule clarifications                 |

---

## World Content

**5 towns**

| ID    | Name              | Notes                                              |
|-------|-------------------|----------------------------------------------------|
| T001  | Stoneford         | Starting town. Guild, Docks, Inn, Shops.           |
| T002  | Windrest Keep     | Military post. House Stoneshield garrison.         |
| T003  | Wolfsjaw Pass     | Mountain pass. Smugglers' checkpoint.              |
| T004  | Jadehollow        | Mining town. Deepvein clan. Miner's Union stirs.   |
| T005  | Mistmere          | Lake city. Septry, shrine, drowned quarter.        |

**1 flagship dungeon**

- **D001 The Mossbarrow** — 4-room ancient barrow near Stoneford. The
  Ashford cellar.

**Quests**

- 28 named quests across the 5 towns (guild bounties, faction asks,
  personal favors), including 1 boss encounter (*The Drowned Thing*).
- 3 intertwined **backlines** — political conspiracies that bloom
  across the quests.

**Rules**

- d20 + ability modifier resolution.
- HP, status effects, death consequences recorded into world history.

---

## Directory Layout

```
templates/stoneford-worldlines/
├── README.md                     <- you are here
├── LICENSE                       <- AGPL-3.0
├── agents/
│   ├── orchestrator/
│   ├── town-agent/
│   ├── dungeon-agent/
│   ├── combat-referee/
│   ├── world-builder/
│   └── rules-referee/
└── game/
    ├── meta/
    │   ├── run_state.json        # location, time, last action
    │   └── game-start.json       # opening narration + bootstrap reads
    ├── player/                   # 7 files: profile / stats / inventory / ...
    ├── towns/                    # T001..T005
    ├── dungeons/                 # D001
    ├── rules/
    │   └── combat_rules.md
    ├── lore/                     # houses, religions, regions
    └── world/                    # world map, region index
```

---

## Using as a git submodule

Stoneford lives in its own repository so you can pin a known-good
version and pull updates independently from the engine.

```bash
# in your WorldLines documentation / deployment repo
git submodule add https://github.com/ludic-dynamics/stoneford-worldlines templates/stoneford-worldlines
git submodule update --init --recursive

# later, to update
git submodule update --remote templates/stoneford-worldlines
```

When `neonrp game new --template stoneford` runs, the CLI resolves the
template by name in:

1. `./templates/<name>/` (submodule path)
2. `~/.neonrp/templates/<name>/`
3. Engine packaged fallback

## Forking Stoneford for your own world

```bash
cp -R templates/stoneford-worldlines templates/my-world
# then:
#  - rename the houses, towns, NPCs
#  - keep the agent layout; it is the reusable part
#  - edit agents/*/system.md to match your tone
neonrp game new --template my-world
```

---

## See also

- [../../QUICKSTART.md](../../QUICKSTART.md)
- [../../CONCEPTS.md](../../CONCEPTS.md)
- [../../CLI_REFERENCE.md](../../CLI_REFERENCE.md)

---

## License & Acknowledgements

Copyright © 2026 Ludic Dynamics.

stoneford-worldlines is licensed under **AGPL-3.0-only**. See
[LICENSE](LICENSE) or https://www.gnu.org/licenses/agpl-3.0.html for
the full text. If you run a modified version to interact with users
over a network, you must make the corresponding source available to
those users.

Drift from the earlier `llm-rpg-starter` project. Narrative design by
the Ludic Dynamics founder. d20 rules adapted from open SRD conventions.

With gratitude to the Ludic Dynamics community, and to amber and other
friends whose support made this release possible.
